## Summary
簡述此 PR 做了什麼與其必要性 (what & why)。

## Scope
- [ ] feature
- [ ] fix
- [ ] refactor
- [ ] chore
- [ ] perf
- [ ] docs

## Algorithm Impact (BaZi Logic?)
- 影響核心八字/節氣/真太陽時計算： yes / no  (若 yes 說明層級與原因)
- 影響 evidence chain (anchorbasis)： yes / no (列出受影響節點)

## Changes
列出主要修改點（可用精簡條列）

## Evidence Chain Updates (若適用)
```
來源 → 中間推導 → 結論 (各步驟對應檔案/函式)
```

## Tests
- [ ] 新增測試
- [ ] 更新既有測試
- [ ] 不需測試 (說明原因)
- [ ] TEST-DEBT: 後續補 (理由)

若涉節氣 / 真太陽時 / 干支序列，至少提供：
- [ ] 正常案例
- [ ] 邊界 (交界 ±1 分鐘)
- [ ] 極端時區 / UTC +/- (若適用)

## Performance Considerations
(是否有 cache、是否移除重複計算、是否影響啟動時間)

## Security
(Secrets 未外洩 / 無硬編碼金鑰 / 無 eval)

## Breaking Changes
- [ ] Yes (描述舊版相容策略)
- [ ] No

## Checklist
- [ ] 無 magic number 未註解 (如 86400 / 0.2422)
- [ ] 型別嚴格 / 無 any 濫用
- [ ] 無未使用 console.debug / TODO 殘留 (除非標記 FIXME)
- [ ] 文檔/註解更新 (若必要)

## Screenshots / Logs (Optional)
(若為 UI 或輸出格式變動提供前後對照)

## Risk Mitigation / Rollback Plan
(如何快速回滾；是否可 feature flag)

## Related Issues
Closes #

---
Reviewer 提示：若檢視到時間/節氣/干支計算邏輯大幅變更，請優先標籤 `logic-core` 或 `astro-time`。
