/**
 * 神煞引擎測試
 */

import { describe, it, expect } from 'vitest';
import ShenshaEngine from '../storyEngine/shenshaEngine';
import ShenshaValidator from '../storyEngine/shenshaValidator';

describe('神煞規則引擎測試', () => {
  
  describe('ShenshaEngine', () => {
    it('should load traditional ruleset', () => {
      const engine = new ShenshaEngine('trad');
      expect(engine.getRuleset()).toBe('trad');
      expect(engine.getLoadedCount()).toBeGreaterThan(0);
      console.log(`載入 ${engine.getLoadedCount()} 個傳統神煞`);
      console.log('神煞清單:', engine.getLoadedNames());
    });

    it('should load legion ruleset', () => {
      const engine = new ShenshaEngine('legion');
      expect(engine.getRuleset()).toBe('legion');
      expect(engine.getLoadedCount()).toBeGreaterThan(0);
      console.log(`載入 ${engine.getLoadedCount()} 個軍團神煞`);
    });

    it('T1: 應命中桃花、太極（年=申、月=酉、日=卯、時=子）', () => {
      const engine = new ShenshaEngine('trad');
      const chart = {
        year: { stem: '甲', branch: '申' },
        month: { stem: '乙', branch: '酉' },
        day: { stem: '丙', branch: '卯' },
        hour: { stem: '丁', branch: '子' }
      };
      
      const matches = engine.calculate(chart);
      console.log('T1 命中神煞:', matches.map(m => m.name));
      
      const shenshaNames = matches.map(m => m.name);
      expect(shenshaNames).toContain('桃花');
      expect(shenshaNames).toContain('太極貴人');
    });

    it('T2: 應命中天乙貴人（日干=甲；四柱含丑或未）', () => {
      const engine = new ShenshaEngine('trad');
      const chart = {
        year: { stem: '甲', branch: '丑' },
        month: { stem: '乙', branch: '寅' },
        day: { stem: '甲', branch: '卯' },
        hour: { stem: '丁', branch: '辰' }
      };
      
      const matches = engine.calculate(chart);
      console.log('T2 命中神煞:', matches.map(m => m.name));
      
      const shenshaNames = matches.map(m => m.name);
      expect(shenshaNames).toContain('天乙貴人');
      
      // 檢查證據鏈
      const tianyi = matches.find(m => m.name === '天乙貴人');
      expect(tianyi).toBeDefined();
      expect(tianyi?.anchor_basis).toContain('日干=甲');
      expect(tianyi?.why_matched).toContain('丑');
    });

    it('T3: 應命中桃花（年=寅，四柱含卯）', () => {
      const engine = new ShenshaEngine('trad');
      const chart = {
        year: { stem: '甲', branch: '寅' },
        month: { stem: '乙', branch: '卯' },
        day: { stem: '丙', branch: '辰' },
        hour: { stem: '丁', branch: '巳' }
      };
      
      const matches = engine.calculate(chart);
      console.log('T3 命中神煞:', matches.map(m => m.name));
      
      const shenshaNames = matches.map(m => m.name);
      expect(shenshaNames).toContain('桃花');
    });

    it('T5: 軍團版應命中強桃花（年=申、月=酉、日=酉）', () => {
      const engine = new ShenshaEngine('legion');
      const chart = {
        year: { stem: '甲', branch: '申' },
        month: { stem: '乙', branch: '酉' },
        day: { stem: '丙', branch: '酉' },
        hour: { stem: '丁', branch: '子' }
      };
      
      const matches = engine.calculate(chart);
      console.log('T5 命中神煞:', matches.map(m => m.name));
      
      const shenshaNames = matches.map(m => m.name);
      expect(shenshaNames).toContain('強桃花');
      
      // 檢查證據鏈
      const qiangTaohua = matches.find(m => m.name === '強桃花');
      expect(qiangTaohua).toBeDefined();
      expect(qiangTaohua?.anchor_basis).toBe('combo');
      expect(qiangTaohua?.why_matched).toContain('AND');
    });
  });

  describe('ShenshaValidator', () => {
    it('should validate correct shensha definition', () => {
      const validator = new ShenshaValidator();
      const validDef = {
        name: '測試神煞',
        enabled: true,
        priority: 50,
        rules: [
          {
            anchor: 'dayStem',
            rule_ref: '測試來源',
            table: {
              '甲': ['子', '丑']
            }
          }
        ]
      };
      
      const result = validator.validate(validDef);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should detect missing required fields', () => {
      const validator = new ShenshaValidator();
      const invalidDef = {
        name: '測試神煞',
        // missing enabled and priority
        rules: []
      };
      
      const result = validator.validate(invalidDef);
      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      console.log('驗證錯誤:', result.errors);
    });

    it('should detect invalid 天干地支 values', () => {
      const validator = new ShenshaValidator();
      const invalidDef = {
        name: '測試神煞',
        enabled: true,
        priority: 50,
        rules: [
          {
            anchor: 'dayStem',
            rule_ref: '測試來源',
            table: {
              'invalid': ['子']  // invalid key
            }
          }
        ]
      };
      
      const result = validator.validate(invalidDef);
      expect(result.valid).toBe(false);
      const hasInvalidKeyError = result.errors.some(e => e.message.includes('不合法'));
      expect(hasInvalidKeyError).toBe(true);
    });
  });
});
