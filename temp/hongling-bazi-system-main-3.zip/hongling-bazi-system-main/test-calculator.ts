/**
 * 簡單測試新的專業八字計算器
 */
import { ProfessionalBaziCalculator } from './lookup-calculator';

async function testCalculator() {
  console.log('🧪 測試專業八字計算器');
  console.log('='.repeat(50));

  const calculator = new ProfessionalBaziCalculator();

  // 測試案例1: 1984/2/4 23:00 (立春邊界)
  console.log('\n📅 測試案例1: 1984/2/4 23:00 (立春邊界)');
  try {
    const result1 = calculator.calculateBazi(1984, 2, 4, 23, 0, { debug: true });
    console.log('年柱:', result1.year.pillar);
    console.log('月柱:', result1.month.pillar);
    console.log('日柱:', result1.day.pillar);  
    console.log('時柱:', result1.hour.pillar);
    console.log('十神:', result1.ten_gods.map(tg => `${tg.basis}:${tg.name}`));
    console.log('神煞:', result1.shensha.map(ss => `${ss.name}(${ss.anchor_basis})`));
    console.log('五行分佈:', result1.five_elements);
    console.log('立春判斷:', result1.calculation_logs.solar_terms_log);
  } catch (error) {
    console.error('❌ 測試1失敗:', error);
  }

  // 測試案例2: 1985/10/6 19:30 (寒露邊界)
  console.log('\n📅 測試案例2: 1985/10/6 19:30 (寒露邊界)'); 
  try {
    const result2 = calculator.calculateBazi(1985, 10, 6, 19, 30, { debug: true });
    console.log('年柱:', result2.year.pillar);
    console.log('月柱:', result2.month.pillar);
    console.log('日柱:', result2.day.pillar);
    console.log('時柱:', result2.hour.pillar);
    console.log('節氣判斷:', result2.calculation_logs.solar_terms_log);
    console.log('月柱計算:', result2.calculation_logs.month_log);
  } catch (error) {
    console.error('❌ 測試2失敗:', error);
  }

  // 測試案例3: 子時換日
  console.log('\n📅 測試案例3: 2024/1/1 23:30 (子時換日測試)');
  try {
    const result3a = calculator.calculateBazi(2024, 1, 1, 23, 30, { use_early_zi: false, debug: true });
    const result3b = calculator.calculateBazi(2024, 1, 1, 23, 30, { use_early_zi: true, debug: true });
    console.log('不換日日柱:', result3a.day.pillar);
    console.log('換日日柱:', result3b.day.pillar);
    console.log('日柱計算邏輯:', result3a.calculation_logs.day_log);
  } catch (error) {
    console.error('❌ 測試3失敗:', error);
  }

  // 測試案例4: 真太陽時
  console.log('\n📅 測試案例4: 2024/6/15 12:00 (真太陽時測試)');
  try {
    const result4a = calculator.calculateBazi(2024, 6, 15, 12, 0, { use_true_solar_time: false });
    const result4b = calculator.calculateBazi(2024, 6, 15, 12, 0, { use_true_solar_time: true, longitude: 110, debug: true });
    console.log('標準時時柱:', result4a.hour.pillar);
    console.log('真太陽時時柱:', result4b.hour.pillar);
    console.log('真太陽時調整:', result4b.calculation_logs.hour_log);
  } catch (error) {
    console.error('❌ 測試4失敗:', error);
  }

  console.log('\n✅ 測試完成！');
}

testCalculator().catch(console.error);