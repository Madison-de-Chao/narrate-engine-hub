# Changelog

All notable changes to this project will be documented in this file.

The format is inspired by Keep a Changelog, and this project adheres (informally) to Semantic Versioning once past v0.x.

## [Unreleased]
### Added
- Self-test script placeholder (to be expanded with endpoint checks)

## [v0.1.1] - 2025-09-10
### Added
- /health: query parameter `?storage=full` to return per-table counts and file size (SQLite).
- /health: query parameter `?test=full` to optionally run story engine generation smoke test.
- Repository stats aggregation (`repoStats`) with lightweight COUNT(*) queries.
- Documentation for advanced health check usage with examples.

### Changed
- `repository.ts` now exposes file size for SQLite database if available.

### Fixed
- Markdown trailing space lint issue in README health parameters table.

## [v0.1.0] - 2025-09-10
### Added
- Initial release tag after repository restructuring, SQLite integration, and narrative engine baseline.

### Notes
- Maintenance branch `release/v0.1-maintenance` created for patch updates.

---

Legend:
- Added: new features
- Changed: backward-compatible behavior changes
- Fixed: bug fixes
- Removed: features removed
- Security: security fixes
