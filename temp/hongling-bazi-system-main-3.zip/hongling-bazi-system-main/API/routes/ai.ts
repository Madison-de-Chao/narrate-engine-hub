import express from 'express'
import jwt, { JwtPayload } from 'jsonwebtoken'

import { generateArmyNarrative } from '../../storyEngine/generateArmyNarrative'
import type { ChartData, Pillar } from '../../storyEngine/utils'

const router = express.Router()

// ===== Env keys（只在後端使用，不暴露前端）=====
const OPENAI_API_KEY = process.env.OPENAI_API_KEY
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY || process.env.CLAUDE_API_KEY
const JWT_SECRET = process.env.JWT_SECRET

// ====== 型別定義 ======
export type StoryOptions = {
  tone?: string
  locale?: string
  maxTokens?: number
}

// 基本請求型別
type ArmyNarrativeRequest = {
  type: 'army-narrative'
  data: { pillars: import('../../storyEngine/utils').PillarSet }
  options?: StoryOptions
}


type FortuneAnalysisRequest = {
  type: 'fortune-analysis'
  data: ChartData
  options?: StoryOptions
}

type LifePredictionRequest = {
  type: 'life-prediction'
  data: ChartData
  options?: StoryOptions
}

type StoryGenerationRequest =
  | ArmyNarrativeRequest
  | FortuneAnalysisRequest
  | LifePredictionRequest

interface StoryGenerationResponse {
  storyId: string
  type: StoryGenerationRequest['type']
  story: string
  metadata: {
    userId?: string
    generatedAt: string
    provider: 'local' | 'openai' | 'anthropic'
    tokenUsed?: number
  }
}

// ===== 擴充 Express Request =====
declare global {
  namespace Express {
    interface Request {
      user?: { id: string; name: string }
    }
  }
}

// ===== 使用者驗證（JWT；未設定 JWT_SECRET 時採寬鬆模式）=====
function authenticateUser(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
): void {
  const raw = req.headers.authorization?.replace('Bearer ', '').trim()
  if (!raw) {
    res.status(401).json({ success: false, error: 'Please login first' })
    return
  }

  if (JWT_SECRET) {
    try {
      const decoded = jwt.verify(raw, JWT_SECRET) as JwtPayload | string
      if (typeof decoded === 'object' && decoded !== null) {
        req.user = { id: (decoded.sub as string) || (decoded['id'] as string) || 'user_jwt', name: (decoded['name'] as string) || 'JWT User' }
      } else req.user = { id: decoded as string, name: 'JWT User' }
      return next()
    } catch {
      res.status(401).json({ success: false, error: 'Invalid or expired JWT token' })
      return
    }
  } else {
    if (raw === 'invalid') {
      res.status(401).json({ success: false, error: 'Invalid token' })
      return
    }
    req.user = { id: 'user_dev', name: 'Dev User (no JWT)' }
    return next()
  }
}

// ====== OpenAI / Anthropic（示範：回傳假資料）======
async function callOpenAI(data: ChartData, _apiKey: string): Promise<string> {
  // 真實實作需安裝 openai 套件並呼叫 API
  return `🔮【AI 運勢分析（OpenAI 模擬）】\n${JSON.stringify(data, null, 2)}`
}

async function callAnthropic(data: ChartData, _apiKey: string): Promise<string> {
  // 真實實作需安裝 @anthropic-ai/sdk 並呼叫 API
  return `🌟【AI 人生預測（Claude 模擬）】\n${JSON.stringify(data, null, 2)}`
}

// ====== POST /api/ai/story ：產生故事 ======
router.post('/story', authenticateUser, async (req, res) => {
  try {
    const payload = req.body as StoryGenerationRequest
    const user = req.user

    if (!payload?.type) {
      res.status(400).json({ success: false, error: 'Story type is required' })
      return
    }
    if (!payload?.data) {
      res.status(400).json({ success: false, error: 'Story data is required' })
      return
    }

    let story = ''
    let provider: StoryGenerationResponse['metadata']['provider'] = 'local'

    switch (payload.type) {
      case 'army-narrative': {
        const { pillars } = payload.data as ArmyNarrativeRequest['data']
        if (!pillars) {
          res.status(400).json({
            success: false,
            error: 'Army narrative requires { pillars }'
          })
          return
        }
        const result = generateArmyNarrative(pillars)
        story = result.narrative
        break
      }

      case 'fortune-analysis': {
        if (!OPENAI_API_KEY) {
          res.status(500).json({ success: false, error: 'OpenAI API key not configured' })
          return
        }
        story = await callOpenAI(payload.data as ChartData, OPENAI_API_KEY)
        provider = 'openai'
        break
      }

      case 'life-prediction': {
        if (!ANTHROPIC_API_KEY) {
          res.status(500).json({ success: false, error: 'Anthropic/Claude API key not configured' })
          return
        }
        story = await callAnthropic(payload.data as ChartData, ANTHROPIC_API_KEY)
        provider = 'anthropic'
        break
      }

      default:
        res.status(400).json({ success: false, error: `Unsupported story type: ${(payload as any).type}` })
        return
    }

    const storyId = `story_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`
    const response: StoryGenerationResponse = {
      storyId,
      type: payload.type,
      story,
      metadata: {
        userId: user?.id,
        generatedAt: new Date().toISOString(),
        provider,
        tokenUsed: story.length,
      },
    };

    res.json({
      success: true,
      data: response,
      message: `Story generated successfully using ${provider} provider`
    })
  } catch (error) {
    console.error('Story generation error:', error)
    res.status(500).json({ success: false, error: 'Internal server error during story generation' })
  }
});

// ====== GET /api/ai/story/:storyId ：取回故事 ======
router.get('/story/:storyId', authenticateUser, (req, res) => {
  try {
    const { storyId } = req.params
    if (!storyId?.startsWith('story_')) {
      res.status(404).json({ success: false, error: 'Story not found' })
      return
    }
    if (!req.user) {
      res.status(401).json({ success: false, error: "User not authenticated" });
      return;
    }
    res.json({
      success: true,
      data: {
        storyId,
        type: 'army-narrative',
        story: '（示範）您的軍團敘事內容……',
        metadata: {
          userId: req.user.id,
          generatedAt: new Date().toISOString(),
          provider: 'local'
        }
      }
    })
  } catch (error) {
    console.error('Story retrieval error:', error)
    res.status(500).json({ success: false, error: 'Internal server error during story retrieval' })
  }
});

// ====== GET /api/ai/providers ：提供者清單（公開）======
router.get('/providers', (_req, res) => {
  try {
    res.json({
      success: true,
      data: {
        providers: [
          {
            name: "local",
            displayName: "本地故事引擎",
            description: "使用內建的故事生成邏輯",
            supportedTypes: ["army-narrative"],
            status: "active",
            available: true,
          },
          {
            name: "openai",
            displayName: "OpenAI GPT",
            description: "OpenAI GPT 模型驅動的故事生成",
            supportedTypes: [
              "army-narrative",
              "fortune-analysis",
              "life-prediction",
            ],
            status: OPENAI_API_KEY ? "active" : "not-configured",
            available: !!OPENAI_API_KEY,
          },
          {
            name: 'anthropic',
            displayName: 'Anthropic Claude',
            description: 'Anthropic Claude 模型驅動的故事生成',
            supportedTypes: ['fortune-analysis', 'life-prediction'],
            status: ANTHROPIC_API_KEY ? 'active' : 'not-configured',
            available: !!ANTHROPIC_API_KEY
          }
        ]
      }
    })
  } catch (error) {
    console.error('Provider list error:', error)
    res.status(500).json({ success: false, error: 'Internal server error while fetching providers' })
  }
});

export default router

