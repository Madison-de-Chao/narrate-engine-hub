import express from "express";
import { baziComplianceEngine } from "../compliance/BaziComplianceEngine";
import { enhancedBaziEngine } from "../../storyEngine/enhancedBaziEngine";
import fs from "fs";
import path from "path";

const router = express.Router();

// Load test cases
const testCasesPath = path.join(
  __dirname,
  "../../tests/bazi-compliance-test-cases.json",
);
const testCases = JSON.parse(fs.readFileSync(testCasesPath, "utf8"));

interface ValidationRequest {
  test_type?: "compliance" | "accuracy" | "performance" | "all";
  test_cases?: string[]; // specific test case names
  input_data?: {
    year: number;
    month: number;
    day: number;
    hour: number;
    minute?: number;
  };
  options?: {
    include_evidence?: boolean;
    detailed_report?: boolean;
    performance_metrics?: boolean;
  };
}

interface ValidationResult {
  overall_status: "PASS" | "FAIL" | "WARNING";
  compliance_score: number;
  test_results: Array<{
    test_name: string;
    status: "PASS" | "FAIL" | "WARNING";
    score: number;
    details: any;
    evidence?: any;
  }>;
  performance_metrics?: {
    total_time_ms: number;
    average_time_ms: number;
    memory_usage_mb: number;
  };
  recommendations: string[];
  summary: {
    total_tests: number;
    passed: number;
    failed: number;
    warnings: number;
  };
}

// POST /api/validate/bazi - 八字計算驗證端點
router.post("/bazi", async (req, res) => {
  const startTime = Date.now();

  try {
    const request = req.body as ValidationRequest;
    const testType = request.test_type || "all";

    let validationResult: ValidationResult = {
      overall_status: "PASS",
      compliance_score: 100,
      test_results: [],
      recommendations: [],
      summary: {
        total_tests: 0,
        passed: 0,
        failed: 0,
        warnings: 0,
      },
    };

    // 如果提供特定輸入數據，進行單次驗證
    if (request.input_data) {
      validationResult = await validateSingleInput(
        request.input_data,
        request.options,
      );
    } else {
      // 運行預定義的測試案例
      validationResult = await runTestSuite(
        testType,
        request.test_cases,
        request.options,
      );
    }

    // 添加性能指標
    const totalTime = Date.now() - startTime;
    if (request.options?.performance_metrics) {
      validationResult.performance_metrics = {
        total_time_ms: totalTime,
        average_time_ms:
          totalTime / Math.max(validationResult.summary.total_tests, 1),
        memory_usage_mb: process.memoryUsage().heapUsed / 1024 / 1024,
      };
    }

    res.json({
      success: true,
      data: validationResult,
    });
  } catch (error: any) {
    console.error("Validation error:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error during validation",
      details: error.message,
    });
  }
});

// GET /api/validate/test-cases - 取得可用的測試案例
router.get("/test-cases", (req, res) => {
  try {
    const { category } = req.query;

    let availableTests = testCases.compliance_test_cases;

    if (category) {
      availableTests = {
        [category as string]: availableTests[category as string],
      };
    }

    const testSummary = Object.keys(availableTests).map((testCategory) => ({
      category: testCategory,
      test_count: Array.isArray(availableTests[testCategory])
        ? availableTests[testCategory].length
        : Object.keys(availableTests[testCategory]).length,
      description: getTestCategoryDescription(testCategory),
    }));

    res.json({
      success: true,
      data: {
        test_categories: testSummary,
        test_config: testCases.automated_testing_config,
        compliance_scoring: testCases.compliance_scoring,
      },
    });
  } catch (error: any) {
    console.error("Test cases listing error:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error during test cases listing",
    });
  }
});

// POST /api/validate/batch - 批量驗證
router.post("/batch", async (req, res) => {
  const startTime = Date.now();

  try {
    const { inputs, options = {} } = req.body;

    if (!inputs || !Array.isArray(inputs)) {
      return res.status(400).json({
        success: false,
        error: "inputs array is required",
      });
    }

    const batchResults: any[] = [];
    const batchSummary = {
      total: inputs.length,
      passed: 0,
      failed: 0,
      warnings: 0,
      average_score: 0,
    };

    for (let i = 0; i < inputs.length; i++) {
      const input = inputs[i];
      try {
        const result = await validateSingleInput(input, options);
        batchResults.push({
          index: i,
          input,
          result,
        });

        // 更新統計
        if (result.overall_status === "PASS") batchSummary.passed++;
        else if (result.overall_status === "FAIL") batchSummary.failed++;
        else batchSummary.warnings++;

        batchSummary.average_score += result.compliance_score;
      } catch (error: any) {
        batchResults.push({
          index: i,
          input,
          error: error.message,
        });
        batchSummary.failed++;
      }
    }

    batchSummary.average_score = batchSummary.average_score / inputs.length;

    const totalTime = Date.now() - startTime;

    res.json({
      success: true,
      data: {
        batch_summary: batchSummary,
        results: batchResults,
        performance: {
          total_time_ms: totalTime,
          average_time_per_test_ms: totalTime / inputs.length,
        },
      },
    });
  } catch (error: any) {
    console.error("Batch validation error:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error during batch validation",
    });
  }
});

// GET /api/validate/standards - 取得驗證標準
router.get("/standards", (req, res) => {
  try {
    const standards = {
      calculation_standards: {
        year_pillar: {
          required_method: "lichun_boundary_precise",
          precision: "minute_level",
          forbidden_methods: ["gregorian_new_year", "lunar_new_year"],
        },
        month_pillar: {
          required_method: "solar_terms_with_wu_hu_dun",
          required_tables: ["solar_terms", "wu_hu_dun_month"],
          forbidden_methods: ["gregorian_month_direct"],
        },
        day_pillar: {
          required_method: "reference_date_calculation",
          reference_date: "1985-09-22",
          required_handling: ["leap_year", "timezone", "zishi_crossday"],
        },
        hour_pillar: {
          required_method: "wu_shu_dun_shi_with_zishi",
          required_tables: ["wu_shu_dun_shi"],
          special_handling: ["zishi_crossday_23_to_01"],
        },
      },
      lookup_table_requirements: {
        shensha: {
          method: "table_lookup_only",
          forbidden: "mathematical_calculation",
          required_tables: ["tianyi_guiren", "taohua", "yang_ren", "kong_wang"],
        },
        nayin: {
          method: "direct_table_lookup",
          table_completeness: "60_jiazi_complete",
        },
        ten_gods: {
          method: "day_gan_based_lookup",
          required_relationships: "all_ten_relationships",
        },
        hidden_stems: {
          method: "table_with_weights",
          required_data: ["gan", "weight", "element"],
        },
      },
      compliance_requirements: {
        minimum_score: 80,
        critical_requirements: [
          "no_hardcoded_calculations",
          "complete_table_lookup",
          "accurate_boundary_handling",
          "comprehensive_evidence_recording",
        ],
      },
    };

    res.json({
      success: true,
      data: standards,
    });
  } catch (error: any) {
    console.error("Standards retrieval error:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error during standards retrieval",
    });
  }
});

// 輔助函數

async function validateSingleInput(
  input: any,
  options: any = {},
): Promise<ValidationResult> {
  const testStartTime = Date.now();

  try {
    // 使用增強版八字引擎計算
    const chart = enhancedBaziEngine.calculateEnhancedChart(input);

    // 使用合規性引擎檢查
    const complianceResult = baziComplianceEngine.checkFullCompliance(
      input,
      chart.pillars,
      "enhanced_bazi_engine",
    );

    const testResults: any[] = [];

    // 檢查年柱合規性
    testResults.push({
      test_name: "year_pillar_lichun_boundary",
      status: chart.pillars.year.calculation_method.includes("lichun")
        ? "PASS"
        : "FAIL",
      score: chart.pillars.year.calculation_method.includes("lichun")
        ? 100
        : 60,
      details: {
        method_used: chart.pillars.year.calculation_method,
        evidence: chart.pillars.year.calculation_evidence,
      },
    });

    // 檢查月柱合規性
    testResults.push({
      test_name: "month_pillar_solar_terms",
      status: chart.pillars.month.calculation_method.includes("solar_terms")
        ? "PASS"
        : "FAIL",
      score: chart.pillars.month.calculation_method.includes("solar_terms")
        ? 100
        : 50,
      details: {
        method_used: chart.pillars.month.calculation_method,
        evidence: chart.pillars.month.calculation_evidence,
      },
    });

    // 檢查日柱合規性
    testResults.push({
      test_name: "day_pillar_reference_date",
      status: chart.pillars.day.calculation_method.includes("reference")
        ? "PASS"
        : "FAIL",
      score: chart.pillars.day.calculation_method.includes("reference")
        ? 100
        : 70,
      details: {
        method_used: chart.pillars.day.calculation_method,
        evidence: chart.pillars.day.calculation_evidence,
      },
    });

    // 檢查時柱合規性
    testResults.push({
      test_name: "hour_pillar_zishi_handling",
      status: chart.pillars.hour.calculation_method.includes("zishi")
        ? "PASS"
        : "FAIL",
      score: chart.pillars.hour.calculation_method.includes("zishi") ? 100 : 80,
      details: {
        method_used: chart.pillars.hour.calculation_method,
        evidence: chart.pillars.hour.calculation_evidence,
      },
    });

    // 檢查神煞計算
    testResults.push({
      test_name: "shensha_table_lookup",
      status: chart.shensha.every((s) => s.calculation_method.includes("table"))
        ? "PASS"
        : "WARNING",
      score: chart.shensha.every((s) => s.calculation_method.includes("table"))
        ? 100
        : 85,
      details: {
        shensha_count: chart.shensha.length,
        calculation_methods: chart.shensha.map((s) => s.calculation_method),
      },
    });

    // 檢查藏干權重
    const hiddenStemsComplete = Object.values(chart.pillars).every(
      (pillar) => pillar.hiddenStems && pillar.hiddenStems.length > 0,
    );
    testResults.push({
      test_name: "hidden_stems_with_weights",
      status: hiddenStemsComplete ? "PASS" : "FAIL",
      score: hiddenStemsComplete ? 100 : 60,
      details: {
        pillars_with_hidden_stems: Object.keys(chart.pillars).filter(
          (key) => chart.pillars[key].hiddenStems.length > 0,
        ),
      },
    });

    // 計算總體分數
    const totalScore =
      testResults.reduce((sum, test) => sum + test.score, 0) /
      testResults.length;
    const passedTests = testResults.filter((t) => t.status === "PASS").length;
    const failedTests = testResults.filter((t) => t.status === "FAIL").length;
    const warningTests = testResults.filter(
      (t) => t.status === "WARNING",
    ).length;

    const overallStatus =
      totalScore >= 90 ? "PASS" : totalScore >= 70 ? "WARNING" : "FAIL";

    const recommendations: string[] = [];
    if (totalScore < 90) {
      recommendations.push("考慮升級到完全查表方法");
    }
    if (failedTests > 0) {
      recommendations.push("修正失敗的測試項目");
    }
    if (!hiddenStemsComplete) {
      recommendations.push("補充完整的藏干權重計算");
    }

    return {
      overall_status: overallStatus,
      compliance_score: Math.round(totalScore),
      test_results: testResults,
      recommendations,
      summary: {
        total_tests: testResults.length,
        passed: passedTests,
        failed: failedTests,
        warnings: warningTests,
      },
    };
  } catch (error: any) {
    throw new Error(`Validation failed: ${error.message}`);
  }
}

async function runTestSuite(
  testType: string,
  testCaseNames?: string[],
  options: any = {},
): Promise<ValidationResult> {
  const allResults: any[] = [];
  let totalScore = 0;

  // 根據測試類型選擇相應的測試案例
  const testCategories =
    testType === "all"
      ? Object.keys(testCases.compliance_test_cases)
      : [testType];

  for (const category of testCategories) {
    const categoryTests = testCases.compliance_test_cases[category];

    if (Array.isArray(categoryTests)) {
      for (const testCase of categoryTests) {
        if (!testCaseNames || testCaseNames.includes(testCase.name)) {
          try {
            const result = await validateSingleInput(testCase.input, options);
            result.test_results.forEach((tr) => {
              tr.test_name = `${category}_${tr.test_name}`;
            });
            allResults.push(...result.test_results);
            totalScore += result.compliance_score;
          } catch (error: any) {
            allResults.push({
              test_name: `${category}_${testCase.name}`,
              status: "FAIL",
              score: 0,
              details: { error: error.message },
            });
          }
        }
      }
    }
  }

  const averageScore =
    allResults.length > 0
      ? (totalScore / allResults.length) * testCategories.length
      : 0;
  const passedTests = allResults.filter((t) => t.status === "PASS").length;
  const failedTests = allResults.filter((t) => t.status === "FAIL").length;
  const warningTests = allResults.filter((t) => t.status === "WARNING").length;

  const overallStatus =
    averageScore >= 90 ? "PASS" : averageScore >= 70 ? "WARNING" : "FAIL";

  const recommendations: string[] = [];
  if (failedTests > 0) {
    recommendations.push(`修正 ${failedTests} 個失敗的測試`);
  }
  if (averageScore < 80) {
    recommendations.push("整體合規性分數偏低，需要系統性改進");
  }

  return {
    overall_status: overallStatus,
    compliance_score: Math.round(averageScore),
    test_results: allResults,
    recommendations,
    summary: {
      total_tests: allResults.length,
      passed: passedTests,
      failed: failedTests,
      warnings: warningTests,
    },
  };
}

function getTestCategoryDescription(category: string): string {
  const descriptions: Record<string, string> = {
    lichun_boundary_tests: "立春分界測試 - 驗證年柱計算是否正確使用立春分界",
    solar_term_month_tests: "節氣月柱測試 - 驗證月柱是否按節氣正確劃分",
    day_pillar_tests: "日柱計算測試 - 驗證基準日推算和閏年處理",
    hour_pillar_tests: "時柱計算測試 - 驗證子時跨日和五鼠遁時",
    shensha_calculation_tests: "神煞計算測試 - 驗證神煞是否正確查表計算",
    hidden_stems_tests: "藏干權重測試 - 驗證藏干是否包含完整權重信息",
    edge_case_tests: "邊界情況測試 - 驗證特殊情況的處理",
  };
  return descriptions[category] || "未知測試類別";
}

export default router;
