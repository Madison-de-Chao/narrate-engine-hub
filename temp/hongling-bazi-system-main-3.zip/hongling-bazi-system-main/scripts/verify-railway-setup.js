#!/usr/bin/env node

/**
 * Railway Setup Verification Script
 * Verifies that all necessary components are configured for Railway OAuth and deployment
 */

const fs = require('fs');
const path = require('path');

console.log('🔍 Railway 設定驗證工具');
console.log('========================\n');

const checks = [];

// Check package.json
function checkPackageJson() {
    const packagePath = path.join(process.cwd(), 'package.json');
    if (!fs.existsSync(packagePath)) {
        return { pass: false, message: '找不到 package.json' };
    }
    
    const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
    
    const requiredScripts = ['build', 'start'];
    const missingScripts = requiredScripts.filter(script => !pkg.scripts || !pkg.scripts[script]);
    
    if (missingScripts.length > 0) {
        return { pass: false, message: `缺少必要腳本: ${missingScripts.join(', ')}` };
    }
    
    return { pass: true, message: 'package.json 配置正確' };
}

// Check railway.json
function checkRailwayJson() {
    const railwayPath = path.join(process.cwd(), 'railway.json');
    if (!fs.existsSync(railwayPath)) {
        return { pass: false, message: '找不到 railway.json' };
    }
    
    const config = JSON.parse(fs.readFileSync(railwayPath, 'utf8'));
    
    // Check source configuration
    if (!config.source || config.source.type !== 'github') {
        return { pass: false, message: 'railway.json 缺少 GitHub 來源配置' };
    }
    
    // Check build configuration
    if (!config.build || !config.build.buildCommand) {
        return { pass: false, message: 'railway.json 缺少建置配置' };
    }
    
    // Check deploy configuration
    if (!config.deploy || !config.deploy.startCommand) {
        return { pass: false, message: 'railway.json 缺少部署配置' };
    }
    
    // Check health check
    if (!config.deploy.healthcheckPath) {
        return { pass: false, message: 'railway.json 缺少健康檢查配置' };
    }
    
    return { pass: true, message: 'railway.json 配置完整' };
}

// Check GitHub workflows
function checkGitHubWorkflows() {
    const workflowsPath = path.join(process.cwd(), '.github/workflows');
    if (!fs.existsSync(workflowsPath)) {
        return { pass: false, message: '找不到 .github/workflows 目錄' };
    }
    
    /**
     * The required workflow files for Railway integration.
     * By default, we check for 'ci.yml' and 'deploy.yml', which are commonly used for CI and deployment.
     * You can override this by setting the REQUIRED_WORKFLOWS environment variable (comma-separated).
     */
    const requiredWorkflows = process.env.REQUIRED_WORKFLOWS
        ? process.env.REQUIRED_WORKFLOWS.split(',').map(f => f.trim()).filter(Boolean)
        : ['ci.yml', 'deploy.yml'];
    const missingWorkflows = requiredWorkflows.filter(workflow => 
        !fs.existsSync(path.join(workflowsPath, workflow))
    );
    
    if (missingWorkflows.length > 0) {
        return { pass: false, message: `缺少工作流程: ${missingWorkflows.join(', ')}` };
    }
    
    return { pass: true, message: 'GitHub 工作流程配置完整' };
}

// Check CODEOWNERS
function checkCodeowners() {
    const codeownersPath = path.join(process.cwd(), '.github/CODEOWNERS');
    if (!fs.existsSync(codeownersPath)) {
        return { pass: false, message: '找不到 .github/CODEOWNERS 檔案' };
    }
    
    return { pass: true, message: 'CODEOWNERS 檔案存在' };
}

// Check build output
function checkBuildOutput() {
    const distPath = path.join(process.cwd(), 'dist');
    if (!fs.existsSync(distPath)) {
        return { pass: false, message: '找不到建置輸出目錄 (dist/)，請執行 npm run build' };
    }
    
    const apiPath = path.join(distPath, 'API', 'index.js');
    if (!fs.existsSync(apiPath)) {
        return { pass: false, message: '找不到主要應用程式檔案 (dist/API/index.js)' };
    }
    
    return { pass: true, message: '建置輸出正確' };
}

// Run all checks
const checkFunctions = [
    { name: 'Package.json 配置', fn: checkPackageJson },
    { name: 'Railway.json 配置', fn: checkRailwayJson },
    { name: 'GitHub 工作流程', fn: checkGitHubWorkflows },
    { name: 'CODEOWNERS 檔案', fn: checkCodeowners },
    { name: '建置輸出', fn: checkBuildOutput }
];

let allPassed = true;

checkFunctions.forEach(({ name, fn }) => {
    const result = fn();
    const status = result.pass ? '✅' : '❌';
    console.log(`${status} ${name}: ${result.message}`);
    
    if (!result.pass) {
        allPassed = false;
    }
});

console.log('\n========================');
if (allPassed) {
    console.log('🎉 所有檢查通過！Railway OAuth 設定應該可以正常運作。');
    console.log('\n建議步驟:');
    console.log('1. 前往 Railway 儀表板重新連接 GitHub');
    console.log('2. 確認儲存庫存取權限已授予');
    console.log('3. 測試自動部署功能');
} else {
    console.log('⚠️  部分檢查失敗，請修正後重新執行驗證。');
    process.exit(1);
}