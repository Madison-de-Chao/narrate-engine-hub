# Railway 部署連線問題故障排除指南

## 問題症狀
Railway 持續跳回 "app Installed" 頁面，無法正常連接到應用程式。

## 可能原因與解決方案

### 1. 健康檢查失敗 🏥

**症狀**: Railway 健康檢查超時或返回錯誤狀態
**解決方案**:
- 確認 `/health` 端點可正常訪問
- 檢查健康檢查是否在 60 秒內完成
- 使用簡化的健康檢查（不測試完整故事引擎）

**驗證方式**:
```bash
# 測試基本健康檢查（快速）
curl https://your-app.railway.app/health

# 測試完整健康檢查（包含故事引擎）
curl https://your-app.railway.app/health?test=full

# 測試快速狀態端點
curl https://your-app.railway.app/status
```

### 2. 埠口綁定問題 🔌

**症狀**: 應用程式無法綁定到 Railway 分配的埠口
**解決方案**:
- 確保應用程式使用 `process.env.PORT`
- 綁定到 `0.0.0.0` 而非 `localhost`
- 檢查 Railway 環境變數設定

**檢查步驟**:
1. 在 Railway 日誌中查看啟動配置輸出
2. 確認 PORT 和 HOST 變數正確
3. 檢查是否有埠口衝突錯誤

### 3. 建置失敗 🔨

**症狀**: TypeScript 編譯或依賴安裝失敗
**解決方案**:
- 檢查 `npm ci && npm run build` 命令執行狀況
- 確認所有依賴版本兼容
- 檢查 TypeScript 配置

**驗證方式**:
```bash
# 本地測試建置過程
npm ci
npm run build
npm start
```

### 4. 環境變數配置 ⚙️

**必要的環境變數**:
- `NODE_ENV=production`
- `PORT` (Railway 自動設定)
- `HOST=0.0.0.0` (可選，應用程式有預設值)

**可選的環境變數**:
- `OPENAI_API_KEY` (如果使用 AI 功能)
- `CLAUDE_API_KEY` (如果使用 AI 功能)

### 5. 故事引擎依賴問題 📚

**症狀**: 故事生成模組載入失敗
**解決方案**:
- 健康檢查已優化為可選測試故事引擎
- 默認情況下跳過故事引擎測試以加快啟動
- 可通過 `?test=full` 參數測試完整功能

## 部署檢查清單 ✅

### 部署前檢查
- [ ] 本地建置成功 (`npm run build`)
- [ ] 本地啟動正常 (`npm start`)
- [ ] 健康檢查端點回應正常
- [ ] 環境變數已正確設定

### 部署後檢查
- [ ] Railway 建置日誌無錯誤
- [ ] 應用程式啟動日誌正常
- [ ] 健康檢查端點可訪問
- [ ] 主要 API 端點正常運作

## 常見錯誤代碼

### GitHub OAuth 認證錯誤 🔐
**症狀**: "Error authenticating with github，Problem completing OAuth login"
**含義**: Railway 無法與 GitHub 完成 OAuth 認證
**解決方案**:
- 檢查 GitHub App 權限設定
- 確認 Railway 有權訪問儲存庫
- 重新連接 Railway 與 GitHub 整合
- 驗證 `.github/` 目錄配置完整
- 檢查 `railway.json` 中的 GitHub 來源設定
- 清除瀏覽器快取和 Cookie
- 嘗試使用無痕/私人瀏覽視窗連接
- 確認 GitHub 帳戶有足夠權限
- 檢查組織 SSO 限制是否阻擋 Railway
- 驗證雙重驗證 (2FA) 正確配置

**詳細解決步驟**: 參閱 `RAILWAY_OAUTH_FIX.md`

**GitHub App 設定檢查**:
1. 前往 GitHub 設定 > 應用程式 > 已安裝的 GitHub Apps
2. 找到 "Railway" 並點選 "設定"
3. 確認儲存庫存取權限已正確授予
4. 驗證所有必要權限已啟用

### EADDRINUSE
**含義**: 埠口已被占用
**解決**: 確認 Railway 環境中的 PORT 設定

### EACCES
**含義**: 權限不足
**解決**: 檢查埠口權限設定

### ENOTFOUND
**含義**: 主機解析失敗
**解決**: 檢查 HOST 環境變數

## 調試步驟

1. **檢查 Railway 日誌**
   - 查看建置日誌確認編譯成功
   - 查看部署日誌確認啟動過程
   - 注意任何錯誤或警告訊息

2. **測試健康檢查**
   ```bash
   curl -v https://your-app.railway.app/health
   curl -v https://your-app.railway.app/status
   ```

3. **檢查環境配置**
   - 確認 Railway 環境變數設定
   - 檢查 railway.json 配置
   - 驗證 package.json 腳本

4. **本地重現問題**
   ```bash
   # 模擬生產環境
   NODE_ENV=production npm start
   ```

## 最佳實踐建議

1. **使用分層健康檢查**
   - 基本健康檢查快速回應
   - 完整健康檢查按需執行

2. **改善日誌輸出**
   - 詳細的啟動配置日誌
   - Railway 特定的調試資訊

3. **優雅錯誤處理**
   - 捕獲並記錄啟動錯誤
   - 提供有用的錯誤訊息

4. **監控和警報**
   - 定期檢查健康檢查端點
   - 監控應用程式效能指標

## 聯絡支援

如果問題仍然存在，請提供以下資訊：
- Railway 建置和部署日誌
- 健康檢查端點的回應
- 環境變數配置（隱藏敏感資訊）
- 錯誤訊息的完整內容