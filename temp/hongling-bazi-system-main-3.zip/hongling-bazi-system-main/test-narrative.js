const http = require('http');

function testAPI(path, payload) {
    return new Promise((resolve, reject) => {
        const data = JSON.stringify(payload);
        
        const options = {
            hostname: 'localhost',
            port: 3000,
            path: path,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': data.length
            }
        };
        
        const req = http.request(options, (res) => {
            let responseData = '';
            
            res.on('data', (chunk) => {
                responseData += chunk;
            });
            
            res.on('end', () => {
                try {
                    resolve(JSON.parse(responseData));
                } catch (e) {
                    resolve(responseData);
                }
            });
        });
        
        req.on('error', reject);
        req.write(data);
        req.end();
    });
}

// 執行測試
async function runTests() {
    console.log('測試敘事生成 API...\n');
    
    const tests = [
        {
            name: '基礎測試',
            payload: {
                bazi: { year: '甲子' },
                tone: 'default'
            }
        },
        {
            name: '完整八字',
            payload: {
                bazi: {
                    year: '甲子',
                    month: '丙寅',
                    day: '戊午',
                    hour: '庚申'
                },
                tone: 'military'
            }
        }
    ];
    
    for (const test of tests) {
        console.log(`執行: ${test.name}`);
        try {
            const result = await testAPI('/api/generate', test.payload);
            console.log('結果:', JSON.stringify(result, null, 2));
            console.log('-'.repeat(50));
        } catch (error) {
            console.error('錯誤:', error.message);
        }
    }
}

runTests();
