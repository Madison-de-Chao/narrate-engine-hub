#!/bin/bash
echo "🔍 虹靈御所後端診斷開始..."

# 顏色定義
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 檢查 Node 版本
NODE_VERSION=$(node -v | cut -d'v' -f2)
REQUIRED_VERSION="18.0.0"
if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$NODE_VERSION" | sort -V | head -n1)" = "$REQUIRED_VERSION" ]; then 
    echo -e "${GREEN}✓ Node 版本符合要求: $NODE_VERSION${NC}"
else
    echo -e "${RED}✗ Node 版本不符: $NODE_VERSION (需要 >= $REQUIRED_VERSION)${NC}"
    exit 1
fi

# 檢查依賴
if [ -d "node_modules" ]; then
    echo -e "${GREEN}✓ node_modules 存在${NC}"
else
    echo -e "${YELLOW}! 安裝依賴中...${NC}"
    npm install
fi

# 檢查編譯
if [ -d "dist" ]; then
    echo -e "${GREEN}✓ dist 目錄存在${NC}"
else
    echo -e "${YELLOW}! 編譯中...${NC}"
    npm run build
fi

# 檢查環境變數
if [ -f ".env" ]; then
    echo -e "${GREEN}✓ .env 檔案存在${NC}"
else
    echo -e "${YELLOW}! 創建 .env...${NC}"
    cp env.example .env
fi

# 嘗試啟動
echo -e "${YELLOW}啟動服務器...${NC}"
npm start &
PID=$!
sleep 3

# 測試連接
if curl -s http://localhost:3000/health > /dev/null; then
    echo -e "${GREEN}✓ 服務器啟動成功！${NC}"
else
    echo -e "${RED}✗ 服務器啟動失敗${NC}"
    kill $PID 2>/dev/null
    echo "嘗試開發模式..."
    npm run dev
fi
