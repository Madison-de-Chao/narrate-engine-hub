# Frontend Integration Guide

This document explains how a frontend (React/TypeScript or other web client) can integrate with the Hongling BaZi System APIs. The focus is on the publicly exposed REST endpoints, payload contracts, and recommended client-side helpers.

## 1. Environment Setup

- **API base URL**: expose a single configuration such as `VITE_API_BASE_URL` (for Vite) or `NEXT_PUBLIC_API_BASE_URL` (for Next.js). During local development the default server runs at `http://localhost:3000`.
- **Timeouts**: keep HTTP timeouts around 20 seconds. Some narrative-generation routes may take a few seconds to return.
- **CORS**: the API already enables CORS. Browsers can call the endpoints directly as long as the correct base URL is used.
- **Authentication**: current routes do not require user authentication tokens. If `API keys` are later enabled via `API/routes/keys.ts`, pass them through a request header named `x-api-key`.

```ts
export const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:3000";
```

## 2. Core Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Lightweight heartbeat used by Railway. Returns status, uptime, and memory snapshot. |
| GET | `/status` | Similar to `/health`, intended for dashboards or sanity checks. |
| GET | `/railway-status` | Railway-focused diagnostics (environment, memory, port). |
| POST | `/api/bazi/compute` | Primary BaZi calculation endpoint (stable contract). |
| POST | `/api/bazi/generate` | Legacy full workflow (creates DB rows and generates narratives). Use only if server-side persistence is required. |

### 2.1 POST `/api/bazi/compute`

Request body:

```json
{
  "datetime_local": "2025-10-25T09:30",
  "timezone": "Asia/Taipei",
  "longitude": 121.5654,
  "use_true_solar_time": true
}
```

Field notes:

- `datetime_local` must be ISO-8601 without timezone. Frontend should gather user input and convert via libraries such as `luxon` or `dayjs`.
- `timezone` should be an IANA identifier (e.g. `Asia/Tokyo`).
- `longitude` expects a number (east positive, west negative). Display a slider or decimal input to the user.
- `use_true_solar_time` toggles true solar time adjustments.

Example TypeScript types:

```ts
export interface ComputeRequest {
  datetime_local: string;
  timezone: string;
  longitude: number;
  use_true_solar_time: boolean;
}

export interface ComputeSuccess {
  status: "success";
  data: {
    year_pillar: string;
    month_pillar: string;
    day_pillar: string;
    hour_pillar: string;
    anchors: {
      anchor_basis: string;
      rule_ref: string;
      why_matched: string;
    };
  };
}

export interface ComputeError {
  status: "error";
  code: string;
  message: string;
}
```

Client helper:

```ts
export async function computeBazi(input: ComputeRequest): Promise<ComputeSuccess> {
  const res = await fetch(`${API_BASE}/api/bazi/compute`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  });

  if (!res.ok) {
    const err = (await res.json()) as ComputeError;
    throw new Error(err.message ?? "Compute request failed");
  }

  return (await res.json()) as ComputeSuccess;
}
```

Errors: missing or incorrectly typed fields return HTTP `400` with `code: "INVALID_PAYLOAD"`. Unexpected failures return HTTP `500`.

### 2.2 POST `/api/bazi/generate`

This route runs the full server workflow (DB writes, cards, stories). The request body is larger and mirrors the backend interface `GenerateBaziRequest`:

```json
{
  "name": "測試使用者",
  "birthday": "1992-05-12T14:35",
  "sex": "F",
  "location": "台北",
  "timezone": "Asia/Taipei",
  "options": {
    "debug": false,
    "useTrueSolarTime": true,
    "use_early_zi": false,
    "longitude": 121.5654,
    "flowType": "全細節"
  }
}
```

Response includes persisted IDs and the computed BaZi payload (see `API/routes/bazi.ts` for the exact shape). Only invoke this endpoint if the frontend needs the full narrative dataset or persistence.

## 3. UI Workflow Suggestions

1. **Collect user input**: name, gender, birthdate/time, location, true-solar-time toggle, longitude slider.
2. **Preview via `/api/bazi/compute`**: show pillars, anchors, and validation messages immediately.
3. **Persist via `/api/bazi/generate`**: after the user confirms, call the legacy endpoint and store returned IDs to reference detailed narratives.
4. **Error handling**: map HTTP 400 to form-level validation, show `message` from the response. HTTP 500 should render a fallback modal and encourage retry.

## 4. Testing Utilities

- `tests/api-shensha-integration.test.ts` and `tests/bazi-calculation.test.ts` illustrate expected server behavior.
- Use `scripts/self-test.mjs` before deployment to verify Railway readiness.

## 5. Future Hooks

- **API keys**: `API/routes/keys.ts` exposes endpoints for managing keys. When enabled, frontends should retrieve the key once, then attach it to every request header (`x-api-key`).
- **PDF exports**: `API/routes/report.ts` handles report generation. Plan for a separate download button once the route is stabilized.

## 6. Quick Checklist for Frontend Developers

- [ ] Configure `API_BASE` env variable.
- [ ] Implement `computeBazi` helper and wire it into forms.
- [ ] Validate user input before calling the API (datetime, numeric longitude).
- [ ] Keep error messages surfaced from the API.
- [ ] Add loading states; long narratives can take multiple seconds.
- [ ] Confirm with backend before using deprecated routes.

This guide will be updated as newer versions of the API are promoted to stable. Reach out to the backend team if additional contracts are needed.
