# Branch Protection Configuration

This document outlines the branch protection rules and policies implemented for the repository.

## Protected Branches

### Main Branch (`main`/`master`)
- ✅ **Force Push Protection**: Prevents force pushes to the main branch
- ✅ **Branch Deletion Protection**: Prevents accidental deletion of the branch
- ✅ **Pull Request Requirements**: All changes must go through pull requests
- ✅ **Status Check Requirements**: CI/CD pipeline must pass before merging
- ✅ **Code Review Requirements**: At least one review required from code owners

## Required Status Checks

The following checks must pass before merging:
- **CI/CD Pipeline**: Build, test, type-check, and lint validation
- **Railway Deployment Test**: Verify application starts and health checks pass
- **Code Quality Checks**: ESLint and TypeScript type checking

## Code Review Requirements

- **Minimum Reviews**: 1 review required from repository maintainers
- **Code Owners**: Reviews required from `@Madison-de-Chao` for core files
- **Stale Review Dismissal**: Stale reviews dismissed when new commits are pushed
- **Review Assignment**: Automatic assignment to code owners based on CODEOWNERS file

## Merge Restrictions

- **Linear History**: Merge commits and squash merging allowed
- **Admin Override**: Repository administrators can override protection rules in emergencies
- **Automated Merging**: Dependabot and other trusted bots can merge after reviews

## Enforcement

These protection rules are enforced through:
- GitHub branch protection settings
- GitHub Actions workflows (`.github/workflows/`)
- CODEOWNERS file (`.github/CODEOWNERS`)

## Configuration Files

- `.github/workflows/ci.yml` - Continuous integration pipeline
- `.github/workflows/deploy.yml` - Railway deployment automation
- `.github/CODEOWNERS` - Code ownership and review assignment

For technical implementation details, see the workflow files in `.github/workflows/`.