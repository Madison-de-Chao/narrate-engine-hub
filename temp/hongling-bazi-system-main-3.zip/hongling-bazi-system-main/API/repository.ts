import path from 'path'
import fs from 'fs'

// 型別：資料列（允許動態欄位）
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Row = Record<string, any>

// 嘗試載入 SQLite，可選依賴
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let sqlite: any = null
try {
  // 動態 require 以避免在未安裝 better-sqlite3 的部署環境出錯
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  sqlite = require('better-sqlite3')
} catch {
  // ignore – fallback to memory
}

// 預設資料庫路徑（可透過 DB_PATH 覆寫）
const DB_PATH: string = process.env.DB_PATH || path.join(process.cwd(), 'data', 'app.db')

interface IRepository {
  init(): void
  getInfo(): { backend: string; dbPath?: string; fileSize?: number }
  getStats(): Record<string, number>
  createUser(_data: { name: string; birthday: string; sex: string; location: string; timezone?: string }): { user_id: number }
  createChart(_user_id: number, _payload: Row): { chart_id: number }
  insertNayinCard(_chart_id: number, _row: Row): void
  insertShenshaCard(_chart_id: number, _row: Row): void
  insertStory(_chart_id: number, _row: Row): void
  insertArmyCard(_chart_id: number, _row: Row): void
  insertSkillCard(_chart_id: number, _row: Row): void
  getChart(_chart_id: number): { chart: Row | null, stories: Row[], nayins: Row[], shensha: Row[] }
  getChartsByUser(_user_id: number): Row[]
}

class MemoryRepo implements IRepository {
  private users: Row[] = []
  private charts: Row[] = []
  private nayins: Row[] = []
  private shensha: Row[] = []
  private stories: Row[] = []
  private army: Row[] = []
  private skills: Row[] = []
  private uid = 10000
  private cid = 5000
  private nid = 12000
  private sid = 13000
  private aid = 14000

  init(): void {}
  getInfo(): { backend: string } { return { backend: 'memory' } }
  getStats(): Record<string, number> {
    return {
      users: this.users.length,
      charts: this.charts.length,
      nayin_cards: this.nayins.length,
      shensha_cards: this.shensha.length,
      stories: this.stories.length,
      army_cards: this.army.length,
      skill_cards: this.skills.length
    }
  }

  createUser(d: Row): { user_id: number } {
    const id = ++this.uid
    this.users.push({ user_id: id, ...d })
    return { user_id: id }
  }

  createChart(user_id: number, p: Row): { chart_id: number } {
    const id = ++this.cid
    this.charts.push({ chart_id: id, user_id, ...p })
    return { chart_id: id }
  }

  insertNayinCard(chart_id: number, r: Row): void {
    this.nayins.push({ nayin_id: ++this.nid, chart_id, ...r })
  }
  insertShenshaCard(chart_id: number, r: Row): void {
    this.shensha.push({ shensha_id: ++this.sid, chart_id, ...r })
  }
  insertStory(chart_id: number, r: Row): void {
    this.stories.push({ story_id: ++this.aid, chart_id, ...r })
  }
  insertArmyCard(chart_id: number, r: Row): void {
    this.army.push({ card_id: ++this.sid, chart_id, ...r })
  }
  insertSkillCard(chart_id: number, r: Row): void {
    this.skills.push({ skill_id: ++this.sid, chart_id, ...r })
  }

  getChart(chart_id: number): { chart: Row | null, stories: Row[], nayins: Row[], shensha: Row[] } {
    const chart = this.charts.find(x => x.chart_id === chart_id) || null
    const stories = this.stories.filter(x => x.chart_id === chart_id)
    const nayins = this.nayins.filter(x => x.chart_id === chart_id)
    const shensha = this.shensha.filter(x => x.chart_id === chart_id)
    return { chart, stories, nayins, shensha }
  }

  getChartsByUser(user_id: number): Row[] {
    return this.charts
      .filter(x => x.user_id === user_id)
      .sort((a, b) => b.chart_id - a.chart_id)
  }
}

class SqliteRepo implements IRepository {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private db: any

  constructor() {
    const dir = path.dirname(DB_PATH)
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true })
    }
    this.db = new sqlite(DB_PATH)
    this.db.pragma('journal_mode = WAL')
  }

  init(): void {
    this.db.exec(`
CREATE TABLE IF NOT EXISTS user_profile (
  user_id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT, birthday TEXT, sex TEXT, location TEXT, timezone TEXT,
  create_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS bazi_chart (
  chart_id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  year_gan TEXT, year_zhi TEXT, month_gan TEXT, month_zhi TEXT,
  day_gan TEXT, day_zhi TEXT, hour_gan TEXT, hour_zhi TEXT,
  year_nayin TEXT, month_nayin TEXT, day_nayin TEXT, hour_nayin TEXT,
  year_hidden_gan TEXT, month_hidden_gan TEXT, day_hidden_gan TEXT, hour_hidden_gan TEXT,
  chart_json TEXT, create_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS bazi_nayin_card (
  nayin_id INTEGER PRIMARY KEY AUTOINCREMENT, chart_id INTEGER,
  pillar TEXT, nayin_name TEXT, element TEXT, scene TEXT,
  buff TEXT, debuff TEXT, color TEXT, create_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS bazi_shensha_card (
  shensha_id INTEGER PRIMARY KEY AUTOINCREMENT, chart_id INTEGER,
  pillar TEXT, shensha_name TEXT, type TEXT, trigger TEXT,
  buff TEXT, debuff TEXT, color TEXT, card_json TEXT, create_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS bazi_ai_story (
  story_id INTEGER PRIMARY KEY AUTOINCREMENT, chart_id INTEGER,
  army_type TEXT, story_type TEXT, story_text TEXT, summary TEXT,
  create_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS bazi_army_card (
  card_id INTEGER PRIMARY KEY AUTOINCREMENT, chart_id INTEGER,
  army_type TEXT, role_type TEXT, gan_or_zhi TEXT, canggan TEXT,
  main_buff TEXT, main_debuff TEXT, rpg_job TEXT, color TEXT,
  card_json TEXT, create_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS bazi_skill_card (
  skill_id INTEGER PRIMARY KEY AUTOINCREMENT, chart_id INTEGER,
  skill_type TEXT, main_skill TEXT, skill_buff TEXT, skill_debuff TEXT,
  detail_json TEXT, create_at TEXT DEFAULT (datetime('now'))
);`)
  }

  getInfo(): { backend: string; dbPath: string; fileSize?: number } {
    let fileSize: number | undefined
    try {
      const st = fs.statSync(DB_PATH)
      fileSize = st.size
    } catch {
      // ignore
    }
    return { backend: 'sqlite', dbPath: DB_PATH, fileSize }
  }

  getStats(): Record<string, number> {
    // Individual lightweight COUNT queries (better-sqlite3 is synchronous & fast for this scale)
    const count = (table: string): number => {
      try {
        return Number(this.db.prepare(`SELECT COUNT(*) as c FROM ${table}`).get().c) || 0
      } catch {
        return 0
      }
    }
    return {
      users: count('user_profile'),
      charts: count('bazi_chart'),
      nayin_cards: count('bazi_nayin_card'),
      shensha_cards: count('bazi_shensha_card'),
      stories: count('bazi_ai_story'),
      army_cards: count('bazi_army_card'),
      skill_cards: count('bazi_skill_card')
    }
  }

  createUser(d: Row): { user_id: number } {
    const st = this.db.prepare('INSERT INTO user_profile(name,birthday,sex,location,timezone) VALUES (?,?,?,?,?)')
    const r = st.run(d.name, d.birthday, d.sex, d.location, d.timezone || '+08:00')
    return { user_id: Number(r.lastInsertRowid) }
  }

  createChart(user_id: number, p: Row): { chart_id: number } {
    const ks = Object.keys(p)
    const placeholders = ['?'].concat(ks.map(() => '?')).join(',')
    const st = this.db.prepare(`INSERT INTO bazi_chart(user_id,${ks.join(',')}) VALUES (${placeholders})`)
    const r = st.run(user_id, ...ks.map(k => p[k]))
    return { chart_id: Number(r.lastInsertRowid) }
  }

  insertNayinCard(chart_id: number, r: Row): void {
    const ks = Object.keys(r)
    const placeholders = ['?'].concat(ks.map(() => '?')).join(',')
    const st = this.db.prepare(`INSERT INTO bazi_nayin_card(chart_id,${ks.join(',')}) VALUES (${placeholders})`)
    st.run(chart_id, ...ks.map(k => r[k]))
  }
  insertShenshaCard(chart_id: number, r: Row): void {
    const ks = Object.keys(r)
    const placeholders = ['?'].concat(ks.map(() => '?')).join(',')
    const st = this.db.prepare(`INSERT INTO bazi_shensha_card(chart_id,${ks.join(',')}) VALUES (${placeholders})`)
    st.run(chart_id, ...ks.map(k => r[k]))
  }
  insertStory(chart_id: number, r: Row): void {
    const ks = Object.keys(r)
    const placeholders = ['?'].concat(ks.map(() => '?')).join(',')
    const st = this.db.prepare(`INSERT INTO bazi_ai_story(chart_id,${ks.join(',')}) VALUES (${placeholders})`)
    st.run(chart_id, ...ks.map(k => r[k]))
  }
  insertArmyCard(chart_id: number, r: Row): void {
    const ks = Object.keys(r)
    const placeholders = ['?'].concat(ks.map(() => '?')).join(',')
    const st = this.db.prepare(`INSERT INTO bazi_army_card(chart_id,${ks.join(',')}) VALUES (${placeholders})`)
    st.run(chart_id, ...ks.map(k => r[k]))
  }
  insertSkillCard(chart_id: number, r: Row): void {
    const ks = Object.keys(r)
    const placeholders = ['?'].concat(ks.map(() => '?')).join(',')
    const st = this.db.prepare(`INSERT INTO bazi_skill_card(chart_id,${ks.join(',')}) VALUES (${placeholders})`)
    st.run(chart_id, ...ks.map(k => r[k]))
  }

  getChart(chart_id: number): { chart: Row | null, stories: Row[], nayins: Row[], shensha: Row[] } {
    const chart = this.db.prepare('SELECT * FROM bazi_chart WHERE chart_id=?').get(chart_id) || null
    const stories = this.db.prepare('SELECT * FROM bazi_ai_story WHERE chart_id=?').all(chart_id)
    const nayins = this.db.prepare('SELECT * FROM bazi_nayin_card WHERE chart_id=?').all(chart_id)
    const shensha = this.db.prepare('SELECT * FROM bazi_shensha_card WHERE chart_id=?').all(chart_id)
    return { chart, stories, nayins, shensha }
  }

  getChartsByUser(user_id: number): Row[] {
    return this.db.prepare('SELECT * FROM bazi_chart WHERE user_id=? ORDER BY chart_id DESC').all(user_id)
  }
}

const repo: IRepository = sqlite ? new SqliteRepo() : new MemoryRepo()
repo.init()

export default repo
export const repoInfo = (): { backend: string; dbPath?: string; fileSize?: number } => repo.getInfo()
export const repoStats = (): Record<string, number> => repo.getStats()
