import crypto from 'crypto'

export interface AIProvider {
  name: string
  displayName: string
  description: string
  supportedTypes: string[]
  status: 'active' | 'inactive' | 'maintenance'
  baseUrl?: string
  headers?: Record<string, string>
}

export interface AIKey {
  keyId: string
  provider: string
  service: string
  encryptedKey: string
  status: 'valid' | 'invalid' | 'expired' | 'suspended'
  createdAt: string
  expiresAt?: string
  usageCount: number
  lastUsedAt?: string
  metadata?: Record<string, any>
}

export interface KeyUsageLog {
  keyId: string
  provider: string
  service: string
  requestType: string
  tokensUsed?: number
  cost?: number
  timestamp: string
  success: boolean
  error?: string
  metadata?: Record<string, any>
}

/**
 * AIKeyManager - 集中管理多家AI API Key
 * 支援自動切換、加密儲存、熱更新
 */
export class AIKeyManager {
  private keys: Map<string, AIKey> = new Map()
  private providers: Map<string, AIProvider> = new Map()
  private usageLogs: KeyUsageLog[] = []
  private encryptionKey: string

  constructor(encryptionKey?: string) {
    this.encryptionKey = encryptionKey || process.env.AI_KEY_ENCRYPTION_SECRET || 'default-secret-key'
    this.initializeProviders()
  }

  private initializeProviders(): void {
    const defaultProviders: AIProvider[] = [
      {
        name: 'openai',
        displayName: 'OpenAI GPT',
        description: 'OpenAI GPT 模型驅動的故事生成',
        supportedTypes: ['army-narrative', 'fortune-analysis', 'life-prediction'],
        status: 'active',
        baseUrl: 'https://api.openai.com/v1'
      },
      {
        name: 'claude',
        displayName: 'Claude AI',
        description: 'Anthropic Claude 模型驅動的故事生成',
        supportedTypes: ['army-narrative', 'fortune-analysis', 'life-prediction'],
        status: 'inactive',
        baseUrl: 'https://api.anthropic.com/v1'
      },
      {
        name: 'gemini',
        displayName: 'Google Gemini',
        description: 'Google Gemini 模型驅動的故事生成',
        supportedTypes: ['army-narrative', 'fortune-analysis', 'life-prediction'],
        status: 'inactive'
      },
      {
        name: 'azure',
        displayName: 'Azure OpenAI',
        description: 'Azure OpenAI 服務驅動的故事生成',
        supportedTypes: ['army-narrative', 'fortune-analysis', 'life-prediction'],
        status: 'inactive'
      },
      {
        name: 'local',
        displayName: '本地故事引擎',
        description: '使用內建的故事生成邏輯',
        supportedTypes: ['army-narrative'],
        status: 'active'
      }
    ]

    defaultProviders.forEach(provider => {
      this.providers.set(provider.name, provider)
    })
  }

  /**
   * 加密API Key
   */
  private encryptKey(key: string): string {
    const cipher = crypto.createCipher('aes256', this.encryptionKey)
    let encrypted = cipher.update(key, 'utf8', 'hex')
    encrypted += cipher.final('hex')
    return encrypted
  }

  /**
   * 解密API Key
   */
  private decryptKey(encryptedKey: string): string {
    try {
      const decipher = crypto.createDecipher('aes256', this.encryptionKey)
      let decrypted = decipher.update(encryptedKey, 'hex', 'utf8')
      decrypted += decipher.final('utf8')
      return decrypted
    } catch (error) {
      console.error('Failed to decrypt API key:', error)
      throw new Error('Invalid encrypted key')
    }
  }

  /**
   * 註冊和驗證API Key
   */
  async registerKey(
    apiKey: string,
    provider: string,
    service: string = 'story-generation',
    metadata?: Record<string, any>
  ): Promise<string> {
    // 基本格式驗證
    if (!this.validateKeyFormat(apiKey, provider)) {
      throw new Error(`Invalid API key format for provider: ${provider}`)
    }

    // 生成keyId
    const keyId = `key_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`

    // 加密存儲
    const encryptedKey = this.encryptKey(apiKey)

    const keyData: AIKey = {
      keyId,
      provider,
      service,
      encryptedKey,
      status: 'valid', // 在實際實現中會進行真實驗證
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24小時
      usageCount: 0,
      metadata
    }

    this.keys.set(keyId, keyData)

    console.log(`✅ API Key registered: ${keyId} for ${provider}`)
    return keyId
  }

  /**
   * 驗證API Key格式
   */
  private validateKeyFormat(apiKey: string, provider: string): boolean {
    const patterns: Record<string, RegExp> = {
      openai: /^sk-[a-zA-Z0-9]{20,}$/,
      claude: /^sk-ant-[a-zA-Z0-9-]{20,}$/,
      gemini: /^[a-zA-Z0-9_-]{20,}$/,
      azure: /^[a-zA-Z0-9]{32}$/,
      local: /^test-[a-zA-Z0-9]{8,}$/
    }

    const pattern = patterns[provider]
    if (!pattern) {
      // 對於未知provider，使用通用驗證
      return apiKey.length >= 10
    }

    return pattern.test(apiKey)
  }

  /**
   * 獲取API Key狀態
   */
  getKeyStatus(keyId: string): AIKey | null {
    const key = this.keys.get(keyId)
    if (!key) return null

    // 檢查是否過期
    if (key.expiresAt && new Date() > new Date(key.expiresAt)) {
      key.status = 'expired'
      this.keys.set(keyId, key)
    }

    // 返回不包含解密密鑰的副本
    return {
      ...key,
      encryptedKey: '[ENCRYPTED]'
    }
  }

  /**
   * 獲取可用的API Key用於指定provider
   */
  getAvailableKey(provider: string, service: string = 'story-generation'): AIKey | null {
    for (const [keyId, key] of this.keys) {
      if (
        key.provider === provider &&
        key.service === service &&
        key.status === 'valid' &&
        (!key.expiresAt || new Date() < new Date(key.expiresAt))
      ) {
        return key
      }
    }
    return null
  }

  /**
   * 記錄API Key使用情況
   */
  logKeyUsage(
    keyId: string,
    requestType: string,
    success: boolean,
    tokensUsed?: number,
    cost?: number,
    error?: string,
    metadata?: Record<string, any>
  ): void {
    const key = this.keys.get(keyId)
    if (!key) return

    // 更新使用計數
    key.usageCount += 1
    key.lastUsedAt = new Date().toISOString()
    this.keys.set(keyId, key)

    // 記錄使用日誌
    const logEntry: KeyUsageLog = {
      keyId,
      provider: key.provider,
      service: key.service,
      requestType,
      tokensUsed,
      cost,
      timestamp: new Date().toISOString(),
      success,
      error,
      metadata
    }

    this.usageLogs.push(logEntry)

    // 保持日誌大小合理（最多保留1000條）
    if (this.usageLogs.length > 1000) {
      this.usageLogs = this.usageLogs.slice(-1000)
    }
  }

  /**
   * 撤銷API Key
   */
  revokeKey(keyId: string): boolean {
    const key = this.keys.get(keyId)
    if (!key) return false

    key.status = 'suspended'
    this.keys.set(keyId, key)

    console.log(`🚫 API Key revoked: ${keyId}`)
    return true
  }

  /**
   * 獲取所有可用的AI提供商
   */
  getProviders(): AIProvider[] {
    return Array.from(this.providers.values())
  }

  /**
   * 獲取指定provider的配置
   */
  getProvider(name: string): AIProvider | null {
    return this.providers.get(name) || null
  }

  /**
   * 熱更新provider配置
   */
  updateProvider(name: string, updates: Partial<AIProvider>): boolean {
    const provider = this.providers.get(name)
    if (!provider) return false

    const updatedProvider = { ...provider, ...updates }
    this.providers.set(name, updatedProvider)

    console.log(`🔄 Provider updated: ${name}`)
    return true
  }

  /**
   * 獲取使用統計
   */
  getUsageStats(keyId?: string): {
    totalRequests: number
    successfulRequests: number
    totalTokensUsed: number
    totalCost: number
    recentErrors: string[]
  } {
    const relevantLogs = keyId
      ? this.usageLogs.filter(log => log.keyId === keyId)
      : this.usageLogs

    const totalRequests = relevantLogs.length
    const successfulRequests = relevantLogs.filter(log => log.success).length
    const totalTokensUsed = relevantLogs.reduce((sum, log) => sum + (log.tokensUsed || 0), 0)
    const totalCost = relevantLogs.reduce((sum, log) => sum + (log.cost || 0), 0)
    const recentErrors = relevantLogs
      .filter(log => !log.success && log.error)
      .slice(-10)
      .map(log => log.error!)

    return {
      totalRequests,
      successfulRequests,
      totalTokensUsed,
      totalCost,
      recentErrors
    }
  }

  /**
   * 自動切換到可用的API Key
   */
  async autoSwitchKey(provider: string, failedKeyId: string): Promise<string | null> {
    // 標記失敗的key
    const failedKey = this.keys.get(failedKeyId)
    if (failedKey) {
      failedKey.status = 'invalid'
      this.keys.set(failedKeyId, failedKey)
    }

    // 尋找同一provider的其他可用key
    const availableKey = this.getAvailableKey(provider)
    if (availableKey) {
      console.log(`🔄 Auto-switched from ${failedKeyId} to ${availableKey.keyId}`)
      return availableKey.keyId
    }

    console.warn(`⚠️ No available keys for provider: ${provider}`)
    return null
  }

  /**
   * 獲取解密的API Key（僅內部使用）
   */
  getDecryptedKey(keyId: string): string | null {
    const key = this.keys.get(keyId)
    if (!key || key.status !== 'valid') return null

    try {
      return this.decryptKey(key.encryptedKey)
    } catch (error) {
      console.error(`Failed to decrypt key ${keyId}:`, error)
      return null
    }
  }

  /**
   * 清理過期的keys和日誌
   */
  cleanup(): void {
    const now = new Date()

    // 清理過期的keys
    for (const [keyId, key] of this.keys) {
      if (key.expiresAt && now > new Date(key.expiresAt)) {
        key.status = 'expired'
        this.keys.set(keyId, key)
      }
    }

    // 清理舊日誌（保留最近7天）
    const cutoffDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
    this.usageLogs = this.usageLogs.filter(log => new Date(log.timestamp) > cutoffDate)

    console.log('🧹 Cleanup completed')
  }
}

// 單例實例
export const aiKeyManager = new AIKeyManager()