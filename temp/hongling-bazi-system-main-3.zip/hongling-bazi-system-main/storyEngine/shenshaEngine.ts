/**
 * 神煞規則引擎 (ShenSha Rule Engine)
 * 根據JSON規則檔案計算神煞，支援完整的證據鏈追蹤
 */

import * as fs from "fs";
import * as path from "path";

// 天干地支常量
const TIAN_GAN = ["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"];
const DI_ZHI = [
  "子",
  "丑",
  "寅",
  "卯",
  "辰",
  "巳",
  "午",
  "未",
  "申",
  "酉",
  "戌",
  "亥",
];

export interface ShenshaRule {
  anchor:
    | "dayStem"
    | "yearBranch"
    | "monthBranch"
    | "dayBranch"
    | "hourBranch"
    | "anyBranch"
    | "combo";
  rule_ref: string;
  table?: Record<string, string[]>;
  combo?: Array<{
    anchor:
      | "dayStem"
      | "yearBranch"
      | "monthBranch"
      | "dayBranch"
      | "hourBranch";
    in: string[];
    target: "year" | "month" | "day" | "hour" | "any";
    any?: boolean;
  }>;
  notes?: string;
}

export interface ShenshaDefinition {
  name: string;
  enabled: boolean;
  priority: number;
  rules: ShenshaRule[];
}

export interface BaziChart {
  year: { stem: string; branch: string };
  month: { stem: string; branch: string };
  day: { stem: string; branch: string };
  hour: { stem: string; branch: string };
}

export interface ShenshaMatch {
  name: string;
  anchor_basis: string;
  why_matched: string;
  rule_ref: string;
  priority: number;
}

export class ShenshaEngine {
  private shenshaDefinitions: Map<string, ShenshaDefinition> = new Map();
  private ruleset: "trad" | "legion" = "trad";

  constructor(ruleset: "trad" | "legion" = "trad") {
    this.ruleset = ruleset;
    this.loadShenshaDefinitions();
  }

  /**
   * 載入指定ruleset的所有神煞定義
   */
  private loadShenshaDefinitions() {
    const dataDir = path.join(__dirname, "data", `shensha_${this.ruleset}`);

    if (!fs.existsSync(dataDir)) {
      throw new Error(`ShenSha data directory not found: ${dataDir}`);
    }

    const files = fs.readdirSync(dataDir).filter((f) => f.endsWith(".json"));

    for (const file of files) {
      try {
        const filePath = path.join(dataDir, file);
        const content = fs.readFileSync(filePath, "utf8");
        const def: ShenshaDefinition = JSON.parse(content);

        if (def.enabled) {
          this.shenshaDefinitions.set(def.name, def);
        }
      } catch (error) {
        console.error(`Error loading shensha file ${file}:`, error);
      }
    }
  }

  /**
   * 計算給定八字的所有神煞
   */
  calculate(chart: BaziChart): ShenshaMatch[] {
    const matches: ShenshaMatch[] = [];

    // 按priority排序處理
    const sortedDefinitions = Array.from(this.shenshaDefinitions.values()).sort(
      (a, b) => a.priority - b.priority,
    );

    for (const def of sortedDefinitions) {
      for (const rule of def.rules) {
        const match = this.evaluateRule(def, rule, chart);
        if (match) {
          matches.push(match);
          break; // 一個神煞只需命中一次
        }
      }
    }

    return matches;
  }

  /**
   * 評估單一規則
   */
  private evaluateRule(
    def: ShenshaDefinition,
    rule: ShenshaRule,
    chart: BaziChart,
  ): ShenshaMatch | null {
    if (rule.anchor === "combo") {
      return this.evaluateComboRule(def, rule, chart);
    }

    if (rule.anchor === "anyBranch") {
      return this.evaluateAnyBranchRule(def, rule, chart);
    }

    return this.evaluateTableRule(def, rule, chart);
  }

  /**
   * 評估表格規則（dayStem, yearBranch, monthBranch, dayBranch, hourBranch）
   */
  private evaluateTableRule(
    def: ShenshaDefinition,
    rule: ShenshaRule,
    chart: BaziChart,
  ): ShenshaMatch | null {
    if (!rule.table) return null;

    let anchorValue: string = "";
    let anchorDescription: string = "";

    switch (rule.anchor) {
      case "dayStem":
        anchorValue = chart.day.stem;
        anchorDescription = `日干=${anchorValue}`;
        break;
      case "yearBranch":
        anchorValue = chart.year.branch;
        anchorDescription = `年支=${anchorValue}`;
        break;
      case "monthBranch":
        anchorValue = chart.month.branch;
        anchorDescription = `月支=${anchorValue}`;
        break;
      case "dayBranch":
        anchorValue = chart.day.branch;
        anchorDescription = `日支=${anchorValue}`;
        break;
      case "hourBranch":
        anchorValue = chart.hour.branch;
        anchorDescription = `時支=${anchorValue}`;
        break;
      default:
        return null;
    }

    const targetBranches = rule.table[anchorValue];
    if (!targetBranches || targetBranches.length === 0) {
      return null;
    }

    // 檢查四柱任一地支是否在目標集合中
    const allBranches = [
      { name: "年支", value: chart.year.branch },
      { name: "月支", value: chart.month.branch },
      { name: "日支", value: chart.day.branch },
      { name: "時支", value: chart.hour.branch },
    ];

    for (const branch of allBranches) {
      if (targetBranches.includes(branch.value)) {
        return {
          name: def.name,
          anchor_basis: anchorDescription,
          why_matched: `查表得[${targetBranches.join(",")}]，四柱${branch.name}=${branch.value}命中`,
          rule_ref: rule.rule_ref,
          priority: def.priority,
        };
      }
    }

    return null;
  }

  /**
   * 評估anyBranch規則（支對支互見）
   */
  private evaluateAnyBranchRule(
    def: ShenshaDefinition,
    rule: ShenshaRule,
    chart: BaziChart,
  ): ShenshaMatch | null {
    if (!rule.table) return null;

    const allBranches = [
      chart.year.branch,
      chart.month.branch,
      chart.day.branch,
      chart.hour.branch,
    ];

    for (let i = 0; i < allBranches.length; i++) {
      const branch = allBranches[i];
      const targetBranches = rule.table[branch];

      if (targetBranches && targetBranches.length > 0) {
        // 檢查是否有其他支在目標集合中
        for (let j = 0; j < allBranches.length; j++) {
          if (i !== j && targetBranches.includes(allBranches[j])) {
            const pillarNames = ["年", "月", "日", "時"];
            return {
              name: def.name,
              anchor_basis: `${pillarNames[i]}支=${branch}`,
              why_matched: `互見：${pillarNames[i]}支=${branch}對應[${targetBranches.join(",")}]，${pillarNames[j]}支=${allBranches[j]}命中`,
              rule_ref: rule.rule_ref,
              priority: def.priority,
            };
          }
        }
      }
    }

    return null;
  }

  /**
   * 評估combo規則（多條件AND）
   */
  private evaluateComboRule(
    def: ShenshaDefinition,
    rule: ShenshaRule,
    chart: BaziChart,
  ): ShenshaMatch | null {
    if (!rule.combo || rule.combo.length === 0) return null;

    const conditions: string[] = [];
    let allMatched = true;

    for (const condition of rule.combo) {
      let pillarValue: string = "";
      let pillarName: string = "";

      switch (condition.target) {
        case "year":
          if (condition.anchor.endsWith("Branch")) {
            pillarValue = chart.year.branch;
            pillarName = "年支";
          } else {
            pillarValue = chart.year.stem;
            pillarName = "年干";
          }
          break;
        case "month":
          if (condition.anchor.endsWith("Branch")) {
            pillarValue = chart.month.branch;
            pillarName = "月支";
          } else {
            pillarValue = chart.month.stem;
            pillarName = "月干";
          }
          break;
        case "day":
          if (condition.anchor.endsWith("Branch")) {
            pillarValue = chart.day.branch;
            pillarName = "日支";
          } else {
            pillarValue = chart.day.stem;
            pillarName = "日干";
          }
          break;
        case "hour":
          if (condition.anchor.endsWith("Branch")) {
            pillarValue = chart.hour.branch;
            pillarName = "時支";
          } else {
            pillarValue = chart.hour.stem;
            pillarName = "時干";
          }
          break;
        case "any":
          // any目標需要檢查所有柱
          const anyMatched = this.checkAnyTarget(condition, chart);
          if (!anyMatched) {
            allMatched = false;
            break;
          } else {
            conditions.push("任一柱符合");
          }
          continue;
      }

      if (condition.in.includes(pillarValue)) {
        conditions.push(
          `${pillarName}=${pillarValue}∈[${condition.in.join(",")}]`,
        );
      } else {
        allMatched = false;
        break;
      }
    }

    if (allMatched) {
      return {
        name: def.name,
        anchor_basis: "combo",
        why_matched: `複合條件：${conditions.join(" AND ")}`,
        rule_ref: rule.rule_ref,
        priority: def.priority,
      };
    }

    return null;
  }

  /**
   * 檢查any目標條件
   */
  private checkAnyTarget(
    condition: { anchor: string; in: string[] },
    chart: BaziChart,
  ): boolean {
    const values: string[] = [];

    if (condition.anchor.endsWith("Branch")) {
      values.push(
        chart.year.branch,
        chart.month.branch,
        chart.day.branch,
        chart.hour.branch,
      );
    } else {
      values.push(
        chart.year.stem,
        chart.month.stem,
        chart.day.stem,
        chart.hour.stem,
      );
    }

    return values.some((v) => condition.in.includes(v));
  }

  /**
   * 獲取當前ruleset
   */
  getRuleset(): string {
    return this.ruleset;
  }

  /**
   * 獲取已載入的神煞數量
   */
  getLoadedCount(): number {
    return this.shenshaDefinitions.size;
  }

  /**
   * 獲取所有已載入的神煞名稱
   */
  getLoadedNames(): string[] {
    return Array.from(this.shenshaDefinitions.keys());
  }
}

export default ShenshaEngine;
