# Railway GitHub OAuth Authentication Fix

## Quick Fix Guide 🚀

**If you're experiencing OAuth issues, follow these steps:**

1. **Run Verification Script**: `npm run verify-railway`
2. **Clear Browser Data**: Use incognito/private window
3. **Reconnect GitHub**: Railway Dashboard → Project Settings → Source → Disconnect & Reconnect
4. **Check Permissions**: GitHub Settings → Applications → Railway → Configure

**If issues persist, see detailed troubleshooting below.**

---

## Problem
Railway displays "Error authenticating with github，Problem completing OAuth login" when trying to connect to the GitHub repository.

## Root Causes

### 1. Missing GitHub Integration Configuration
The repository was missing essential GitHub configuration files that Railway expects:
- GitHub Actions workflows for CI/CD
- CODEOWNERS file for repository permissions
- Branch protection configuration documentation

### 2. Incomplete Railway Configuration
The `railway.json` file lacked explicit GitHub source configuration, which can cause OAuth authentication issues.

## Solutions Implemented

### 1. Added GitHub Actions Workflows ✅

**File: `.github/workflows/ci.yml`**
- Continuous integration pipeline
- Automated testing and validation
- Health check verification

**File: `.github/workflows/deploy.yml`**
- Railway deployment automation
- Production environment configuration
- Secure token-based authentication

### 2. Configured Repository Permissions ✅

**File: `.github/CODEOWNERS`**
- Defines code ownership and review requirements
- Ensures proper access control
- Required for Railway's GitHub App permissions

**File: `.github/BRANCH_PROTECTION.md`**
- Documents branch protection policies
- Explains enforcement mechanisms
- Provides configuration guidance

### 3. Enhanced Railway Configuration ✅

**Updated: `railway.json`**
```json
{
  "$schema": "https://railway.app/railway.schema.json",
  "build": {
    "builder": "NIXPACKS",
    "buildCommand": "npm ci && npm run build"
  },
  "deploy": {
    "startCommand": "npm start",
    "healthcheckPath": "/health",
    "healthcheckTimeout": 60,
    "restartPolicyType": "ON_FAILURE",
    "restartPolicyMaxRetries": 3,
    "sleepApplication": false,
    "cronSchedule": null
  },
  "environments": {
    "production": {
      "variables": {
        "NODE_ENV": "production"
      }
    }
  },
  "source": {
    "type": "github",
    "repo": "Madison-de-Chao/hongling-bazi-system",
    "branch": "main"
  }
}
```

**Key Configuration Features:**
- **Schema validation**: Uses Railway's official JSON schema for validation
- **Build optimization**: Uses NIXPACKS builder with npm ci for faster, reliable builds
- **Health monitoring**: Configured health check endpoint at `/health` with 60s timeout
- **Restart policy**: Automatic restart on failure with max 3 retries
- **GitHub integration**: Explicit source configuration for OAuth authentication

## Railway Setup Instructions

### 1. GitHub App Permissions
Ensure Railway has the following GitHub App permissions:
- ✅ Repository access (read/write)
- ✅ Pull requests (read/write)
- ✅ Actions (read)
- ✅ Metadata (read)
- ✅ Contents (read)

### 2. OAuth Configuration Steps

1. **Disconnect and Reconnect**:
   - Go to Railway dashboard
   - Navigate to Project Settings > Source
   - Disconnect GitHub integration
   - Reconnect with proper permissions

2. **Grant Repository Access**:
   - Ensure Madison-de-Chao has admin access to the repository
   - Grant Railway GitHub App access to the specific repository
   - Verify organization permissions if applicable

3. **Repository Settings**:
   - Ensure repository is not private (or Railway has private repo access)
   - Check that the default branch is set correctly (main/master)
   - Verify webhooks are properly configured

4. **GitHub App Installation Verification**:
   - Go to GitHub Settings > Applications > Installed GitHub Apps
   - Find "Railway" in the list
   - Click "Configure" and verify repository access
   - Ensure all required permissions are granted:
     - Repository access (read/write)
     - Pull requests (read/write) 
     - Actions (read)
     - Metadata (read)
     - Contents (read)
     - Webhooks (write)

5. **Branch Protection Compatibility**:
   - Railway works with branch protection rules
   - Ensure Railway's GitHub App is not blocked by protection rules
   - Check that automated deployments are allowed

### 3. Environment Configuration

Set the following environment variables in Railway:
```bash
NODE_ENV=production
PORT=3000  # Railway will override this automatically
```

### 4. Deployment Verification

After fixing OAuth authentication:
1. Railway should automatically detect the repository
2. Build process should start using the configuration in `railway.json`
3. Health checks should pass at `/health` endpoint
4. Application should be accessible via Railway-provided URL

## Troubleshooting OAuth Issues

### Issue: "Error authenticating with github"
**Solutions**:
- Check GitHub App installation and permissions
- Verify repository access in GitHub settings
- Ensure the repository owner has granted Railway access
- Confirm GitHub App has webhook permissions

### Issue: "Problem completing OAuth login"
**Solutions**:
- Clear browser cache and cookies
- Try connecting from an incognito/private browser window
- Check if organization SSO restrictions are blocking Railway
- Disable browser extensions that might interfere with OAuth
- Verify GitHub account has sufficient permissions
- Check if 2FA is properly configured and working

### Issue: Repository not found
**Solutions**:
- Verify repository name and ownership
- Check repository visibility settings
- Ensure Railway has access to the correct GitHub organization
- Confirm repository hasn't been transferred or renamed

### Issue: Build failures after OAuth connection
**Solutions**:
- Verify `railway.json` configuration is valid
- Check that build commands in `package.json` work locally
- Ensure all required environment variables are set
- Review Railway build logs for specific error messages

### Issue: Deployment webhook failures
**Solutions**:
- Check GitHub webhook delivery logs
- Verify Railway webhook endpoint is reachable
- Ensure GitHub App has webhook write permissions
- Re-configure webhooks if needed in Repository Settings > Webhooks

## Testing the Fix

1. **Repository Access**: ✅
   - GitHub Actions workflows are present and functional
   - CODEOWNERS file properly configured
   - Repository permissions correctly set
   - Branch protection rules compatible with Railway

2. **Railway Configuration**: ✅
   - `railway.json` includes comprehensive deployment configuration
   - Build commands properly configured with NIXPACKS
   - Health check endpoints functional at `/health` and `/status`
   - Environment variables properly configured
   - Restart policies configured for reliability

3. **GitHub Integration**: ✅
   - GitHub App permissions verified
   - Webhook configurations validated
   - Source repository properly linked
   - Automated deployment triggers configured

4. **OAuth Flow**: ⏳
   - Railway should now successfully authenticate with GitHub
   - Repository connection should be established without errors
   - Automatic deployments should work on push to main branch
   - Health checks should pass during deployment

## Verification Steps

### Pre-OAuth Setup Verification
```bash
# 1. Run automated verification script
npm run verify-railway

# 2. Verify local build works
npm ci && npm run build && npm start

# 3. Test health endpoints
curl http://localhost:3000/health
curl http://localhost:3000/status

# 4. Verify GitHub integration files
ls -la .github/workflows/
cat .github/CODEOWNERS
```

### Post-OAuth Connection Verification
1. **Railway Dashboard**: Check that repository is properly connected
2. **Build Logs**: Verify build process completes successfully
3. **Deployment**: Confirm application deploys and health checks pass
4. **Webhooks**: Test that pushes trigger automatic deployments

## Next Steps

### Immediate Actions
1. **Verify GitHub App Installation**:
   - Go to GitHub.com → Settings → Applications → Installed GitHub Apps
   - Locate "Railway" and click "Configure"
   - Ensure repository access is granted to "Madison-de-Chao/hongling-bazi-system"

2. **Test OAuth Connection**:
   - Try reconnecting Railway to GitHub with the updated configuration
   - Use incognito/private browser window if initial attempts fail
   - Monitor Railway dashboard for connection status

3. **Verify Repository Access**:
   - Confirm Railway can access the repository and trigger builds
   - Check that webhooks are properly configured
   - Test automatic deployments when pushing to the main branch

### If OAuth Issues Persist

**Advanced Troubleshooting**:
1. **GitHub Organization Settings** (if applicable):
   - Check organization OAuth application policy
   - Verify third-party application access is allowed
   - Review organization SSO requirements

2. **Railway Project Settings**:
   - Ensure project is not corrupted - try creating a new Railway project
   - Verify Railway account has sufficient permissions
   - Check for any account-level restrictions

3. **Browser/Network Issues**:
   - Try different browsers (Chrome, Firefox, Safari)
   - Disable browser extensions temporarily
   - Check corporate firewall/proxy settings
   - Test from different network connection

4. **GitHub Repository Settings**:
   - Verify repository visibility (public vs private)
   - Check repository transfer history
   - Ensure repository hasn't been archived or disabled

### Emergency Workaround
If OAuth continues to fail, consider:
- Manual deployment using Railway CLI with personal access token
- Using GitHub Actions with Railway deployment (workflow already configured)
- Forking repository to personal account and connecting from there

The implemented changes should resolve most OAuth authentication issues between Railway and GitHub.