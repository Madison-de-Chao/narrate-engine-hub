const { Pool } = require('pg')

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
})

class PostgresRepo {
  constructor() {
    this.ensureTable()
  }

  async ensureTable() {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS bazi_reports (
        id SERIAL PRIMARY KEY,
        created_at TIMESTAMP DEFAULT NOW(),
        pillars JSONB,
        tone TEXT,
        narrative JSONB
      )
    `)
  }

  async saveReport(pillars, tone, narrative) {
    await pool.query(
      `INSERT INTO bazi_reports (pillars, tone, narrative) VALUES ($1, $2, $3)`,
      [pillars, tone, narrative]
    )
  }

  async getLatestReport() {
    const res = await pool.query(
      `SELECT * FROM bazi_reports ORDER BY created_at DESC LIMIT 1`
    )
    return res.rows[0]
  }

  async getReportById(id) {
    const res = await pool.query(
      `SELECT * FROM bazi_reports WHERE id = $1`,
      [id]
    )
    return res.rows[0]
  }
}

module.exports = { PostgresRepo }
