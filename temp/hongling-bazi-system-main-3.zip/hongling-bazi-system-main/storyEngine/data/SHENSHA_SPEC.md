# 神煞規則資料化規格（Specification）

## 一、檔案與命名規範

### 目錄
- **傳統版**：`storyEngine/data/shensha_trad/`
- **四時軍團版**：`storyEngine/data/shensha_legion/`

### 檔名
- 格式：`<神煞英文或拼音>.json`（小寫、底線分隔）
- 範例：
  - `tianyi_guiren.json` - 天乙貴人
  - `taohua.json` - 桃花
  - `yima.json` - 驛馬
  - `tiande.json` - 天德
  - `yuede.json` - 月德
  - `hongluan.json` - 紅鸞
  - `tianxi.json` - 天喜

### 版本控制
- 一檔 = 一顆神煞
- 若同顆神煞需多版本（學派差異），放不同目錄或另開 `…_alt.json` 並於 `rule_ref` 標記來源

## 二、資料結構（JSON Schema）

```json
{
  "name": "string",           // 神煞名稱（繁中）
  "enabled": true,            // 是否啟用
  "priority": 10,             // 越小優先越高（數字）
  "rules": [
    {
      "anchor": "dayStem | yearBranch | monthBranch | dayBranch | hourBranch | anyBranch | combo",
      "rule_ref": "string",   // 來源/派別/書目
      "table": {              // 針對 anchor 的查表
        "鍵": ["值","值"]     // dayStem: 甲乙丙丁戊己庚辛壬癸
                              // *Branch: 子丑寅卯辰巳午未申酉戌亥
      },
      "combo": [              // anchor=combo 時使用（多條件 AND/OR）
        {
          "anchor": "dayStem | yearBranch | monthBranch | dayBranch | hourBranch",
          "in": ["值","值"],  // 需要命中的集合
          "target": "year | month | day | hour | any",
          "any": false        // true=此子條件內部 OR；預設 AND
        }
      ],
      "notes": "string (optional)"
    }
  ]
}
```

## 三、語意規則

### table 語意
- **一律解讀為**：「查 key → 得到一組『應命中的地支集合』；四柱任一地支若在該集合，即視為命中。」
- **範例**：
  - `anchor="yearBranch"`、`table["申"]=["酉"]` 
  - 表示「年支為申時，只要四柱任一支＝酉，命中此規則」

### dayStem 類
- 以日干為 key → 得到一組「應命中的地支集合」
- 四柱任一地支若在集合內，即命中

### anyBranch
- 對四柱任一支逐一查 table
- 如果出現「X 支對應集合中包含四柱中另外一支」，視為命中（支對支互見）

### combo（複合條件）
- 多錨點聯合（AND）
- 每個子條件可以指定 `target`（year/month/day/hour/any）
- 常用於「年支取位，且月、日同應」等強化條件

## 四、合法值與字典

### 天干
甲 乙 丙 丁 戊 己 庚 辛 壬 癸

### 地支
子 丑 寅 卯 辰 巳 午 未 申 酉 戌 亥

### anchor 合法值
- `"dayStem"`
- `"yearBranch"`
- `"monthBranch"`
- `"dayBranch"`
- `"hourBranch"`
- `"anyBranch"`
- `"combo"`

### target 合法值（Branch 類子條件）
- `"year"`
- `"month"`
- `"day"`
- `"hour"`
- `"any"`

## 五、校驗規則（產出前必檢）

1. **鍵值合法**：所有 key 值必為天干或地支中之一；表內 value 值必為地支
2. **空陣列允許**：資料未覆核可留空，但 `enabled=false` 並於 notes 註明
3. **無多餘欄位**：不得出現 schema 未定義之欄位
4. **唯一性**：同一資料夾內 name 不重複；衝突請用 priority 或改名
5. **可解析性**：確保 JSON UTF-8 無 BOM；逗號、引號正確
6. **證據鏈**：務必填 `rule_ref`；指向你們的來源章節/派別名

## 六、驗證測試（最小測資組）

### 測試案例

| 測試代號 | 四柱（年/月/日/時 支） | 預期命中（傳統） |
|---------|---------------------|----------------|
| T1 | 年=申、月=酉、日=卯、時=子 | 桃花（年申→酉；四柱含酉）、驛馬（年申→寅；若任一支=寅則中）、太極（有子/午/卯/酉皆中） |
| T2 | 日干=甲；四柱含丑或未 | 天乙（甲→丑未） |
| T3 | 年=寅，四柱含卯 | 桃花（寅→卯） |
| T4 | 四柱任一支∈{子/午/卯/酉} | 太極（任一即中） |
| T5 | 年=申、月=酉、日=酉（ruleset=legion） | 強桃花命中（年申取酉，且月、日同應） |

### API 驗證
透過 `/api/bazi/compute?ruleset=trad|legion` 拿 `.data.anchors.shensha`，應看到：
- `name` - 神煞名稱
- `anchor_basis` - 錨點依據
- `why_matched` - 命中原因
- `rule_ref` - 規則來源

## 七、整合說明

### 使用方式

```typescript
import ShenshaEngine from './storyEngine/shenshaEngine';

// 建立引擎（傳統版或軍團版）
const engine = new ShenshaEngine('trad'); // or 'legion'

// 計算神煞
const chart = {
  year: { stem: '甲', branch: '申' },
  month: { stem: '乙', branch: '酉' },
  day: { stem: '丙', branch: '卯' },
  hour: { stem: '丁', branch: '子' }
};

const matches = engine.calculate(chart);
console.log(matches);
// [
//   {
//     name: '桃花',
//     anchor_basis: '年支=申',
//     why_matched: '查表得[酉]，四柱月支=酉命中',
//     rule_ref: '四柱對照-年支取桃花位',
//     priority: 30
//   },
//   ...
// ]
```

### 驗證工具

```typescript
import ShenshaValidator from './storyEngine/shenshaValidator';

const validator = new ShenshaValidator();
const result = validator.validate(shenshaDefinition);

if (!result.valid) {
  console.error('驗證失敗：', result.errors);
}
```

## 八、落地後檢查事項

1. **在 `/status` 回報**目前 ruleset 與目錄最後修改時間，方便你比對線上到底拿哪套
2. **在 `/api/bazi/compute`** 的回傳 `anchors.shensha` 加上計數統計（命中數、命中清單），前端就能直接畫出「神煞徽章」

## 九、檔案清單

已實作的神煞檔案：

### 傳統版 (shensha_trad/)
- ✅ `tianyi_guiren.json` - 天乙貴人
- ✅ `taiji_guiren.json` - 太極貴人
- ✅ `taohua.json` - 桃花
- ✅ `yima.json` - 驛馬
- ✅ `yangren.json` - 羊刃
- ✅ `tiande.json` - 天德
- ✅ `yuede.json` - 月德
- ✅ `hongluan.json` - 紅鸞
- ✅ `tianxi.json` - 天喜
- ✅ `guchen.json` - 孤辰
- ✅ `guasu.json` - 寡宿
- ✅ `jiesha.json` - 劫煞
- ✅ `wangshen.json` - 亡神

### 軍團版 (shensha_legion/)
- ✅ `qiang_taohua.json` - 強桃花（combo規則示例）
- ✅ 其他：繼承自傳統版

## 十、擴充指南

### 新增神煞
1. 在對應目錄（trad 或 legion）新增 JSON 檔案
2. 遵守命名規範與 Schema
3. 使用 ShenshaValidator 驗證
4. 引擎會自動載入（重啟後）

### 修改規則
1. 編輯對應的 JSON 檔案
2. 重新驗證
3. 重啟服務以重新載入

### 學派差異
- 使用 `_alt.json` 後綴
- 在 `rule_ref` 中標記學派來源
- 可透過 priority 控制優先順序
