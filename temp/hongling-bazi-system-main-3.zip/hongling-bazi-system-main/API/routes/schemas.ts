import { z } from "zod";

// Schema for individual pillar info
const pillarInfoSchema = z.object({
  pillar: z.string(),
});

// Schema for pillar with gan and zhi
const pillarSchema = z.object({
  gan: z.string(),
  zhi: z.string(),
  pillar: z.string(),
});

// Schema for pillar set
const pillarSetSchema = z.object({
  year: pillarSchema,
  month: pillarSchema,
  day: pillarSchema,
  hour: pillarSchema,
});

// Schema for narrative section
const narrativeSectionSchema = z.object({
  naYin: z.string(),
  commander: z.string().optional(),
  strategist: z.string().optional(),
  story: z.string().optional(),
});

// Schema for narrative data
export const narrativeDataSchema = z.object({
  year: narrativeSectionSchema,
  month: narrativeSectionSchema,
  day: narrativeSectionSchema,
  hour: narrativeSectionSchema,
}); // Only allow explicitly defined narrative sections

// Schema for chart data
export const chartDataSchema = z.object({
  pillars: z.union([pillarSetSchema, z.record(z.string(), pillarInfoSchema)]),
  tenGods: z.array(z.string()),
  shensha: z.array(z.string()),
  fiveElements: z.record(z.string(), z.number()),
  yinYang: z.object({
    陰: z.number(),
    陽: z.number(),
  }),
  tone: z.string().optional(),
});

// Schema for the complete request body
export const reportRequestSchema = z.object({
  chart: chartDataSchema,
  narrative: narrativeDataSchema,
});

// Export types for use in other files
export type ChartData = z.infer<typeof chartDataSchema>;
export type NarrativeData = z.infer<typeof narrativeDataSchema>;
export type ReportRequest = z.infer<typeof reportRequestSchema>;
