# 兩步驟 AI 生成架構說明

## 概述

本系統已重構為支援兩步驟的 AI 生成架構，將 API 金鑰管理與故事生成分離，提供更靈活和可擴展的解決方案。

## 架構設計

### 第一步：API 金鑰管理 (`/api/keys`)
負責驗證、註冊和管理 API 金鑰，與具體的 AI 服務解耦。

### 第二步：AI 故事生成 (`/api/ai/story`) 
使用已驗證的 API 金鑰來生成各種類型的故事內容。

## API 端點

### 1. API 金鑰管理

#### POST `/api/keys` - 註冊和驗證 API 金鑰
```bash
curl -X POST http://localhost:3000/api/keys \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{
    "service": "story-generation",
    "provider": "openai"
  }'
```

**回應範例：**
```json
{
  "success": true,
  "data": {
    "keyId": "key_1758372299762_yn4bhwpm2",
    "service": "story-generation",
    "provider": "openai",
    "status": "valid",
    "createdAt": "2025-09-20T12:44:59.762Z",
    "expiresAt": "2025-09-21T12:44:59.762Z"
  },
  "message": "API key validated for story-generation service using openai provider"
}
```

#### GET `/api/keys/:keyId` - 檢查 API 金鑰狀態
```bash
curl http://localhost:3000/api/keys/key_1758372299762_yn4bhwpm2
```

#### DELETE `/api/keys/:keyId` - 撤銷 API 金鑰
```bash
curl -X DELETE http://localhost:3000/api/keys/key_1758372299762_yn4bhwpm2
```

### 2. AI 故事生成

#### POST `/api/ai/story` - 生成 AI 故事
```bash
curl -X POST http://localhost:3000/api/ai/story \
  -H "Content-Type: application/json" \
  -d '{
    "keyId": "key_1758372299762_yn4bhwpm2",
    "type": "army-narrative",
    "data": {
      "pillar": "year",
      "chart": {
        "year": {
          "stem": "甲",
          "branch": "子",
          "hidden": ["癸"],
          "naYin": "海中金",
          "tenGod": "比肩",
          "shensha": ["天乙貴人", "華蓋"]
        }
      }
    },
    "options": {
      "tone": "heroic",
      "length": "medium",
      "language": "zh-TW"
    }
  }'
```

#### GET `/api/ai/providers` - 列出可用的 AI 提供商
```bash
curl http://localhost:3000/api/ai/providers
```

**回應範例：**
```json
{
  "success": true,
  "data": {
    "providers": [
      {
        "name": "local",
        "displayName": "本地故事引擎",
        "description": "使用內建的故事生成邏輯",
        "supportedTypes": ["army-narrative"],
        "status": "active"
      },
      {
        "name": "openai",
        "displayName": "OpenAI GPT",
        "description": "OpenAI GPT 模型驅動的故事生成",
        "supportedTypes": ["army-narrative", "fortune-analysis", "life-prediction"],
        "status": "coming-soon"
      }
    ]
  }
}
```

### 3. 整合端點（V2 生成）

#### POST `/generate-v2` - 使用兩步驟流程的整合端點
```bash
# 不使用 API 金鑰（單步驟本地生成）
curl -X POST http://localhost:3000/generate-v2 \
  -H "Content-Type: application/json" \
  -d '{
    "input": "1984-01-01 12:00:00",
    "tone": "heroic",
    "options": {
      "useAI": false
    }
  }'

# 使用 API 金鑰（兩步驟 AI 生成）
curl -X POST http://localhost:3000/generate-v2 \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{
    "input": "1984-01-01 12:00:00",
    "tone": "heroic",
    "options": {
      "useAI": true,
      "provider": "openai",
      "storyType": "army-narrative"
    }
  }'
```

## 支援的故事類型

### 1. `army-narrative` - 軍團敘事
使用現有的本地故事引擎，生成八字軍團故事。

### 2. `fortune-analysis` - 運勢分析
未來將整合 AI 模型的運勢分析功能。

### 3. `life-prediction` - 人生預測
未來將整合 AI 模型的人生預測功能。

## 支援的 AI 提供商

### 1. `local` - 本地引擎
- **狀態**: 已啟用
- **支援類型**: army-narrative
- **描述**: 使用內建的故事生成邏輯

### 2. `openai` - OpenAI GPT
- **狀態**: 開發中
- **支援類型**: army-narrative, fortune-analysis, life-prediction
- **描述**: 將來整合 OpenAI GPT 模型

### 3. `anthropic` - Anthropic Claude
- **狀態**: 計劃中
- **支援類型**: fortune-analysis, life-prediction
- **描述**: 將來整合 Anthropic Claude 模型

## 架構優勢

### 1. 關注點分離
- API 金鑰管理獨立於故事生成邏輯
- 可以輕鬆添加新的 AI 提供商
- 安全性與功能性解耦

### 2. 可擴展性
- 支援多種故事類型
- 支援多個 AI 提供商
- 易於添加新的服務和功能

### 3. 向後兼容
- 原有的 `/generate` 端點仍然可用
- 新的 `/generate-v2` 端點支援舊有功能

### 4. 容錯機制
- AI 生成失敗時自動回退到本地生成
- 靈活的錯誤處理

## 未來擴展

### 1. 更多 AI 提供商
- Google Bard
- Baidu ERNIE
- 其他專業命理 AI 模型

### 2. 更多故事類型
- 職業建議
- 關係分析
- 健康預測
- 財運分析

### 3. 進階功能
- 故事模板系統
- 個人化風格設定
- 多語言支援
- 圖像生成整合

## 安全考量

### 1. API 金鑰管理
現階段為簡化實作，API 金鑰驗證為模擬實作。正式環境需要：
- 與真實 AI 服務進行金鑰驗證
- 安全的金鑰儲存機制
- 金鑰使用量監控
- 金鑰輪換機制

### 2. 資料保護
- 請求和回應資料的加密
- 使用者隱私資料保護
- 故事內容的安全儲存

## 部署注意事項

### 1. 環境變數
```bash
# 未來需要的環境變數
OPENAI_API_KEY=your-openai-key
ANTHROPIC_API_KEY=your-anthropic-key
```

### 2. 設定檔
將來可考慮使用設定檔管理 AI 提供商的配置。

### 3. 監控
建議監控各 AI 服務的使用量和回應時間。