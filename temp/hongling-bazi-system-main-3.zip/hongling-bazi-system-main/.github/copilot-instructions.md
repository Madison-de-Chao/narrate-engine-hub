## 專案簡介  
本專案為高精度、可追溯的八字計算系統，融合兵法 RPG 遊戲、命理自我探索等角色設定。支持多案例驗證、精細節氣分界、詳盡計算證據鏈。前端主用 React/TypeScript，UI以 Tailwind CSS、Framer Motion 強化動態效果，後端 NodeJS API，PDF匯出功能、AI自動分析。

Project Overview  
This project is a high-precision, fully traceable BaZi (Eight Characters) calculation system. It features RPG-style military formation metaphor and self-exploration logic, supports multi-case validation, minute-accurate solar term boundaries, and a complete calculation proof chain. The frontend uses React/TypeScript with dynamic UI via Tailwind CSS and Framer Motion, while the backend is NodeJS API. The system supports custom PDF export and AI-powered analysis.

***

## 技術規格  
- 前端：React、TypeScript、Tailwind CSS、Framer Motion  
- 後端：NodeJS、API Server  
- PDF匯出：自訂排版  
- 數據分析：Chart.js  
- AI協作：GPT API 結合命理規則自動生成說明  

Technical Specifications  
- Frontend: React, TypeScript, Tailwind CSS, Framer Motion  
- Backend: NodeJS, API Server  
- PDF Export: Custom typesetting  
- Data Analysis: Chart.js  
- AI Collaboration: GPT API with metaphysics business logic  

***

## 開發、測試與部署流程  
1. 安裝依賴：`npm install`  
2. 開發啟動：`npm run dev`  
3. 打包建置：`npm run build`  
4. 單元測試：`npm run test`  
5. 部署環境：建議用 Vercel/Railway  

Development, Testing, and Deployment Workflow  
1. Install dependencies: `npm install`  
2. Start development: `npm run dev`  
3. Build for production: `npm run build`  
4. Run unit tests: `npm run test`  
5. Deployment: Recommended Vercel or Railway  

***

## 架構穩健、反應快速  
專案架構分層明確，前端/後端/數據/算法分離設計，易於維護擴充。高內聚低耦合，維持大型專案的穩定性與彈性。所有 API 及運算皆經最佳化，確保高併發反應速度，適合雲端部署。

Stability & Fast Performance  
The project is modularized: frontend, backend, data, and logic are separated for easy maintenance and extensibility. Cohesion and loose coupling provide both stability and flexibility. All APIs and computations are optimized for fast, concurrent responses; cloud deployment is well supported.

***

## 核心邏輯與特殊規則  
八字計算支援「真太陽時」與「節氣分界」，EPOCH紀元校驗，anchorbasis證據鏈引擎。支援兵法職業、buff/debuff、場景特殊符號標記。30大神煞、五行權重、納音配對皆用表格映射，所有推論皆附證據原理。

Core Logic & Special Rules  
BaZi calculations support “True Solar Time” and precise solar term division, with EPOCH-based calibration and anchorbasis evidence engine. RPG-style interpretation for roles, buffs/debuffs, scenario marking are included. 30 ShenSha, five-element weights, and Nayin pairing are systematically mapped with lookup tables; all inference results come with traceable calculation proof.

***

## 檔案/資料夾結構  
- `/src`: 前端主程式  
- `/api`: 後端 API  
- `/public/pdf`: PDF模板與匯出資料  
- `/config`: 兵法規則、節氣、五行表格  
- `README.md`: 專案使用維護說明  

File/Folder Structure  
- `/src` - Main frontend application  
- `/api` - Backend API logic  
- `/public/pdf` - PDF templates and export artifacts  
- `/config` - Military logic rules, solar term data, five elements tables  
- `README.md` - Project usage and maintenance notes  

***

## 測算確實無誤  
所有八字（天干地支、五行、神煞）運算皆經多案例驗證，附嚴謹證據鏈，保證正確可追溯。

Guaranteed Accuracy  
All BaZi (Stems, Branches, Five Elements, ShenSha) calculations are validated by test cases and proof chains, ensuring correctness and traceability.

***

## 常見錯誤與處理  
- 節氣分界錯誤 → 檢查 EPOCH、TrueSolarTime 參數  
- PDF匯出異常 → 檢查字型、版面參數  
- API異常 → 查閱 NodeJS server log、比對前後端欄位  

Common Issues & Handling  
- Boundary error in solar term → Check EPOCH and TrueSolarTime parameters  
- PDF export display issue → Check font and layout configs  
- API error → Inspect NodeJS server logs, verify frontend/backend fields  

***

## 研發理念與應用情境  
強調「邏輯可驗證」、「透明可追溯」演算法架構，RPG兵法象徵，角色分工明確，動態互動。適用自我成長、命運解析、社群活動、專業諮詢。

Philosophy & Scenarios  
Emphasizes logic-verifiability, transparency, and traceability throughout algorithm design. Features RPG military metaphor, clear role division, dynamic interaction; suitable for personal growth, destiny analysis, community, and professional consulting.

***

---
description: Instructions for AI agents working on 虹靈御所八字敘事系統
---

# Copilot Instructions for 虹靈御所八字敘事系統

## 專案架構與核心知識
- 分層設計：前端（React/TypeScript/Tailwind）與後端（NodeJS API）完全分離，資料流經由 REST API (`/api/routes/`) 溝通。
- 命理計算：八字、節氣、真太陽時計算集中於 `storyEngine/` 與 `api/config/`，並以表格映射與 anchorbasis 證據鏈追蹤。
- RPG/兵法敘事：角色、buff/debuff、兵法規則由 `config/` 與 `storyEngine/generateArmyNarrative.ts` 協作生成。
- PDF 匯出：模板位於 `public/pdf/`，透過 `api/routes/report.ts` 及 `views/report.ejs` 組裝輸出。
- AI 整合：`api/routes/ai.ts` 串接 GPT，需同時回傳 traceId 與 debug 資訊。

## 開發與測試流程
- 安裝依賴：`npm install`
- 啟動開發：`npm run dev`（同時啟動前端與後端服務）
- 單元測試：`npm run test`
- 打包建置：`npm run build`
- PDF 檢查：執行匯出後檢查 `public/pdf/` 輸出與字型設定
- 部署：優先使用 Vercel/Railway；詳見 `DEPLOYMENT_GUIDE.md`

## 專案慣例與規範
- 證據鏈要求：所有推論結果需保留原始計算依據（EPOCH、TrueSolarTime、anchorbasis）。
- 節氣分界：使用分鐘精度；異常多因 EPOCH 或 TrueSolarTime 設定。
- API 統一：回傳物件需含 `traceId`、`debug` 欄位；錯誤訊息務必記錄。
- 數據來源：五行、神煞、納音等皆以配置表查找，禁止硬編碼常數。
- 日誌排查：若發生誤差，優先比對 `README.md` 與 `API/routes` 內的錯誤處理說明。

## 關鍵檔案速覽
- `api/routes/bazi.ts`：八字計算 API 入口，串接 config 查表與 storyEngine。
- `storyEngine/chartEngine.ts`：核心排盤計算，負責節氣與真太陽時換算。
- `storyEngine/utils.ts`：共用數學/時間工具，注意 EPOCH 轉換。
- `config/`、`api/config/`：兵法、五行、節氣等配置表。
- `scripts/self-test.mjs`：Railway 自動化檢測腳本，可用於部署前驗證。

## 常見問題排查
- 節氣界線錯誤 → 檢查 `storyEngine/chartEngine.ts` 中的 EPOCH 與 TrueSolarTime 參數。
- PDF 空白或字型錯誤 → 確認 `public/pdf/` 模板與字型檔案是否存在、無缺失。
- API 回傳缺欄位 → 檢查各路由 `traceId` 與 `debug` 字段是否在 service 層帶出。
- AI 回應異常 → 比對 `api/routes/ai.ts` 設定是否同步更新 GPT 模板與命理規則。

