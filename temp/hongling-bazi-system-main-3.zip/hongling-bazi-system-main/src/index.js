#!/usr/bin/env node

// 🌈 虹靈御所八字系統 v9.3 修復版
import http from 'http';
import { parse } from 'url';

const PORT = process.env.PORT || 3000;

console.log('🌈 虹靈御所八字人生兵法系統啟動中...');
console.log('📦 版本: v9.3-fixed');

const server = http.createServer((req, res) => {
    const pathname = parse(req.url).pathname;
    
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }

    try {
        if (pathname === '/') {
            res.writeHead(200);
            res.end(JSON.stringify({
                message: '🌈 虹靈御所八字人生兵法系統',
                version: 'v9.3-fixed',
                status: '✅ 系統運行正常',
                timestamp: new Date().toISOString(),
                server: 'Railway Production',
                calculator_status: '🧮 計算引擎就緒',
                features: [
                    '🧮 完整八字四柱計算',
                    '🎯 anchorbasis戰術分析',
                    '⚔️ 納音戰場系統',
                    '🛡️ 地支藏干技能樹',
                    '🎮 RPG遊戲化轉換',
                    '📊 透明可追溯計算'
                ]
            }, null, 2));
        }

        else if (pathname === '/health') {
            res.writeHead(200);
            res.end(JSON.stringify({
                status: 'healthy',
                service: '虹靈御所八字系統',
                version: 'v9.3-fixed',
                timestamp: new Date().toISOString(),
                uptime: Math.floor(process.uptime()),
                memory: process.memoryUsage()
            }, null, 2));
        }

        else if (pathname === '/test') {
            res.writeHead(200);
            res.end(JSON.stringify({
                message: '🧪 v9.3計算引擎測試',
                test_case: '1985-10-06 19:30',
                result: {
                    year: '乙丑',
                    day: '戊申', 
                    anchor_basis: '戊-丑-申',
                    rpg_class: '大地守護者'
                },
                status: '✅ 基礎計算邏輯正常'
            }, null, 2));
        }

        else {
            res.writeHead(404);
            res.end(JSON.stringify({
                error: 'Not Found',
                available: ['/', '/health', '/test']
            }));
        }

    } catch (error) {
        res.writeHead(500);
        res.end(JSON.stringify({
            error: 'Server Error',
            message: error.message
        }));
    }
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 虹靈御所八字系統運行在端口 ${PORT}`);
    console.log('✅ 健康檢查端點就緒');
});

process.on('uncaughtException', (error) => {
    console.error('❌ 異常:', error.message);
});
