
// 類型定義
// 基本介面
export interface Pillar { gan: string; stem?: string; zhi: string; branch?: string }
export interface PillarSet { year: Pillar; month: Pillar; day: Pillar; hour: Pillar }
export type SeasonCycle = '春'|'夏'|'秋'|'冬'
type YinYang = '陽' | '陰'
type FiveElement = '木' | '火' | '土' | '金' | '水'
type TenGodName =
  | '比肩'
  | '劫財'
  | '食神'
  | '傷官'
  | '正財'
  | '偏財'
  | '正官'
  | '七殺'
  | '正印'
  | '偏印'
type TenGodRelation = Record<YinYang, TenGodName>
type MonthPillarResult = { stem: string; branch: string; solarTerm: string }
type DayPillarResult = { stem: string; branch: string; dayNumber: number }
type HourPillarResult = { stem: string; branch: string; hourIndex: number }
type ElementDistribution = Record<FiveElement, number>
type ElementPercentage = Record<FiveElement, string>
type TenGodCount = Record<TenGodName, number>
type TenGodDetail = { position: keyof PillarSet; stem: string; god: TenGodName | '' }
type TenGodSummary = { distribution: TenGodCount; details: TenGodDetail[] }
type SelfAnalysis = {
  五行分布: ElementPercentage
  日主: string
  日主五行: string
  日主旺衰: '偏旺' | '普通' | '偏弱'
  格局: string
  天乙貴人: string[]
  桃花: string
  驛馬: string
  十神分布: TenGodCount
  十神明細: TenGodDetail[]
  神煞: string[]
  四時軍團: FourSeasonsTeam
}
export type SeasonDistribution = {
  seasonByPillar: Record<'year'|'month'|'day'|'hour', SeasonCycle>
  raw: Record<SeasonCycle, number>
  percentage: Record<SeasonCycle, string>
  total: number
}
export type FourSeasonsTeam = {
  team: SeasonCycle
  seasonByPillar: Record<'year'|'month'|'day'|'hour', SeasonCycle>
  distribution: Record<SeasonCycle, string>
  keywords: string[]
  strengths: string[]
  blindspots: string[]
  tips: string[]
}

export const HIDDEN_STEMS: Record<string, Array<{ stem: string; ratio: number; type: string }>> = {
  '子': [
    { stem: '癸', ratio: 100, type: '本氣' }
  ],
  '丑': [
    { stem: '己', ratio: 60, type: '本氣' },
    { stem: '癸', ratio: 30, type: '中氣' },
    { stem: '辛', ratio: 10, type: '餘氣' }
  ],
  '寅': [
    { stem: '甲', ratio: 60, type: '本氣' },
    { stem: '丙', ratio: 30, type: '中氣' },
    { stem: '戊', ratio: 10, type: '餘氣' }
  ],
  '卯': [
    { stem: '乙', ratio: 100, type: '本氣' }
  ],
  '辰': [
    { stem: '戊', ratio: 60, type: '本氣' },
    { stem: '乙', ratio: 30, type: '中氣' },
    { stem: '癸', ratio: 10, type: '餘氣' }
  ],
  '巳': [
    { stem: '丙', ratio: 60, type: '本氣' },
    { stem: '戊', ratio: 30, type: '中氣' },
    { stem: '庚', ratio: 10, type: '餘氣' }
  ],
  '午': [
    { stem: '丁', ratio: 70, type: '本氣' },
    { stem: '己', ratio: 30, type: '中氣' }
  ],
  '未': [
    { stem: '己', ratio: 60, type: '本氣' },
    { stem: '丁', ratio: 30, type: '中氣' },
    { stem: '乙', ratio: 10, type: '餘氣' }
  ],
  '申': [
    { stem: '庚', ratio: 60, type: '本氣' },
    { stem: '壬', ratio: 30, type: '中氣' },
    { stem: '戊', ratio: 10, type: '餘氣' }
  ],
  '酉': [
    { stem: '辛', ratio: 100, type: '本氣' }
  ],
  '戌': [
    { stem: '戊', ratio: 60, type: '本氣' },
    { stem: '辛', ratio: 30, type: '中氣' },
    { stem: '丁', ratio: 10, type: '餘氣' }
  ],
  '亥': [
    { stem: '壬', ratio: 70, type: '本氣' },
    { stem: '甲', ratio: 30, type: '中氣' }
  ]
};

            // 完整五虎遁月表
export const WUHU_DUN: Record<string, string[]> = {
                '甲': ['丙寅','丁卯','戊辰','己巳','庚午','辛未','壬申','癸酉','甲戌','乙亥','丙子','丁丑'],
                '己': ['丙寅','丁卯','戊辰','己巳','庚午','辛未','壬申','癸酉','甲戌','乙亥','丙子','丁丑'],
                '乙': ['戊寅','己卯','庚辰','辛巳','壬午','癸未','甲申','乙酉','丙戌','丁亥','戊子','己丑'],
                '庚': ['戊寅','己卯','庚辰','辛巳','壬午','癸未','甲申','乙酉','丙戌','丁亥','戊子','己丑'],
                '丙': ['庚寅','辛卯','壬辰','癸巳','甲午','乙未','丙申','丁酉','戊戌','己亥','庚子','辛丑'],
                '辛': ['庚寅','辛卯','壬辰','癸巳','甲午','乙未','丙申','丁酉','戊戌','己亥','庚子','辛丑'],
                '丁': ['壬寅','癸卯','甲辰','乙巳','丙午','丁未','戊申','己酉','庚戌','辛亥','壬子','癸丑'],
                '壬': ['壬寅','癸卯','甲辰','乙巳','丙午','丁未','戊申','己酉','庚戌','辛亥','壬子','癸丑'],
                '戊': ['甲寅','乙卯','丙辰','丁巳','戊午','己未','庚申','辛酉','壬戌','癸亥','甲子','乙丑'],
                '癸': ['甲寅','乙卯','丙辰','丁巳','戊午','己未','庚申','辛酉','壬戌','癸亥','甲子','乙丑']
            };

            // 完整五鼠遁時表
export const WUSHU_DUN: Record<string, string[]> = {
                '甲': ['甲子','乙丑','丙寅','丁卯','戊辰','己巳','庚午','辛未','壬申','癸酉','甲戌','乙亥'],
                '己': ['甲子','乙丑','丙寅','丁卯','戊辰','己巳','庚午','辛未','壬申','癸酉','甲戌','乙亥'],
                '乙': ['丙子','丁丑','戊寅','己卯','庚辰','辛巳','壬午','癸未','甲申','乙酉','丙戌','丁亥'],
                '庚': ['丙子','丁丑','戊寅','己卯','庚辰','辛巳','壬午','癸未','甲申','乙酉','丙戌','丁亥'],
                '丙': ['戊子','己丑','庚寅','辛卯','壬辰','癸巳','甲午','乙未','丙申','丁酉','戊戌','己亥'],
                '辛': ['戊子','己丑','庚寅','辛卯','壬辰','癸巳','甲午','乙未','丙申','丁酉','戊戌','己亥'],
                '丁': ['庚子','辛丑','壬寅','癸卯','甲辰','乙巳','丙午','丁未','戊申','己酉','庚戌','辛亥'],
                '壬': ['庚子','辛丑','壬寅','癸卯','甲辰','乙巳','丙午','丁未','戊申','己酉','庚戌','辛亥'],
                '戊': ['壬子','癸丑','甲寅','乙卯','丙辰','丁巳','戊午','己未','庚申','辛酉','壬戌','癸亥'],
                '癸': ['壬子','癸丑','甲寅','乙卯','丙辰','丁巳','戊午','己未','庚申','辛酉','壬戌','癸亥']
            };

            // 完整十神關係表
export const TEN_GODS: Record<FiveElement, Record<FiveElement, TenGodRelation>> = {
                '木': {
                    '木': { '陽': '比肩', '陰': '劫財' },
                    '火': { '陽': '食神', '陰': '傷官' },
                    '土': { '陽': '偏財', '陰': '正財' },
                    '金': { '陽': '七殺', '陰': '正官' },
                    '水': { '陽': '偏印', '陰': '正印' }
                },
                '火': {
                    '火': { '陽': '比肩', '陰': '劫財' },
                    '土': { '陽': '食神', '陰': '傷官' },
                    '金': { '陽': '偏財', '陰': '正財' },
                    '水': { '陽': '七殺', '陰': '正官' },
                    '木': { '陽': '偏印', '陰': '正印' }
                },
                '土': {
                    '土': { '陽': '比肩', '陰': '劫財' },
                    '金': { '陽': '食神', '陰': '傷官' },
                    '水': { '陽': '偏財', '陰': '正財' },
                    '木': { '陽': '七殺', '陰': '正官' },
                    '火': { '陽': '偏印', '陰': '正印' }
                },
                '金': {
                    '金': { '陽': '比肩', '陰': '劫財' },
                    '水': { '陽': '食神', '陰': '傷官' },
                    '木': { '陽': '偏財', '陰': '正財' },
                    '火': { '陽': '七殺', '陰': '正官' },
                    '土': { '陽': '偏印', '陰': '正印' }
                },
                '水': {
                    '水': { '陽': '比肩', '陰': '劫財' },
                    '木': { '陽': '食神', '陰': '傷官' },
                    '火': { '陽': '偏財', '陰': '正財' },
                    '土': { '陽': '七殺', '陰': '正官' },
                    '金': { '陽': '偏印', '陰': '正印' }
                }
            };

            // 完整節氣表（2024年為例，實際應查詢天文曆）
export const SOLAR_TERMS_2024: Record<string, Date> = {
                '小寒': new Date('2024-01-06T04:49:09'),
                '大寒': new Date('2024-01-20T22:07:08'),
                '立春': new Date('2024-02-04T16:26:53'),
                '雨水': new Date('2024-02-19T12:12:58'),
                '驚蟄': new Date('2024-03-05T10:22:31'),
                '春分': new Date('2024-03-20T11:06:12'),
                '清明': new Date('2024-04-04T15:02:03'),
                '穀雨': new Date('2024-04-19T21:59:33'),
                '立夏': new Date('2024-05-05T08:10:00'),
                '小滿': new Date('2024-05-20T20:59:17'),
                '芒種': new Date('2024-06-05T12:09:40'),
                '夏至': new Date('2024-06-21T04:50:46'),
                '小暑': new Date('2024-07-06T22:19:49'),
                '大暑': new Date('2024-07-22T15:44:11'),
                '立秋': new Date('2024-08-07T08:09:01'),
                '處暑': new Date('2024-08-22T22:54:48'),
                '白露': new Date('2024-09-07T11:11:06'),
                '秋分': new Date('2024-09-22T20:43:27'),
                '寒露': new Date('2024-10-08T02:59:43'),
                '霜降': new Date('2024-10-23T06:14:32'),
                '立冬': new Date('2024-11-07T06:19:49'),
                '小雪': new Date('2024-11-22T03:56:16'),
                '大雪': new Date('2024-12-06T23:16:47'),
                '冬至': new Date('2024-12-21T17:20:20')
};

// 六十甲子神煞表
// 1. 天乙貴人
function shensha_tianyiguiren(dayGan: string): string[] {
  return {
    "甲": ["丑", "未"],
    "戊": ["丑", "未"],
    "庚": ["丑", "未"],
    "乙": ["子", "申"],
    "己": ["子", "申"],
    "丙": ["亥", "酉"],
    "丁": ["亥", "酉"],
    "壬": ["卯", "巳"],
    "癸": ["卯", "巳"]
  }[dayGan] || [];
}

// 2. 桃花（咸池）
function shensha_taohua(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "申": "酉", "子": "酉", "辰": "酉",
    "寅": "卯", "午": "卯", "戌": "卯",
    "巳": "午", "酉": "午", "丑": "午",
    "亥": "子", "卯": "子", "未": "子"
  };
  return map[baseZhi];
}

// 3. 驛馬
function shensha_yima(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "申": "寅", "子": "寅", "辰": "寅",
    "寅": "申", "午": "申", "戌": "申",
    "巳": "亥", "酉": "亥", "丑": "亥",
    "亥": "巳", "卯": "巳", "未": "巳"
  };
  return map[baseZhi];
}

// 4. 紅鸞
function shensha_hongluan(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "亥": "卯", "卯": "未", "未": "亥",
    "寅": "午", "午": "戌", "戌": "寅",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "申": "子", "子": "辰", "辰": "申"
  };
  return map[baseZhi];
}

// 5. 咸池
function shensha_xianchi(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "申": "酉", "子": "酉", "辰": "酉",
    "寅": "卯", "午": "卯", "戌": "卯",
    "巳": "午", "酉": "午", "丑": "午",
    "亥": "子", "卯": "子", "未": "子"
  };
  return map[baseZhi];
}

// 6. 孤辰
function shensha_guchen(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "巳", "午": "申", "戌": "亥",
    "申": "亥", "子": "寅", "辰": "巳",
    "巳": "申", "酉": "亥", "丑": "寅",
    "亥": "寅", "卯": "巳", "未": "申"
  };
  return map[baseZhi];
}

// 7. 寡宿
function shensha_guasu(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "亥", "午": "寅", "戌": "巳",
    "申": "巳", "子": "申", "辰": "亥",
    "巳": "寅", "酉": "巳", "丑": "申",
    "亥": "巳", "卯": "申", "未": "亥"
  };
  return map[baseZhi];
}

// 8. 天德
function shensha_tiande(monthZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "丙", "卯": "丁", "辰": "戊",
    "巳": "己", "午": "庚", "未": "辛",
    "申": "壬", "酉": "癸", "戌": "甲",
    "亥": "乙", "子": "丙", "丑": "丁"
  };
  return map[monthZhi];
}

// 9. 月德
function shensha_yuede(monthZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "丙", "卯": "丁", "辰": "戊",
    "巳": "己", "午": "庚", "未": "辛",
    "申": "壬", "酉": "癸", "戌": "甲",
    "亥": "乙", "子": "丙", "丑": "丁"
  };
  return map[monthZhi];
}

// 10. 亡神
function shensha_wangshen(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "申": "巳", "子": "寅", "辰": "亥",
    "寅": "亥", "午": "巳", "戌": "寅",
    "巳": "寅", "酉": "亥", "丑": "巳",
    "亥": "巳", "卯": "寅", "未": "亥"
  };
  return map[baseZhi];
}

// 11. 吊客
function shensha_diaoke(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "申": "卯", "子": "午", "辰": "酉",
    "寅": "酉", "午": "子", "戌": "卯",
    "巳": "卯", "酉": "子", "丑": "午",
    "亥": "午", "卯": "子", "未": "卯"
  };
  return map[baseZhi];
}

// 12. 血刃
function shensha_xueren(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "巳", "午": "申", "戌": "亥",
    "申": "亥", "子": "寅", "辰": "巳",
    "巳": "申", "酉": "亥", "丑": "寅",
    "亥": "寅", "卯": "巳", "未": "申"
  };
  return map[baseZhi];
}

// 13. 白虎
function shensha_baihu(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "申", "午": "寅", "戌": "午",
    "申": "寅", "子": "午", "辰": "戌",
    "巳": "亥", "酉": "卯", "丑": "未",
    "亥": "巳", "卯": "酉", "未": "丑"
  };
  return map[baseZhi];
}

// 14. 天喜
function shensha_tianxi(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "亥": "巳", "卯": "酉", "未": "丑",
    "寅": "申", "午": "子", "戌": "辰",
    "巳": "亥", "酉": "卯", "丑": "未",
    "申": "寅", "子": "午", "辰": "戌"
  };
  return map[baseZhi];
}

// 15. 天官
function shensha_tianguan(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "子", "午": "辰", "戌": "申",
    "申": "辰", "子": "申", "辰": "子",
    "巳": "丑", "酉": "巳", "丑": "酉",
    "亥": "未", "卯": "亥", "未": "卯"
  };
  return map[baseZhi];
}

// 16. 天廚
function shensha_tianchu(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "巳", "午": "申", "戌": "亥",
    "申": "亥", "子": "寅", "辰": "巳",
    "巳": "申", "酉": "亥", "丑": "寅",
    "亥": "寅", "卯": "巳", "未": "申"
  };
  return map[baseZhi];
}

// 17. 太陰
function shensha_taiyin(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "亥", "午": "卯", "戌": "未",
    "申": "巳", "子": "酉", "辰": "丑",
    "巳": "申", "酉": "子", "丑": "辰",
    "亥": "午", "卯": "戌", "未": "寅"
  };
  return map[baseZhi];
}

// 18. 太極貴人
function shensha_taiji(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "子": "子", "午": "午",
    "卯": "卯", "酉": "酉",
    "辰": "辰", "戌": "戌",
    "丑": "丑", "未": "未",
    "寅": "寅", "申": "申",
    "巳": "巳", "亥": "亥"
  };
  return map[baseZhi];
}

// 19. 將星
function shensha_jiangxing(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 20. 金輿
function shensha_jinyu(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "辰", "午": "申", "戌": "子",
    "申": "戌", "子": "寅", "辰": "午",
    "巳": "未", "酉": "亥", "丑": "卯",
    "亥": "丑", "卯": "巳", "未": "酉"
  };
  return map[baseZhi];
}

// 21. 福德
function shensha_fude(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "亥", "午": "卯", "戌": "未",
    "申": "巳", "子": "酉", "辰": "丑",
    "巳": "申", "酉": "子", "丑": "辰",
    "亥": "午", "卯": "戌", "未": "寅"
  };
  return map[baseZhi];
}

// 22. 天貴
function shensha_tiangui(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "子", "午": "辰", "戌": "申",
    "申": "辰", "子": "申", "辰": "子",
    "巳": "丑", "酉": "巳", "丑": "酉",
    "亥": "未", "卯": "亥", "未": "卯"
  };
  return map[baseZhi];
}

// 23. 地煞
function shensha_disha(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "巳", "午": "申", "戌": "亥",
    "申": "亥", "子": "寅", "辰": "巳",
    "巳": "申", "酉": "亥", "丑": "寅",
    "亥": "寅", "卯": "巳", "未": "申"
  };
  return map[baseZhi];
}

// 24. 陰煞
function shensha_yinsha(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "申", "午": "子", "戌": "辰",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 25. 劍鋒
function shensha_jianfeng(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "申", "午": "子", "戌": "辰",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 26. 天狗
function shensha_tiangou(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "戌", "午": "辰", "戌": "申",
    "申": "辰", "子": "申", "辰": "戌",
    "巳": "丑", "酉": "巳", "丑": "酉",
    "亥": "未", "卯": "亥", "未": "卯"
  };
  return map[baseZhi];
}

// 27. 天刑
function shensha_tianxing(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "戌", "午": "辰", "戌": "申",
    "申": "辰", "子": "申", "辰": "戌",
    "巳": "丑", "酉": "巳", "丑": "酉",
    "亥": "未", "卯": "亥", "未": "卯"
  };
  return map[baseZhi];
}

// 28. 喪門
function shensha_sangmen(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "辰", "午": "申", "戌": "子",
    "申": "戌", "子": "寅", "辰": "午",
    "巳": "未", "酉": "亥", "丑": "卯",
    "亥": "丑", "卯": "巳", "未": "酉"
  };
  return map[baseZhi];
}

// 29. 飛廉
function shensha_feilian(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 30. 天馬
function shensha_tianma(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "申": "寅", "子": "寅", "辰": "寅",
    "寅": "申", "午": "申", "戌": "申",
    "巳": "亥", "酉": "亥", "丑": "亥",
    "亥": "巳", "卯": "巳", "未": "巳"
  };
  return map[baseZhi];
}

// 31. 天福
function shensha_tianfu(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 32. 天魁
function shensha_tiankui(dayGan: string): string[] {
  return {
    "甲": ["丑"], "乙": ["子"], "丙": ["亥"], "丁": ["酉"],
    "戊": ["丑"], "己": ["子"], "庚": ["未"], "辛": ["午"],
    "壬": ["巳"], "癸": ["卯"]
  }[dayGan] || [];
}

// 33. 天鉞
function shensha_tianyue(dayGan: string): string[] {
  return {
    "甲": ["未"], "乙": ["申"], "丙": ["酉"], "丁": ["亥"],
    "戊": ["未"], "己": ["申"], "庚": ["丑"], "辛": ["子"],
    "壬": ["卯"], "癸": ["巳"]
  }[dayGan] || [];
}

// 34. 天赦
function shensha_tianshe(monthZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "戌", "卯": "戌", "辰": "戌",
    "巳": "戌", "午": "戌", "未": "戌",
    "申": "戌", "酉": "戌", "戌": "戌",
    "亥": "戌", "子": "戌", "丑": "戌"
  };
  return map[monthZhi];
}

// 35. 月德合
function shensha_yuedehe(monthZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "丁", "卯": "戊", "辰": "己",
    "巳": "庚", "午": "辛", "未": "壬",
    "申": "癸", "酉": "甲", "戌": "乙",
    "亥": "丙", "子": "丁", "丑": "戊"
  };
  return map[monthZhi];
}

// 36. 天德合
function shensha_tiandehe(monthZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "丁", "卯": "戊", "辰": "己",
    "巳": "庚", "午": "辛", "未": "壬",
    "申": "癸", "酉": "甲", "戌": "乙",
    "亥": "丙", "子": "丁", "丑": "戊"
  };
  return map[monthZhi];
}

// 37. 天德貴人
function shensha_tiandeguiren(dayGan: string): string[] {
  return {
    "甲": ["寅"], "乙": ["卯"], "丙": ["巳"], "丁": ["午"],
    "戊": ["巳"], "己": ["午"], "庚": ["申"], "辛": ["酉"],
    "壬": ["亥"], "癸": ["子"]
  }[dayGan] || [];
}

// 38. 月德貴人
function shensha_yuedeguiren(dayGan: string): string[] {
  return {
    "甲": ["申"], "乙": ["酉"], "丙": ["亥"], "丁": ["子"],
    "戊": ["亥"], "己": ["子"], "庚": ["寅"], "辛": ["卯"],
    "壬": ["巳"], "癸": ["午"]
  }[dayGan] || [];
}

// 39. 天廟
function shensha_tianmiao(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "戌", "午": "辰", "戌": "申",
    "申": "辰", "子": "申", "辰": "戌",
    "巳": "丑", "酉": "巳", "丑": "酉",
    "亥": "未", "卯": "亥", "未": "卯"
  };
  return map[baseZhi];
}

// 40. 天市
function shensha_tianshi(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "辰", "午": "申", "戌": "子",
    "申": "戌", "子": "寅", "辰": "午",
    "巳": "未", "酉": "亥", "丑": "卯",
    "亥": "丑", "卯": "巳", "未": "酉"
  };
  return map[baseZhi];
}

// 41. 天貴星
function shensha_tianguixing(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "子", "午": "辰", "戌": "申",
    "申": "辰", "子": "申", "辰": "子",
    "巳": "丑", "酉": "巳", "丑": "酉",
    "亥": "未", "卯": "亥", "未": "卯"
  };
  return map[baseZhi];
}

// 42. 天壽
function shensha_tianshou(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 43. 天壽貴人
function shensha_tianshouguiren(dayGan: string): string[] {
  return {
    "甲": ["寅"], "乙": ["卯"], "丙": ["巳"], "丁": ["午"],
    "戊": ["巳"], "己": ["午"], "庚": ["申"], "辛": ["酉"],
    "壬": ["亥"], "癸": ["子"]
  }[dayGan] || [];
}

// 44. 天馬貴人
function shensha_tianmaguiren(dayGan: string): string[] {
  return {
    "甲": ["申"], "乙": ["酉"], "丙": ["亥"], "丁": ["子"],
    "戊": ["亥"], "己": ["子"], "庚": ["寅"], "辛": ["卯"],
    "壬": ["巳"], "癸": ["午"]
  }[dayGan] || [];
}

// 45. 天壽星
function shensha_tianshouxing(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 46. 天馬星
function shensha_tianmaxing(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "申": "寅", "子": "寅", "辰": "寅",
    "寅": "申", "午": "申", "戌": "申",
    "巳": "亥", "酉": "亥", "丑": "亥",
    "亥": "巳", "卯": "巳", "未": "巳"
  };
  return map[baseZhi];
}

// 47. 天馬將星
function shensha_tianmajiangxing(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 48. 天馬將軍
function shensha_tianmajiangjun(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 49. 天馬將帥
function shensha_tianmajiangshuai(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 50. 天馬將領
function shensha_tianmajiangling(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}
// 51. 天壽將星
function shensha_tianshoujiangxing(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 52. 天壽將軍
function shensha_tianshoujiangjun(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 53. 天壽將帥
function shensha_tianshoujiangshuai(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 54. 天壽將領
function shensha_tianshoujiangling(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 55. 天壽將帥星
function shensha_tianshoujiangshuaixing(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 56. 天壽將軍星
function shensha_tianshoujiangjunxing(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 57. 天壽將帥貴人
function shensha_tianshoujiangshuaiguiren(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 58. 天壽將軍貴人
function shensha_tianshoujiangjunguiren(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 59. 天壽將帥將星
function shensha_tianshoujiangshuaijiangxing(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 60. 天壽將軍將星
function shensha_tianshoujiangjunjiangxing(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "寅": "午", "午": "戌", "戌": "寅",
    "申": "子", "子": "辰", "辰": "申",
    "巳": "酉", "酉": "丑", "丑": "巳",
    "亥": "卯", "卯": "未", "未": "亥"
  };
  return map[baseZhi];
}

// 61. 羊刃（以日干查表）
function shensha_yangren(dayGan: string): string | undefined {
  const map: Record<string, string> = {
    "甲": "卯", "乙": "寅", "丙": "午", "丁": "巳",
    "戊": "午", "己": "巳", "庚": "酉", "辛": "申",
    "壬": "子", "癸": "亥"
  };
  return map[dayGan];
}

// 62. 劫煞（以年支三合局查表）
function shensha_jiesha(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "申": "巳", "子": "巳", "辰": "巳",  // 申子辰見巳
    "寅": "亥", "午": "亥", "戌": "亥",  // 寅午戌見亥
    "巳": "寅", "酉": "寅", "丑": "寅",  // 巳酉丑見寅
    "亥": "申", "卯": "申", "未": "申"   // 亥卯未見申
  };
  return map[baseZhi];
}

// 63. 災煞（以年支三合局查表）
function shensha_zaisha(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "申": "午", "子": "午", "辰": "午",  // 申子辰見午
    "寅": "子", "午": "子", "戌": "子",  // 寅午戌見子
    "巳": "卯", "酉": "卯", "丑": "卯",  // 巳酉丑見卯
    "亥": "酉", "卯": "酉", "未": "酉"   // 亥卯未見酉
  };
  return map[baseZhi];
}

// 64. 華蓋（以年支三合局墓庫查表）
function shensha_huagai(baseZhi: string): string | undefined {
  const map: Record<string, string> = {
    "申": "辰", "子": "辰", "辰": "辰",  // 申子辰見辰
    "寅": "戌", "午": "戌", "戌": "戌",  // 寅午戌見戌
    "巳": "丑", "酉": "丑", "丑": "丑",  // 巳酉丑見丑
    "亥": "未", "卯": "未", "未": "未"   // 亥卯未見未
  };
  return map[baseZhi];
}

// 65. 空亡（以日柱干支查旬空）
function shensha_kongwang(dayGan: string, dayZhi: string): string[] {
  // 六十甲子分為六旬，每旬缺兩個地支
  const stems = ['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
  const branches = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];

  // 計算日柱天干、地支的索引
  const ganIndex = stems.indexOf(dayGan);
  const zhiIndex = branches.indexOf(dayZhi);
  if (ganIndex === -1 || zhiIndex === -1) return [];

  // 計算本旬旬首（甲[支]）的地支索引
  // 用 (zhiIndex - ganIndex + 12) % 12 定位旬首（甲[支]），再加10、11得到空亡
  const xunStartZhiIndex = (zhiIndex - ganIndex + 12) % 12;

  // 每旬空兩個地支，位於旬首後10和11位
  const kong1Index = (xunStartZhiIndex + 10) % 12;
  const kong2Index = (xunStartZhiIndex + 11) % 12;

  return [branches[kong1Index], branches[kong2Index]];
}

// 66. 文昌貴人（以日干查表）
function shensha_wenchang(dayGan: string): string | undefined {
  const map: Record<string, string> = {
    "甲": "巳", "乙": "午", "丙": "申", "丁": "酉",
    "戊": "申", "己": "酉", "庚": "亥", "辛": "子",
    "壬": "寅", "癸": "卯"
  };
  return map[dayGan];
}

// 67. 魁罡（以日柱干支組合判斷，僅四組特定組合）
const KUIGANG_SET = new Set(["庚辰", "庚戌", "壬辰", "戊戌"]);
function shensha_kuigang(dayGan: string, dayZhi: string): boolean {
  const dayPillar = dayGan + dayZhi;
  return KUIGANG_SET.has(dayPillar);
}

function calculateShensha(p: PillarSet): string[] {
  const list: string[] = [];

  // 1. 天乙貴人
  const tmap = shensha_tianyiguiren(p.day.gan || '');
  Object.values(p).forEach((x: Pillar) => {
    if (x?.zhi && tmap.includes(x.zhi) && !list.includes("天乙貴人")) list.push("天乙貴人");
  });

  // 2. 桃花
  const peach = shensha_taohua(p.year.zhi || '');
  Object.values(p).forEach((x: Pillar) => {
    if (x?.zhi === peach && !list.includes("桃花")) list.push("桃花");
  });

  // 3. 驛馬
  const yima = shensha_yima(p.year.zhi || '');
  Object.values(p).forEach((x: Pillar) => {
    if (x?.zhi === yima && !list.includes("驛馬")) list.push("驛馬");
  });

  // 4. 紅鸞
  const hongluan = shensha_hongluan(p.year.zhi || '');
  Object.values(p).forEach((x: Pillar) => {
    if (x?.zhi === hongluan && !list.includes("紅鸞")) list.push("紅鸞");
  });

  // 5. 咸池
  const xianchi = shensha_xianchi(p.year.zhi || '');
  Object.values(p).forEach((x: Pillar) => {
    if (x?.zhi === xianchi && !list.includes("咸池")) list.push("咸池");
  });

  // 6. 孤辰
  const guchen = shensha_guchen(p.day.zhi || '');
  Object.values(p).forEach((x: Pillar) => {
    if (x?.zhi === guchen && !list.includes("孤辰")) list.push("孤辰");
  });

  // 7. 寡宿
  const guasu = shensha_guasu(p.day.zhi || '');
  Object.values(p).forEach((x: Pillar) => {
    if (x?.zhi === guasu && !list.includes("寡宿")) list.push("寡宿");
  });

  // 8. 天德
  const tiande = shensha_tiande(p.month.zhi || '');
  if ([p.year.gan, p.month.gan, p.day.gan, p.hour.gan].includes(tiande ?? '') && !list.includes("天德")) list.push("天德");

  // 9. 月德
  const yuede = shensha_yuede(p.month.zhi || '');
  if ([p.year.gan, p.month.gan, p.day.gan, p.hour.gan].includes(yuede ?? '') && !list.includes("月德")) list.push("月德");

  // 10. 亡神
  const wangshen = shensha_wangshen(p.year.zhi || '');
  Object.values(p).forEach(x => {
    if (x.zhi === wangshen && !list.includes("亡神")) list.push("亡神");
  });

  // 11. 吊客
  const diaoke = shensha_diaoke(p.year.zhi || '');
  Object.values(p).forEach(x => {
    if (x.zhi === diaoke && !list.includes("吊客")) list.push("吊客");
  });

  // 12. 血刃
  const xueren = shensha_xueren(p.year.zhi || '');
  Object.values(p).forEach(x => {
    if (x.zhi === xueren && !list.includes("血刃")) list.push("血刃");
  });

  // 13. 白虎
  const baihu = shensha_baihu(p.year.zhi || '');
  Object.values(p).forEach(x => {
    if (x.zhi === baihu && !list.includes("白虎")) list.push("白虎");
  });

  // 14. 天喜
  const tianxi = shensha_tianxi(p.year.zhi || '');
  Object.values(p).forEach(x => {
    if (x.zhi === tianxi && !list.includes("天喜")) list.push("天喜");
  });

  // 15. 天官
  const tianguan = shensha_tianguan(p.year.zhi || '');
  Object.values(p).forEach(x => {
    if (x.zhi === tianguan && !list.includes("天官")) list.push("天官");
  });

  // 16. 天廚
  const tianchu = shensha_tianchu(p.year.zhi || '');
  Object.values(p).forEach(x => {
    if (x.zhi === tianchu && !list.includes("天廚")) list.push("天廚");
  });

  // 17. 太陰
  const taiyin = shensha_taiyin(p.year.zhi || '');
  Object.values(p).forEach(x => {
    if (x.zhi === taiyin && !list.includes("太陰")) list.push("太陰");
  });

  // 18. 太極貴人
  const taiji = shensha_taiji(p.year.zhi || '');
  Object.values(p).forEach(x => {
    if (x.zhi === taiji && !list.includes("太極貴人")) list.push("太極貴人");
  });

  // 19. 將星
  const jiangxing = shensha_jiangxing(p.year.zhi || '');
  Object.values(p).forEach(x => {
    if (x.zhi === jiangxing && !list.includes("將星")) list.push("將星");
  });

  // 20. 金輿
  const jinyu = shensha_jinyu(p.year.zhi || '');
  Object.values(p).forEach(x => {
    if (x.zhi === jinyu && !list.includes("金輿")) list.push("金輿");
  });

     // 21. 福德
  const fude = shensha_fude(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === fude && !list.includes("福德")) list.push("福德");
  });

  // 22. 天貴
  const tiangui = shensha_tiangui(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tiangui && !list.includes("天貴")) list.push("天貴");
  });

  // 23. 地煞
  const disha = shensha_disha(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === disha && !list.includes("地煞")) list.push("地煞");
  });

  // 24. 陰煞
  const yinsha = shensha_yinsha(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === yinsha && !list.includes("陰煞")) list.push("陰煞");
  });

  // 25. 劍鋒
  const jianfeng = shensha_jianfeng(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === jianfeng && !list.includes("劍鋒")) list.push("劍鋒");
  });

  // 26. 天狗
  const tiangou = shensha_tiangou(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tiangou && !list.includes("天狗")) list.push("天狗");
  });

  // 27. 天刑
  const tianxing = shensha_tianxing(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianxing && !list.includes("天刑")) list.push("天刑");
  });

  // 28. 喪門
  const sangmen = shensha_sangmen(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === sangmen && !list.includes("喪門")) list.push("喪門");
  });

  // 29. 飛廉
  const feilian = shensha_feilian(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === feilian && !list.includes("飛廉")) list.push("飛廉");
  });

  // 30. 天馬
  const tianma = shensha_tianma(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianma && !list.includes("天馬")) list.push("天馬");
  });

  // 31. 天福
  const tianfu = shensha_tianfu(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianfu && !list.includes("天福")) list.push("天福");
  });

  // 32. 天魁
  const tiankui = shensha_tiankui(p.day.gan);
  Object.values(p).forEach(x => {
    if (tiankui.includes(x.zhi) && !list.includes("天魁")) list.push("天魁");
  });

  // 33. 天鉞
  const tianyue = shensha_tianyue(p.day.gan);
  Object.values(p).forEach(x => {
    if (tianyue.includes(x.zhi) && !list.includes("天鉞")) list.push("天鉞");
  });

  // 34. 天赦
  const tianshe = shensha_tianshe(p.month.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshe && !list.includes("天赦")) list.push("天赦");
  });

  // 35. 月德合
  const yuedehe = shensha_yuedehe(p.month.zhi);
  if ([p.year.gan, p.month.gan, p.day.gan, p.hour.gan].includes(yuedehe ?? '') && !list.includes("月德合")) list.push("月德合");

  // 36. 天德合
  const tiandehe = shensha_tiandehe(p.month.zhi);
  if ([p.year.gan, p.month.gan, p.day.gan, p.hour.gan].includes(tiandehe ?? '') && !list.includes("天德合")) list.push("天德合");

  // 37. 天德貴人
  const tiandeguiren = shensha_tiandeguiren(p.day.gan);
  Object.values(p).forEach(x => {
    if (tiandeguiren.includes(x.zhi) && !list.includes("天德貴人")) list.push("天德貴人");
  });

  // 38. 月德貴人
  const yuedeguiren = shensha_yuedeguiren(p.day.gan);
  Object.values(p).forEach(x => {
    if (yuedeguiren.includes(x.zhi) && !list.includes("月德貴人")) list.push("月德貴人");
  });

  // 39. 天廟
  const tianmiao = shensha_tianmiao(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianmiao && !list.includes("天廟")) list.push("天廟");
  });

  // 40. 天市
  const tianshi = shensha_tianshi(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshi && !list.includes("天市")) list.push("天市");
  });

  // 41. 天貴星
  const tianguixing = shensha_tianguixing(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianguixing && !list.includes("天貴星")) list.push("天貴星");
  });

  // 42. 天壽
  const tianshou = shensha_tianshou(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshou && !list.includes("天壽")) list.push("天壽");
  });

  // 43. 天壽貴人
  const tianshouguiren = shensha_tianshouguiren(p.day.gan);
  Object.values(p).forEach(x => {
    if (tianshouguiren.includes(x.zhi) && !list.includes("天壽貴人")) list.push("天壽貴人");
  });

  // 44. 天馬貴人
  const tianmaguiren = shensha_tianmaguiren(p.day.gan);
  Object.values(p).forEach(x => {
    if (tianmaguiren.includes(x.zhi) && !list.includes("天馬貴人")) list.push("天馬貴人");
  });

  // 45. 天壽星
  const tianshouxing = shensha_tianshouxing(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshouxing && !list.includes("天壽星")) list.push("天壽星");
  });

  // 46. 天馬星
  const tianmaxing = shensha_tianmaxing(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianmaxing && !list.includes("天馬星")) list.push("天馬星");
  });

  // 47. 天馬將星
  const tianmajiangxing = shensha_tianmajiangxing(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianmajiangxing && !list.includes("天馬將星")) list.push("天馬將星");
  });

  // 48. 天馬將軍
  const tianmajiangjun = shensha_tianmajiangjun(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianmajiangjun && !list.includes("天馬將軍")) list.push("天馬將軍");
  });

    // 49. 天馬將帥
  const tianmajiangshuai = shensha_tianmajiangshuai(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianmajiangshuai && !list.includes("天馬將帥")) list.push("天馬將帥");
  });

  // 50. 天馬將領
  const tianmajiangling = shensha_tianmajiangling(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianmajiangling && !list.includes("天馬將領")) list.push("天馬將領");
  });

  // 51. 天壽將星
  const tianshoujiangxing = shensha_tianshoujiangxing(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshoujiangxing && !list.includes("天壽將星")) list.push("天壽將星");
  });

  // 52. 天壽將軍
  const tianshoujiangjun = shensha_tianshoujiangjun(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshoujiangjun && !list.includes("天壽將軍")) list.push("天壽將軍");
  });

  // 53. 天壽將帥
  const tianshoujiangshuai = shensha_tianshoujiangshuai(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshoujiangshuai && !list.includes("天壽將帥")) list.push("天壽將帥");
  });

  // 54. 天壽將領
  const tianshoujiangling = shensha_tianshoujiangling(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshoujiangling && !list.includes("天壽將領")) list.push("天壽將領");
  });

  // 55. 天壽將帥星
  const tianshoujiangshuaixing = shensha_tianshoujiangshuaixing(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshoujiangshuaixing && !list.includes("天壽將帥星")) list.push("天壽將帥星");
  });

  // 56. 天壽將軍星
  const tianshoujiangjunxing = shensha_tianshoujiangjunxing(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshoujiangjunxing && !list.includes("天壽將軍星")) list.push("天壽將軍星");
  });

  // 57. 天壽將帥貴人
  const tianshoujiangshuaiguiren = shensha_tianshoujiangshuaiguiren(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshoujiangshuaiguiren && !list.includes("天壽將帥貴人")) list.push("天壽將帥貴人");
  });

  // 58. 天壽將軍貴人
  const tianshoujiangjunguiren = shensha_tianshoujiangjunguiren(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshoujiangjunguiren && !list.includes("天壽將軍貴人")) list.push("天壽將軍貴人");
  });

  // 59. 天壽將帥將星
  const tianshoujiangshuaijiangxing = shensha_tianshoujiangshuaijiangxing(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshoujiangshuaijiangxing && !list.includes("天壽將帥將星")) list.push("天壽將帥將星");
  });

  // 60. 天壽將軍將星
  const tianshoujiangjunjiangxing = shensha_tianshoujiangjunjiangxing(p.year.zhi);
  Object.values(p).forEach(x => {
    if (x.zhi === tianshoujiangjunjiangxing && !list.includes("天壽將軍將星")) list.push("天壽將軍將星");
  });

  // 61. 羊刃
  const yangren = shensha_yangren(p.day.gan);
  if (yangren && zhis.has(yangren) && !list.includes("羊刃")) list.push("羊刃");

  // 62. 劫煞
  const jiesha = shensha_jiesha(p.year.zhi);
  if (jiesha && zhis.has(jiesha) && !list.includes("劫煞")) list.push("劫煞");

  // Precompute Set of the four zhi for efficient membership checks
  const zhis = new Set(Object.values(p).map(x => x.zhi));

  // 63. 災煞
  const zaisha = shensha_zaisha(p.year.zhi);
  if (zaisha && zhis.has(zaisha) && !list.includes("災煞")) list.push("災煞");

  // 64. 華蓋
  const huagai = shensha_huagai(p.year.zhi);
  if (huagai && zhis.has(huagai) && !list.includes("華蓋")) list.push("華蓋");

  // 65. 空亡
  const kongwangList = shensha_kongwang(p.day.gan, p.day.zhi);
  if (kongwangList.some(zhi => zhis.has(zhi)) && !list.includes("空亡")) list.push("空亡");

  // 66. 文昌貴人
  const wenchang = shensha_wenchang(p.day.gan);
  if (wenchang && zhis.has(wenchang) && !list.includes("文昌貴人")) list.push("文昌貴人");

  // 67. 魁罡
  if (shensha_kuigang(p.day.gan, p.day.zhi) && !list.includes("魁罡")) {
    list.push("魁罡");
  }

  return list.length ? list : ["（本盤暫無核心神煞）"];
}

// 專業八字計算器（收斂於單一類別）
export class ProfessionalBaziCalculator {
  public stems: string[] = ['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
  public branches: string[] = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
  public wuhuDun = WUHU_DUN;
  public wushuDun = WUSHU_DUN;
  public hiddenStems = HIDDEN_STEMS;
  public tenGodsTable = TEN_GODS;

  // 天干、地支到五行/陰陽對照
  public wuxingMap: Record<string, { element: string; yin_yang: string }> = {
    // 天干
    '甲': { element: '木', yin_yang: '陽' }, '乙': { element: '木', yin_yang: '陰' },
    '丙': { element: '火', yin_yang: '陽' }, '丁': { element: '火', yin_yang: '陰' },
    '戊': { element: '土', yin_yang: '陽' }, '己': { element: '土', yin_yang: '陰' },
    '庚': { element: '金', yin_yang: '陽' }, '辛': { element: '金', yin_yang: '陰' },
    '壬': { element: '水', yin_yang: '陽' }, '癸': { element: '水', yin_yang: '陰' },
    // 地支
    '子': { element: '水', yin_yang: '陽' }, '丑': { element: '土', yin_yang: '陰' },
    '寅': { element: '木', yin_yang: '陽' }, '卯': { element: '木', yin_yang: '陰' },
    '辰': { element: '土', yin_yang: '陽' }, '巳': { element: '火', yin_yang: '陰' },
    '午': { element: '火', yin_yang: '陽' }, '未': { element: '土', yin_yang: '陰' },
    '申': { element: '金', yin_yang: '陽' }, '酉': { element: '金', yin_yang: '陰' },
    '戌': { element: '土', yin_yang: '陽' }, '亥': { element: '水', yin_yang: '陰' }
  };

  /** 計算月柱（根據節氣，簡化版） */
  public calculateMonthPillar(time: { month: number; day: number }, yearStem: string): MonthPillarResult {
    const monthBranch = this.getMonthBranch(time.month, time.day);
    const monthBranchIndex = this.branches.indexOf(monthBranch);
    const monthGanzhi = this.wuhuDun[yearStem]?.[monthBranchIndex] ?? '';
    return {
      stem: monthGanzhi[0] ?? '',
      branch: monthGanzhi[1] ?? '',
      solarTerm: this.getCurrentSolarTerm(time.month, time.day)
    };
  }

  /** 以月份取月支（簡化） */
  public getMonthBranch(month: number, _day: number): string {
    return this.branches[(month - 1 + 12) % 12];
  }

  /** 查詢節氣名（簡化） */
  public getCurrentSolarTerm(month: number, _day: number): string {
    const terms = ['立春','雨水','驚蟄','春分','清明','穀雨',
      '立夏','小滿','芒種','夏至','小暑','大暑',
      '立秋','處暑','白露','秋分','寒露','霜降',
      '立冬','小雪','大雪','冬至','小寒','大寒'];
    return terms[(month - 1) * 2] || '';
  }

  /** 計算日柱（1900-01-31 為甲子日基準，簡化） */
  public calculateDayPillar(time: { year: number; month: number; day: number }): DayPillarResult {
    const baseDate = new Date(1900, 0, 31);
    const targetDate = new Date(time.year, time.month - 1, time.day);
    const daysDiff = Math.floor((targetDate.getTime() - baseDate.getTime()) / (1000 * 60 * 60 * 24));
    const stemIndex = ((daysDiff % 10) + 10) % 10;
    const branchIndex = ((daysDiff % 12) + 12) % 12;
    return {
      stem: this.stems[stemIndex],
      branch: this.branches[branchIndex],
      dayNumber: daysDiff
    };
  }

  /** 計算時柱（以五鼠遁時配干，簡化） */
  public calculateHourPillar(time: { hour: number }, dayStem: string): HourPillarResult {
    const h = time.hour;
    let hourBranchIndex = 0;
    if (h === 23 || h === 0) hourBranchIndex = 0;
    else if (h === 1 || h === 2) hourBranchIndex = 1;
    else if (h === 3 || h === 4) hourBranchIndex = 2;
    else if (h === 5 || h === 6) hourBranchIndex = 3;
    else if (h === 7 || h === 8) hourBranchIndex = 4;
    else if (h === 9 || h === 10) hourBranchIndex = 5;
    else if (h === 11 || h === 12) hourBranchIndex = 6;
    else if (h === 13 || h === 14) hourBranchIndex = 7;
    else if (h === 15 || h === 16) hourBranchIndex = 8;
    else if (h === 17 || h === 18) hourBranchIndex = 9;
    else if (h === 19 || h === 20) hourBranchIndex = 10;
    else if (h === 21 || h === 22) hourBranchIndex = 11;
    const hourGanzhi = this.wushuDun[dayStem]?.[hourBranchIndex] ?? '';
    return { stem: hourGanzhi[0] ?? '', branch: hourGanzhi[1] ?? '', hourIndex: hourBranchIndex };
  }

  /** 五行分布（含藏干，簡化） */
  public calculateWuxingDistribution(fourPillars: PillarSet): { raw: ElementDistribution; percentage: ElementPercentage; total: number } {
    const distribution: ElementDistribution = { 木: 0, 火: 0, 土: 0, 金: 0, 水: 0 };
    Object.values(fourPillars).forEach((pillar: Pillar) => {
      const stem = pillar.gan ?? pillar.stem ?? '';
      const el = this.wuxingMap[stem]?.element;
      if (el) distribution[el] += 1;
    });
    Object.values(fourPillars).forEach((pillar: Pillar) => {
      const branch = pillar.zhi ?? pillar.branch ?? '';
      const el = this.wuxingMap[branch]?.element;
      if (el) distribution[el] += 1;
    });
    Object.values(fourPillars).forEach((pillar: Pillar) => {
      const branch = pillar.zhi ?? pillar.branch ?? '';
      const hids = this.hiddenStems[branch] || [];
      hids.forEach(h => {
        const el = this.wuxingMap[h.stem]?.element;
        if (el) distribution[el] += h.ratio / 100;
      });
    });
    const total = Object.values(distribution).reduce((a, b) => a + b, 0);
    const percentage: ElementPercentage = { 木: '0', 火: '0', 土: '0', 金: '0', 水: '0' };
    (Object.keys(distribution) as FiveElement[]).forEach(k => {
      percentage[k] = total ? ((distribution[k] / total) * 100).toFixed(1) : '0';
    });
    return { raw: distribution, percentage, total };
  }

  /** 十神分布（簡化） */
  public calculateTenGods(fourPillars: PillarSet): TenGodSummary {
    const dayStem = fourPillars.day.gan ?? fourPillars.day.stem ?? '';
    const dayElement = this.wuxingMap[dayStem]?.element ?? '';
    const dayYinYang = this.wuxingMap[dayStem]?.yin_yang ?? '';
    const tenGods: TenGodCount = {
      比肩: 0, 劫財: 0, 食神: 0, 傷官: 0,
      正財: 0, 偏財: 0, 正官: 0, 七殺: 0, 正印: 0, 偏印: 0
    };
    const details: TenGodDetail[] = [];
    Object.entries(fourPillars).forEach(([pos, pillar]) => {
      if (pos === 'day') return;
      const s = pillar.gan ?? pillar.stem ?? '';
      const el = this.wuxingMap[s]?.element ?? '';
      const yy = this.wuxingMap[s]?.yin_yang ?? '';
      const god = this.getTenGod(dayElement, dayYinYang, el, yy);
      if (god) tenGods[god]++;
  details.push({ position: pos as keyof PillarSet, stem: s, god });
    });
    Object.values(fourPillars).forEach(pillar => {
      const branch = pillar.zhi ?? pillar.branch ?? '';
      const hids = this.hiddenStems[branch] || [];
      hids.forEach(h => {
        const el = this.wuxingMap[h.stem]?.element ?? '';
        const yy = this.wuxingMap[h.stem]?.yin_yang ?? '';
        const god = this.getTenGod(dayElement, dayYinYang, el, yy);
        if (god) tenGods[god] += h.ratio / 100;
      });
    });
    return { distribution: tenGods, details };
  }

  /** 取得十神名稱 */
  public getTenGod(dayElement: string, dayYinYang: string, targetElement: string, targetYinYang: string): TenGodName | '' {
    const rel = this.tenGodsTable[dayElement]?.[targetElement];
    if (!rel) return '';
    const same = dayYinYang === targetYinYang;
    return rel[same ? '陽' : '陰'] || '';
  }

  /** 自我認識：綜合分析（不涉未來） */
  public analyzeSelf(fourPillars: PillarSet): SelfAnalysis {
    const wuxing = this.calculateWuxingDistribution(fourPillars);
    const dayStem = fourPillars.day.gan ?? fourPillars.day.stem ?? '';
    const dayElement = this.wuxingMap[dayStem]?.element ?? '';
    const dayStrength = parseFloat(wuxing.percentage[dayElement] ?? '0');
  let dayStatus: '偏旺' | '普通' | '偏弱' = '普通';
    if (dayStrength >= 35) dayStatus = '偏旺';
    else if (dayStrength <= 15) dayStatus = '偏弱';
    const tianyi = shensha_tianyiguiren(dayStem || '');
    const taohua = shensha_taohua(fourPillars.day.zhi || '') ?? '';
    const yima = shensha_yima(fourPillars.day.zhi || '') ?? '';
    const pattern = dayStatus === '偏旺' ? '身旺格局' : dayStatus === '偏弱' ? '身弱格局' : '普通格局';
    const tenGods = this.calculateTenGods(fourPillars);
    const shenshaList = calculateShensha(fourPillars);
    return {
      五行分布: wuxing.percentage,
      日主: dayStem,
      日主五行: dayElement,
      日主旺衰: dayStatus,
      格局: pattern,
      天乙貴人: tianyi,
      桃花: taohua,
      驛馬: yima,
      十神分布: tenGods.distribution,
      十神明細: tenGods.details,
      神煞: shenshaList,
      四時軍團: this.getFourSeasonsTeam(fourPillars)
    };
  }

  // ===== 四時軍團 =====
  private seasonByBranch: Record<string, SeasonCycle> = {
    '寅':'春','卯':'春','辰':'春',
    '巳':'夏','午':'夏','未':'夏',
    '申':'秋','酉':'秋','戌':'秋',
    '亥':'冬','子':'冬','丑':'冬'
  };

  public getSeasonByBranch(branch: string): SeasonCycle {
    return this.seasonByBranch[branch] ?? '春';
  }

  public calculateSeasonDistribution(p: PillarSet): SeasonDistribution {
    const dist: Record<SeasonCycle, number> = { '春':0,'夏':0,'秋':0,'冬':0 };
    const seasonYear = this.getSeasonByBranch(p.year.zhi);
    const seasonMonth = this.getSeasonByBranch(p.month.zhi);
    const seasonDay = this.getSeasonByBranch(p.day.zhi);
    const seasonHour = this.getSeasonByBranch(p.hour.zhi);
    // 權重：月支 2，其餘 1（可之後調整為設定）
    dist[seasonYear] += 1;
    dist[seasonMonth] += 2;
    dist[seasonDay] += 1;
    dist[seasonHour] += 1;
    const total = Object.values(dist).reduce((a,b)=>a+b,0);
    const percentage: Record<SeasonCycle, string> = { '春':'0','夏':'0','秋':'0','冬':'0' };
    (Object.keys(dist) as Array<SeasonCycle>).forEach(k=>{
      percentage[k] = total ? ((dist[k]/total)*100).toFixed(1) : '0';
    });
    return {
      seasonByPillar: { year: seasonYear, month: seasonMonth, day: seasonDay, hour: seasonHour },
      raw: dist,
      percentage,
      total
    };
  }

  private fourSeasonsProfiles: Record<SeasonCycle, { keywords: string[]; strengths: string[]; blindspots: string[]; tips: string[] }> = {
    '春': {
      keywords: ['生發','創新','學習','規劃'],
      strengths: ['啟動力強','適合開創新題','善於連結資源','成長導向'],
      blindspots: ['容易虎頭蛇尾','規劃過多執行不足','耐心略弱'],
      tips: ['鎖定1-2個關鍵目標','設里程碑與回顧節奏','與執行型夥伴配對']
    },
    '夏': {
      keywords: ['熱情','行動','表達','領導'],
      strengths: ['爆發力強','影響力高','擅長溝通號召','敢於承擔'],
      blindspots: ['衝動決策','忽略細節','能量易過載'],
      tips: ['先做風險清單','安排恢復與休息','以數據/清單補足細節']
    },
    '秋': {
      keywords: ['條理','效率','規範','決斷'],
      strengths: ['結構化能力強','優化流程','注重品質','善收斂與交付'],
      blindspots: ['過度嚴格','創意不足','對變動不安'],
      tips: ['保留探索空間','用原型驗證取代一次到位','與創意型夥伴合作']
    },
    '冬': {
      keywords: ['內省','沉穩','專注','研究'],
      strengths: ['深入研究','韌性高','能長期專注','風險意識強'],
      blindspots: ['行動慢熱','不易求助','容易自我懷疑'],
      tips: ['以小步快跑取代完美主義','建立定期分享','設定求助與互動節點']
    }
  };

  public getFourSeasonsTeam(p: PillarSet): FourSeasonsTeam {
    const dist = this.calculateSeasonDistribution(p);
    // 軍團以「月支所屬季節」為主
    const team = dist.seasonByPillar.month;
    const profile = this.fourSeasonsProfiles[team];
    return {
      team,
      seasonByPillar: dist.seasonByPillar,
      distribution: dist.percentage,
      keywords: profile.keywords,
      strengths: profile.strengths,
      blindspots: profile.blindspots,
      tips: profile.tips
    };
  }
}
