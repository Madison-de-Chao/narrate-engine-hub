import express from "express";
import repo from "../repository";
import { ProfessionalBaziCalculator } from "../../lookup-calculator";
import { generateChart } from "../../storyEngine/chartEngine";
import { generateArmyNarrative } from "../../storyEngine/generateArmyNarrative";
import {
  NAYIN,
  CANG_GAN,
  getTenGod,
  type ChartData,
} from "../../storyEngine/utils";

const router = express.Router();

interface GenerateBaziRequest {
  name: string;
  birthday: string;
  sex: "M" | "F";
  location: string;
  timezone?: string;
  options?: {
    debug?: boolean;
    useTrueSolarTime?: boolean;
    use_early_zi?: boolean;
    longitude?: number;
    flowType?: "標準" | "極限邊界" | "全細節";
  };
}

router.post("/generate", (req, res) => {
  const body = req.body as GenerateBaziRequest;
  try {
    // 1) 建 user_profile
    const { user_id } = repo.createUser({
      name: body.name,
      birthday: body.birthday,
      sex: body.sex,
      location: body.location,
      timezone: body.timezone,
    });

    // 2) 解析生日時間，使用新的專業計算器
    const raw = body.birthday;
    const m = raw.match(
      /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?(?:([+-]\d{2}):?(\d{2}))?$/,
    );
    let yyyy: number,
      mm: number,
      dd: number,
      hh: number,
      min: number = 0;
    if (m) {
      yyyy = parseInt(m[1], 10);
      mm = parseInt(m[2], 10);
      dd = parseInt(m[3], 10);
      hh = parseInt(m[4], 10);
      min = parseInt(m[5] || "0", 10);
    } else {
      const dt = new Date(raw);
      yyyy = dt.getFullYear();
      mm = dt.getMonth() + 1;
      dd = dt.getDate();
      hh = dt.getHours();
      min = dt.getMinutes();
    }

    // 使用專業計算器進行八字計算
    const calculator = new ProfessionalBaziCalculator();
    const baziOptions = {
      use_early_zi: body.options?.use_early_zi || false,
      use_true_solar_time: body.options?.useTrueSolarTime || false,
      longitude: body.options?.longitude,
      debug: body.options?.debug || false,
    };

    const baziResult = calculator.calculateBazi(
      yyyy,
      mm,
      dd,
      hh,
      min,
      baziOptions,
    );

    // 3) 建 bazi_chart - 使用新計算結果
    const year = baziResult.year;
    const month = baziResult.month;
    const day = baziResult.day;
    const hour = baziResult.hour;

    // 從新的hiddenStems數據獲取藏干
    const getHiddenStems = (branch: string) => {
      try {
        const hiddenData = JSON.parse(
          require("fs").readFileSync(
            require("path").join(__dirname, "../../data/hidden_stems.json"),
            "utf8",
          ),
        );
        return (
          hiddenData.hiddenStems[branch]?.stems?.map((s: any) => s.stem) || []
        );
      } catch {
        return CANG_GAN[branch] || [];
      }
    };

    const year_hidden = JSON.stringify(getHiddenStems(year.branch));
    const month_hidden = JSON.stringify(getHiddenStems(month.branch));
    const day_hidden = JSON.stringify(getHiddenStems(day.branch));
    const hour_hidden = JSON.stringify(getHiddenStems(hour.branch));

    const { chart_id } = repo.createChart(user_id, {
      year_gan: year.stem,
      year_zhi: year.branch,
      month_gan: month.stem,
      month_zhi: month.branch,
      day_gan: day.stem,
      day_zhi: day.branch,
      hour_gan: hour.stem,
      hour_zhi: hour.branch,
      year_nayin: baziResult.nayin.year,
      month_nayin: baziResult.nayin.month,
      day_nayin: baziResult.nayin.day,
      hour_nayin: baziResult.nayin.hour,
      year_hidden_gan: year_hidden,
      month_hidden_gan: month_hidden,
      day_hidden_gan: day_hidden,
      hour_hidden_gan: hour_hidden,
      chart_json: JSON.stringify(baziResult),
    });

    // 4) 產出軍團卡、技能卡、納音卡、神煞卡、AI故事 - 使用新的計算結果
    const tenGods = baziResult.ten_gods;

    // 納音卡 - 使用新的納音結果
    (
      [
        { key: "year", nayin: baziResult.nayin.year },
        { key: "month", nayin: baziResult.nayin.month },
        { key: "day", nayin: baziResult.nayin.day },
        { key: "hour", nayin: baziResult.nayin.hour },
      ] as const
    ).forEach(({ key, nayin }) => {
      const element = nayin ? nayin.slice(-1) : "";
      repo.insertNayinCard(chart_id, {
        pillar: key,
        nayin_name: nayin,
        element,
        scene: "",
        buff: "",
        debuff: "",
        color: "",
      });
    });

    // 神煞卡 - 使用新的神煞結果
    baziResult.shensha.forEach((s) => {
      repo.insertShenshaCard(chart_id, {
        pillar: s.anchor_basis.includes("年")
          ? "year"
          : s.anchor_basis.includes("月")
            ? "month"
            : s.anchor_basis.includes("日")
              ? "day"
              : "hour",
        shensha_name: s.name,
        type: s.anchor_basis,
        trigger: s.source,
        buff: "",
        debuff: "",
        color: "",
        card_json: JSON.stringify({
          anchor_basis: s.anchor_basis,
          source: s.source,
        }),
      });
    });

    // AI 故事 - 使用四時軍團系統
    const pillarsForNarrative = {
      year: { gan: baziResult.year.stem, zhi: baziResult.year.branch, pillar: baziResult.year.stem + baziResult.year.branch },
      month: { gan: baziResult.month.stem, zhi: baziResult.month.branch, pillar: baziResult.month.stem + baziResult.month.branch },
      day: { gan: baziResult.day.stem, zhi: baziResult.day.branch, pillar: baziResult.day.stem + baziResult.day.branch },
      hour: { gan: baziResult.hour.stem, zhi: baziResult.hour.branch, pillar: baziResult.hour.stem + baziResult.hour.branch },
    };
    const armyNarrative = generateArmyNarrative(pillarsForNarrative);
    const narrativeLines = armyNarrative.narrative.split("\n");

    (["year", "month", "day", "hour"] as const).forEach((k, idx) => {
      const story = narrativeLines[idx] || `${k}軍團故事`;
      repo.insertStory(chart_id, {
        army_type: k,
        story_type: "軍團故事",
        story_text: story,
        summary: `${k}軍團`,
      });
      // Army card（示例）
      repo.insertArmyCard(chart_id, {
        army_type: k,
        role_type: "主將",
        gan_or_zhi: baziResult[k].stem,
        canggan: "",
        main_buff: "",
        main_debuff: "",
        rpg_job: "",
        color: "#999",
        card_json: "{}",
      });
    });

    // Skill cards（十神）
    tenGods.forEach((s) =>
      repo.insertSkillCard(chart_id, {
        skill_type: s.name,
        main_skill: s.name,
        skill_buff: "",
        skill_debuff: "",
        detail_json: JSON.stringify(s),
      }),
    );

    // 回傳 - 使用新的計算結果並包含詳細計算日誌
    res.json({
      success: true,
      user_id,
      chart_id,
      bazi: {
        year: [year.stem, year.branch],
        month: [month.stem, month.branch],
        day: [day.stem, day.branch],
        hour: [hour.stem, hour.branch],
      },
      // 包含完整的計算依據與細節步驟log
      calculation_details: baziOptions.debug
        ? baziResult.calculation_logs
        : undefined,
      five_elements: baziResult.five_elements,
      ten_gods: baziResult.ten_gods,
      nayin: baziResult.nayin,
      shensha: baziResult.shensha,
      // debug 額外回傳解析後的原始時間拆解（僅在 debug 模式）
      time_debug: baziOptions.debug
        ? {
            parsed: { yyyy, mm, dd, hh, min },
            source: raw,
            options: baziOptions,
          }
        : undefined,
      army_cards: [],
      skill_cards: tenGods.map((x) => ({
        type: x.name,
        basis: x.basis,
        calculation: x.calculation,
      })),
      ai_story: ["year", "month", "day", "hour"].map((k) => ({
        army_type: k,
        story: "...",
      })),
      debug_steps: baziOptions.debug
        ? {
            bazi_result: baziResult,
            solar_terms_used: baziResult.calculation_logs.solar_terms_log,
            calculation_method: "ProfessionalBaziCalculator with lookup tables",
          }
        : undefined,
    });
  } catch (e: unknown) {
    console.error("generate error:", e);
    const errorMessage = e instanceof Error ? e.message : "internal_error";
    res.status(500).json({ success: false, error: errorMessage });
  }
});

router.get("/story/:chart_id", (req, res) => {
  try {
    const id = Number(req.params.chart_id);
    const { stories } = repo.getChart(id);
    res.json({ stories });
  } catch (e: unknown) {
    const errorMessage = e instanceof Error ? e.message : "internal_error";
    res.status(500).json({ error: errorMessage });
  }
});

router.get("/chart/:chart_id", (req, res) => {
  try {
    const id = Number(req.params.chart_id);
    const { chart, stories, nayins, shensha } = repo.getChart(id);
    res.json({ chart, stories, nayins, shensha });
  } catch (e: unknown) {
    const errorMessage = e instanceof Error ? e.message : "internal_error";
    res.status(500).json({ error: errorMessage });
  }
});

router.get("/user/:user_id", (req, res) => {
  try {
    const uid = Number(req.params.user_id);
    const charts = repo.getChartsByUser(uid);
    res.json({ charts });
  } catch (e: unknown) {
    const errorMessage = e instanceof Error ? e.message : "internal_error";
    res.status(500).json({ error: errorMessage });
  }
});

// 神煞計算 endpoint
import ShenshaEngine from "../../storyEngine/shenshaEngine";

router.post("/compute", (req, res) => {
  try {
    const { chart, ruleset = "trad" } = req.body;

    if (!chart || !chart.year || !chart.month || !chart.day || !chart.hour) {
      return res.status(400).json({
        error:
          "Invalid chart data. Required: chart.year, chart.month, chart.day, chart.hour with stem and branch",
      });
    }

    // 驗證 ruleset
    if (ruleset !== "trad" && ruleset !== "legion") {
      return res.status(400).json({
        error: 'Invalid ruleset. Must be "trad" or "legion"',
      });
    }

    // 建立神煞引擎
    const engine = new ShenshaEngine(ruleset);

    // 計算神煞
    const shenshaMatches = engine.calculate(chart);

    // 統計資訊
    const stats = {
      total: shenshaMatches.length,
      list: shenshaMatches.map((m) => m.name),
    };

    res.json({
      success: true,
      data: {
        anchors: {
          shensha: shenshaMatches,
        },
        stats,
      },
      metadata: {
        ruleset,
        engine_version: "1.0",
        timestamp: new Date().toISOString(),
      },
    });
  } catch (e: unknown) {
    const errorMessage = e instanceof Error ? e.message : "internal_error";
    res.status(500).json({ error: errorMessage });
  }
});

router.get("/compute/info", (req, res) => {
  try {
    const ruleset = (req.query.ruleset as string) || "trad";

    // 驗證 ruleset
    if (ruleset !== "trad" && ruleset !== "legion") {
      return res.status(400).json({
        error: 'Invalid ruleset. Must be "trad" or "legion"',
      });
    }

    // 簡單示例：沒有chart就返回引擎資訊
    const engine = new ShenshaEngine(ruleset as "trad" | "legion");

    res.json({
      success: true,
      message:
        "Use POST /api/bazi/compute with chart data to calculate shensha",
      info: {
        ruleset,
        loaded_shensha_count: engine.getLoadedCount(),
        loaded_shensha_list: engine.getLoadedNames(),
      },
    });
  } catch (e: unknown) {
    const errorMessage = e instanceof Error ? e.message : "internal_error";
    res.status(500).json({ error: errorMessage });
  }
});

// 系統狀態 endpoint
import * as fs from "fs";
import * as path from "path";

router.get("/status", (req, res) => {
  try {
    const tradDir = path.join(__dirname, "../../storyEngine/data/shensha_trad");
    const legionDir = path.join(
      __dirname,
      "../../storyEngine/data/shensha_legion",
    );

    // 獲取目錄資訊
    const getTradModTime = () => {
      try {
        const stats = fs.statSync(tradDir);
        return stats.mtime.toISOString();
      } catch {
        return "N/A";
      }
    };

    const getLegionModTime = () => {
      try {
        const stats = fs.statSync(legionDir);
        return stats.mtime.toISOString();
      } catch {
        return "N/A";
      }
    };

    // 載入引擎統計
    const tradEngine = new ShenshaEngine("trad");
    const legionEngine = new ShenshaEngine("legion");

    res.json({
      success: true,
      system_info: {
        version: "1.0",
        timestamp: new Date().toISOString(),
      },
      rulesets: {
        trad: {
          directory: "storyEngine/data/shensha_trad",
          last_modified: getTradModTime(),
          loaded_count: tradEngine.getLoadedCount(),
          loaded_list: tradEngine.getLoadedNames(),
        },
        legion: {
          directory: "storyEngine/data/shensha_legion",
          last_modified: getLegionModTime(),
          loaded_count: legionEngine.getLoadedCount(),
          loaded_list: legionEngine.getLoadedNames(),
        },
      },
    });
  } catch (e: unknown) {
    const errorMessage = e instanceof Error ? e.message : "internal_error";
    res.status(500).json({ error: errorMessage });
  }
});

export default router;
