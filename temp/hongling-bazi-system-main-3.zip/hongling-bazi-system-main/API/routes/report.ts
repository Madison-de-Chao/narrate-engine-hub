import express from "express";
import { fmtPillars } from "../../storyEngine/utils";
import { getRepository } from "../config/repository";
import { reportRequestSchema } from "./schemas";

const router = express.Router();

router.post("/", async (req, res): Promise<void> => {
  try {
    // Validate input using Zod schema
    const validationResult = reportRequestSchema.safeParse(req.body);

    if (!validationResult.success) {
      console.warn("[report] 輸入驗證失敗：", validationResult.error.issues);
      res.status(400).json({
        error: "輸入資料格式錯誤",
        details: validationResult.error.issues,
      });
      return;
    }

    const { chart, narrative } = validationResult.data;

    // Asynchronously get repository instance
    const repo = await getRepository();

    if (repo) {
      try {
        await repo.saveReport(
          chart.pillars,
          chart.tone || "default",
          narrative,
        );
      } catch (e) {
        console.warn("[report] 儲存 PostgreSQL 失敗：", (e as Error).message);
      }
    }

    // Render using EJS template with proper escaping
    res.render("report", {
      chart,
      narrative,
      fmtPillars,
    });
  } catch (err) {
    console.error("報告匯出錯誤：", err);
    res.status(500).json({
      error: "報告生成失敗",
      message: err instanceof Error ? err.message : "Unknown error",
    });
  }
});

export default router;
