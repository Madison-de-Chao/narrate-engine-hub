// generateArmyNarrative.ts
import type { PillarSet } from "./utils";

const gan2General: Record<string, string> = {
  甲: "森林將軍",
  乙: "花草軍師",
  丙: "烈日戰神",
  丁: "燭光法師",
  戊: "山岳守護",
  己: "大地母親",
  庚: "鋼鐵騎士",
  辛: "珠寶商人",
  壬: "江河船長",
  癸: "甘露天使",
};

const zhi2Advisor: Record<string, string> = {
  子: "夜行刺客",
  丑: "忠犬守衛",
  寅: "森林獵人",
  卯: "春兔使者",
  辰: "龍族法師",
  巳: "火蛇術士",
  午: "烈馬騎兵",
  未: "溫羊牧者",
  申: "靈猴戰士",
  酉: "金雞衛士",
  戌: "戰犬統領",
  亥: "海豚智者",
};

export function generateArmyNarrative(pillars: PillarSet) {
  const Y = pillars.year,
    M = pillars.month,
    D = pillars.day,
    H = pillars.hour;

  const map = (gan: string, zhi: string) => ({
    mainGeneral: gan2General[gan] ?? `${gan}主將`,
    advisor: zhi2Advisor[zhi] ?? `${zhi}軍師`,
    deputy: "（待補：副將）",
    tactic: "（待補：奇謀）",
  });

  const legions = {
    year: map(Y.gan, Y.zhi),
    month: map(M.gan, M.zhi),
    day: map(D.gan, D.zhi),
    hour: map(H.gan, H.zhi),
  };

  const blocks = [
    `【家族兵團】主將：${legions.year.mainGeneral}；軍師：${legions.year.advisor}。`,
    `【成長兵團】主將：${legions.month.mainGeneral}；軍師：${legions.month.advisor}。`,
    `【本我兵團】主將：${legions.day.mainGeneral}；軍師：${legions.day.advisor}。`,
    `【未來兵團】主將：${legions.hour.mainGeneral}；軍師：${legions.hour.advisor}。`,
  ];

  return { legions, narrative: blocks.join("\n") };
}

export default generateArmyNarrative;
