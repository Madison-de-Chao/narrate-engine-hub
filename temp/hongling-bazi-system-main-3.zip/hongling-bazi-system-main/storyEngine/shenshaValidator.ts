/**
 * 神煞規則JSON驗證工具
 * 驗證神煞JSON檔案是否符合規格
 */

import type { ShenshaDefinition, ShenshaRule } from "./shenshaEngine";

const VALID_TIAN_GAN = [
  "甲",
  "乙",
  "丙",
  "丁",
  "戊",
  "己",
  "庚",
  "辛",
  "壬",
  "癸",
];
const VALID_DI_ZHI = [
  "子",
  "丑",
  "寅",
  "卯",
  "辰",
  "巳",
  "午",
  "未",
  "申",
  "酉",
  "戌",
  "亥",
];
const VALID_ANCHORS = [
  "dayStem",
  "yearBranch",
  "monthBranch",
  "dayBranch",
  "hourBranch",
  "anyBranch",
  "combo",
];
const VALID_TARGETS = ["year", "month", "day", "hour", "any"];

export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
}

export class ShenshaValidator {
  /**
   * 驗證神煞定義
   */
  validate(def: unknown): ValidationResult {
    const errors: ValidationError[] = [];

    // 檢查 def 是否為物件且不為 null
    if (typeof def !== "object" || def === null) {
      errors.push({ field: "root", message: "輸入必須為物件" });
      return { valid: false, errors };
    }
    // 基本欄位檢查
    // 斷言 def 為 Record<string, unknown>
    const obj = def as Record<string, unknown>;
    if (!obj.name || typeof obj.name !== "string") {
      errors.push({ field: "name", message: "必須提供name欄位（string）" });
    }

    if (typeof obj.enabled !== "boolean") {
      errors.push({
        field: "enabled",
        message: "必須提供enabled欄位（boolean）",
      });
    }

    if (typeof obj.priority !== "number") {
      errors.push({
        field: "priority",
        message: "必須提供priority欄位（number）",
      });
    }

    if (!Array.isArray(obj.rules)) {
      errors.push({ field: "rules", message: "必須提供rules欄位（array）" });
      return { valid: false, errors };
    }

    // 驗證每個規則
    for (let i = 0; i < obj.rules.length; i++) {
      const rule = obj.rules[i];
      const ruleErrors = this.validateRule(rule, i);
      errors.push(...ruleErrors);
    }

    // 檢查是否有未定義的額外欄位
    const allowedFields = ["name", "enabled", "priority", "rules"];
    const extraFields = Object.keys(obj).filter(
      (k) => !allowedFields.includes(k),
    );
    if (extraFields.length > 0) {
      errors.push({
        field: "root",
        message: `發現未定義的欄位: ${extraFields.join(", ")}`,
      });
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  }

  /**
   * 驗證單一規則
   */
  private validateRule(rule: ShenshaRule, index: number): ValidationError[] {
    const errors: ValidationError[] = [];
    const prefix = `rules[${index}]`;

    // 檢查anchor
    if (!rule.anchor || !VALID_ANCHORS.includes(rule.anchor)) {
      errors.push({
        field: `${prefix}.anchor`,
        message: `anchor必須是以下之一: ${VALID_ANCHORS.join(", ")}`,
      });
    }

    // 檢查rule_ref
    if (!rule.rule_ref || typeof rule.rule_ref !== "string") {
      errors.push({
        field: `${prefix}.rule_ref`,
        message: "rule_ref為必填欄位（string）",
      });
    }

    // 根據anchor類型驗證
    if (rule.anchor === "combo") {
      errors.push(...this.validateCombo(rule, prefix));
    } else {
      errors.push(...this.validateTable(rule, prefix));
    }

    return errors;
  }

  /**
   * 驗證table規則
   */
  private validateTable(rule: ShenshaRule, prefix: string): ValidationError[] {
    const errors: ValidationError[] = [];

    if (!rule.table || typeof rule.table !== "object") {
      errors.push({
        field: `${prefix}.table`,
        message: "table為必填欄位（object）",
      });
      return errors;
    }

    // 驗證table的key和value
    for (const [key, values] of Object.entries(rule.table)) {
      // 檢查key是否合法
      const isValidKey =
        rule.anchor === "dayStem"
          ? VALID_TIAN_GAN.includes(key)
          : VALID_DI_ZHI.includes(key);

      if (!isValidKey) {
        errors.push({
          field: `${prefix}.table.${key}`,
          message: `key "${key}" 不合法。${rule.anchor === "dayStem" ? "應為天干" : "應為地支"}`,
        });
      }

      // 檢查value是否為數組
      if (!Array.isArray(values)) {
        errors.push({
          field: `${prefix}.table.${key}`,
          message: `value必須為數組`,
        });
        continue;
      }

      // 檢查value中的每個元素（應該都是地支或天干）
      for (const val of values as string[]) {
        if (typeof val !== "string") {
          errors.push({
            field: `${prefix}.table.${key}`,
            message: `value中的元素必須為string`,
          });
        } else {
          // table的value通常是地支，但天德月德可能是天干
          const isValidValue =
            VALID_DI_ZHI.includes(val) || VALID_TIAN_GAN.includes(val);
          if (!isValidValue) {
            errors.push({
              field: `${prefix}.table.${key}`,
              message: `value "${val}" 不是有效的天干或地支`,
            });
          }
        }
      }
    }

    return errors;
  }

  /**
   * 驗證combo規則
   */
  private validateCombo(rule: ShenshaRule, prefix: string): ValidationError[] {
    const errors: ValidationError[] = [];

    if (!Array.isArray(rule.combo)) {
      errors.push({
        field: `${prefix}.combo`,
        message: "combo必須為array",
      });
      return errors;
    }

    for (let i = 0; i < rule.combo.length; i++) {
      const cond = rule.combo[i];
      const condPrefix = `${prefix}.combo[${i}]`;

      // 檢查anchor
      if (!cond.anchor || !VALID_ANCHORS.includes(cond.anchor)) {
        errors.push({
          field: `${condPrefix}.anchor`,
          message: `anchor必須是以下之一: ${VALID_ANCHORS.join(", ")}`,
        });
      }

      // 檢查in數組
      if (!Array.isArray(cond.in)) {
        errors.push({
          field: `${condPrefix}.in`,
          message: "in必須為array",
        });
      } else {
        for (const val of cond.in) {
          const isValid =
            VALID_TIAN_GAN.includes(val) || VALID_DI_ZHI.includes(val);
          if (!isValid) {
            errors.push({
              field: `${condPrefix}.in`,
              message: `"${val}" 不是有效的天干或地支`,
            });
          }
        }
      }

      // 檢查target
      if (!cond.target || !VALID_TARGETS.includes(cond.target)) {
        errors.push({
          field: `${condPrefix}.target`,
          message: `target必須是以下之一: ${VALID_TARGETS.join(", ")}`,
        });
      }

      // any是可選的布林值
      if (cond.any !== undefined && typeof cond.any !== "boolean") {
        errors.push({
          field: `${condPrefix}.any`,
          message: "any必須為boolean",
        });
      }
    }

    return errors;
  }

  /**
   * 驗證檔案內容
   */
  validateFile(filePath: string, content: string): ValidationResult {
    try {
      const def = JSON.parse(content);
      return this.validate(def);
    } catch (error) {
      return {
        valid: false,
        errors: [
          {
            field: "file",
            message: `JSON解析錯誤: ${error instanceof Error ? error.message : String(error)}`,
          },
        ],
      };
    }
  }
}

export default ShenshaValidator;
