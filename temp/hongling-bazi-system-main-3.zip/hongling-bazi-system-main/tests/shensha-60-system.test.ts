/**
 * 60 神煞系統測試
 * 驗證新增的神煞計算功能
 */

import { describe, it, expect } from 'vitest'
import { EnhancedBaziEngine } from '../storyEngine/enhancedBaziEngine'

describe('60 神煞系統測試', () => {
  const engine = new EnhancedBaziEngine()

  it('應該能計算天乙貴人', () => {
    const result = engine.calculateBazi({
      year: 1990,
      month: 1,
      day: 15,
      hour: 10
    })

    expect(result.shensha).toBeDefined()
    expect(Array.isArray(result.shensha)).toBe(true)
  })

  it('應該能計算多種神煞', () => {
    const result = engine.calculateBazi({
      year: 1985,
      month: 6,
      day: 20,
      hour: 14
    })

    // 檢查是否有神煞被計算出來
    expect(result.shensha.length).toBeGreaterThan(0)
    
    // 檢查神煞結構
    if (result.shensha.length > 0) {
      const shensha = result.shensha[0]
      expect(shensha).toHaveProperty('name')
      expect(shensha).toHaveProperty('type')
      expect(shensha).toHaveProperty('source_pillar')
      expect(shensha).toHaveProperty('calculation_method')
      expect(shensha).toHaveProperty('effect')
      expect(shensha).toHaveProperty('evidence')
    }
  })

  it('應該能識別刑沖關係', () => {
    // 子午沖的案例
    const result = engine.calculateBazi({
      year: 1984, // 甲子年
      month: 5,
      day: 15,
      hour: 12  // 午時
    })

    // 檢查是否有沖
    const chongShensha = result.shensha.filter(s => s.name.includes('沖'))
    // 注意：這個測試可能需要根據實際計算結果調整
    // 因為沖的產生需要特定的四柱組合
    expect(result.shensha).toBeDefined()
  })

  it('神煞應該包含完整的證據鏈', () => {
    const result = engine.calculateBazi({
      year: 1990,
      month: 3,
      day: 25,
      hour: 8
    })

    result.shensha.forEach(shensha => {
      expect(shensha.evidence).toBeDefined()
      expect(typeof shensha.evidence).toBe('object')
    })
  })

  it('應該能計算桃花系神煞', () => {
    const result = engine.calculateBazi({
      year: 1988, // 戊辰年
      month: 8,
      day: 8,
      hour: 10
    })

    // 檢查是否有計算桃花相關神煞
    expect(result.shensha).toBeDefined()
    // 桃花、紅鸞、天喜等都屬於桃花系
  })

  it('應該能計算吉神貴人', () => {
    const result = engine.calculateBazi({
      year: 1995,
      month: 5,
      day: 20,
      hour: 15
    })

    // 檢查是否有吉神
    const jiShen = result.shensha.filter(s => s.type === '吉神')
    expect(result.shensha).toBeDefined()
  })

  it('應該能計算凶煞', () => {
    const result = engine.calculateBazi({
      year: 1993,
      month: 7,
      day: 15,
      hour: 18
    })

    // 檢查是否有凶神
    const xiongShen = result.shensha.filter(s => s.type === '凶神')
    expect(result.shensha).toBeDefined()
  })
})

describe('神煞配置檔案測試', () => {
  it('shensha_calculation.json 應該包含所有神煞規則', () => {
    const shenshaCalc = require('../config/bazi/shensha_calculation.json')
    
    expect(shenshaCalc.shensha_calculation_rules).toBeDefined()
    
    // 檢查關鍵神煞是否存在
    const rules = shenshaCalc.shensha_calculation_rules
    expect(rules['天乙貴人']).toBeDefined()
    expect(rules['太極貴人']).toBeDefined()
    expect(rules['文昌貴人']).toBeDefined()
    expect(rules['將星']).toBeDefined()
    expect(rules['華蓋']).toBeDefined()
    expect(rules['桃花']).toBeDefined()
    expect(rules['羊刃']).toBeDefined()
    expect(rules['劫煞']).toBeDefined()
    expect(rules['災煞']).toBeDefined()
    expect(rules['孤辰']).toBeDefined()
    expect(rules['寡宿']).toBeDefined()
    expect(rules['空亡']).toBeDefined()
    expect(rules['紅鸞']).toBeDefined()
    expect(rules['天喜']).toBeDefined()
  })

  it('shensha_complete.json 應該包含所有神煞效果', () => {
    const shenshaComplete = require('../config/story/shensha_complete.json')
    
    expect(shenshaComplete.shensha_effects).toBeDefined()
    
    // 檢查神煞效果數量
    const effectsCount = Object.keys(shenshaComplete.shensha_effects).length
    expect(effectsCount).toBeGreaterThanOrEqual(60)
    
    // 檢查關鍵神煞效果
    const effects = shenshaComplete.shensha_effects
    expect(effects['天乙貴人']).toBeDefined()
    expect(effects['天乙貴人'].buff).toBeDefined()
    expect(effects['天乙貴人'].pillar_meaning).toBeDefined()
    
    // 檢查組合效果
    expect(shenshaComplete.shensha_combinations).toBeDefined()
    expect(shenshaComplete.shensha_combinations['天乙貴人+文昌貴人']).toBeDefined()
  })

  it('神煞分類統計應該正確', () => {
    const shenshaComplete = require('../config/story/shensha_complete.json')
    
    expect(shenshaComplete.shensha_category_summary).toBeDefined()
    
    const summary = shenshaComplete.shensha_category_summary
    expect(summary['貴人系']).toBeDefined()
    expect(summary['財祿系']).toBeDefined()
    expect(summary['德星系']).toBeDefined()
    expect(summary['權貴系']).toBeDefined()
    expect(summary['桃花系']).toBeDefined()
    expect(summary['孤高系']).toBeDefined()
    expect(summary['凶煞系']).toBeDefined()
    expect(summary['孤寡系']).toBeDefined()
    expect(summary['陰陽系']).toBeDefined()
    expect(summary['刑沖害破系']).toBeDefined()
  })
})
