import express, { Request, Response } from "express";

const router = express.Router();

// OAuth login endpoint - minimal stub for Railway integration
router.get("/login", (req: Request, res: Response): void => {
  const clientId = process.env.OAUTH_CLIENT_ID;
  const redirectUri = process.env.OAUTH_REDIRECT_URI;

  if (!clientId || !redirectUri) {
    res.status(500).json({
      error: "OAuth not configured",
      message:
        "OAUTH_CLIENT_ID and OAUTH_REDIRECT_URI environment variables required",
    });
    return;
  }

  // For Railway integration, return OAuth URL structure
  const githubAuthUrl = `https://github.com/login/oauth/authorize?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&scope=repo`;

  res.json({
    auth_url: githubAuthUrl,
    client_id: clientId,
    redirect_uri: redirectUri,
    message: "OAuth login endpoint for Railway integration",
  });
});

// OAuth callback endpoint - minimal stub for Railway integration
router.get("/callback", (req: Request, res: Response): void => {
  const { code, state } = req.query;

  if (!code) {
    res.status(400).json({
      error: "Missing authorization code",
      message: "OAuth callback requires code parameter",
    });
    return;
  }

  // Minimal callback response for Railway
  res.json({
    status: "callback_received",
    code: code,
    state: state,
    message: "OAuth callback processed for Railway integration",
    timestamp: new Date().toISOString(),
  });
});

// OAuth logout endpoint - minimal stub for Railway integration
router.post("/logout", (req: Request, res: Response): void => {
  res.json({
    status: "logged_out",
    message: "OAuth logout endpoint for Railway integration",
    timestamp: new Date().toISOString(),
  });
});

// OAuth user endpoint - minimal stub for Railway integration
router.get("/user", (req: Request, res: Response): void => {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    res.status(401).json({
      error: "No authorization header",
      message: "Bearer token required for user endpoint",
    });
    return;
  }

  // Minimal user response for Railway
  res.json({
    status: "authenticated",
    user: {
      id: "railway_user",
      login: "railway_integration",
      type: "User",
    },
    message: "OAuth user endpoint for Railway integration",
    timestamp: new Date().toISOString(),
  });
});

export default router;
