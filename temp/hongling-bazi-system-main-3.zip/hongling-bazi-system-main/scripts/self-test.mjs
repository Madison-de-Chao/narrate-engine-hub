#!/usr/bin/env node
/* eslint-disable */
// Simple self-test to verify core endpoints.
// Usage: node scripts/self-test.mjs [baseUrl]
// Default baseUrl: http://localhost:3000

import http from 'node:http'

const base = process.argv[2] || 'http://localhost:3000'

const get = (path) => new Promise((resolve, reject) => {
  const url = base + path
  http.get(url, (res) => {
    let data = ''
    res.on('data', c => { data += c })
    res.on('end', () => {
      resolve({ status: res.statusCode, body: data })
    })
  }).on('error', reject)
})

const required = [ '/', '/status', '/health', '/health?storage=full', '/health?test=full', '/health?storage=full&test=full' ]

;(async () => {
  let ok = true
  for (const p of required) {
    try {
      const r = await get(p)
      const label = `${p.padEnd(32)}`
      if (r.status === 200) {
        console.log('✅', label, 'OK')
      } else {
        console.log('❌', label, 'STATUS', r.status)
        ok = false
      }
    } catch (e) {
      console.log('❌', p, 'ERROR', e.message)
      ok = false
    }
  }
  if (!ok) {
    console.error('Self-test failed')
    process.exit(1)
  } else {
    console.log('All endpoint checks passed')
  }
})()
