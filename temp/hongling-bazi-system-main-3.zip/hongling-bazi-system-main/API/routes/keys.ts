import express from "express";

const router = express.Router();

interface ApiKeyRequest {
  service?: string;
  provider?: string;
}

interface ApiKeyResponse {
  keyId: string;
  service: string;
  provider: string;
  status: string;
  createdAt: string;
  expiresAt?: string;
}

// POST /api/keys - Validate and register an API key
router.post("/", (req, res) => {
  try {
    const { service = "story-generation", provider = "openai" } =
      req.body as ApiKeyRequest;
    const apiKey = req.headers["x-api-key"] as string;

    if (!apiKey) {
      res.status(400).json({
        success: false,
        error: "API key required in X-API-Key header",
      });
      return;
    }

    // For now, we'll do basic validation - in real implementation this would validate against the actual service
    if (!apiKey.startsWith("sk-") && !apiKey.startsWith("test-")) {
      res.status(401).json({
        success: false,
        error: "Invalid API key format",
      });
      return;
    }

    // Generate a temporary key ID for this session
    const keyId = `key_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;

    // Store the key validation result (in real implementation, this would be in a secure store)
    const keyData: ApiKeyResponse = {
      keyId,
      service,
      provider,
      status: "valid",
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hours
    };

    res.json({
      success: true,
      data: keyData,
      message: `API key validated for ${service} service using ${provider} provider`,
    });
    return;
  } catch (error: unknown) {
    console.error("API key validation error:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error during API key validation",
    });
    return;
  }
});

// GET /api/keys/:keyId - Check API key status
router.get("/:keyId", (req, res) => {
  try {
    const { keyId } = req.params;

    if (!keyId.startsWith("key_")) {
      res.status(404).json({
        success: false,
        error: "API key not found",
      });
      return;
    }

    // Mock response - in real implementation this would fetch from secure storage
    res.json({
      success: true,
      data: {
        keyId,
        service: "story-generation",
        provider: "openai",
        status: "valid",
        createdAt: new Date(Date.now() - 60000).toISOString(), // 1 minute ago
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      },
    });
    return;
  } catch (error: unknown) {
    console.error("API key status check error:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error during key status check",
    });
    return;
  }
});

// DELETE /api/keys/:keyId - Invalidate an API key
router.delete("/:keyId", (req, res) => {
  try {
    const { keyId } = req.params;

    // In real implementation, this would invalidate the key in secure storage
    res.json({
      success: true,
      message: `API key ${keyId} has been invalidated`,
    });
    return;
  } catch (error: unknown) {
    console.error("API key invalidation error:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error during key invalidation",
    });
    return;
  }
});

export default router;
