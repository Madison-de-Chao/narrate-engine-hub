interface IReportRepo {
  saveReport(_pillars: unknown, _tone: string, _narrative: unknown): Promise<void>
}

let repoInstance: IReportRepo | null = null
let isInitialized = false

export async function getRepository(): Promise<IReportRepo | null> {
  if (isInitialized) {
    return repoInstance
  }

  try {
    if (process.env.DATABASE_URL || (process.env.PGHOST && process.env.PGUSER)) {
      const { PostgresRepo } = await import('../repository/PostgresRepo')
      repoInstance = new PostgresRepo() as IReportRepo
      console.log('[report] PostgreSQL 已啟用')
    } else {
      console.log('[report] 未偵測到 PostgreSQL 環境變數，報告儲存功能停用 (僅回傳 HTML)')
      repoInstance = null
    }
  } catch (e) {
    console.warn('[report] PostgreSQL 初始化失敗，將以降級模式運作：', (e as Error).message)
    repoInstance = null
  }

  isInitialized = true
  return repoInstance
}

export type { IReportRepo }