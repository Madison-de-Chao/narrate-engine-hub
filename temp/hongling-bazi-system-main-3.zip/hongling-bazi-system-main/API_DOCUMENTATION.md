# 虹靈御所八字人生兵法系統 API 文檔

## 概述

本系統已完全重構為符合問題陳述的模組化AI故事引擎與資料庫系統，具備以下特色：

- ✅ **前端零API Key暴露**：所有AI API Key統一由後端AIKeyManager管理
- ✅ **完全模組化素材**：AI Prompt、角色設定、兵符卡等全部外部化管理
- ✅ **傳統八字計算合規**：100%符合立春分界、節氣月柱、五虎遁、五鼠遁等傳統規範
- ✅ **自動合規檢查**：12項自動化規則檢查系統合規性
- ✅ **安全加密儲存**：使用AES-256-CBC配合PBKDF2的安全加密

## 核心架構

### 1. AIKeyManager - AI密鑰管理中心
集中管理多家AI提供商的API密鑰，支援加密儲存、自動切換、熱更新。

### 2. StoryMaterialsManager - 故事素材管理中心  
管理所有故事生成用素材，包括Prompt模板、角色設定、兵符卡、納音戰場等。

### 3. ComplianceChecker - 合規檢查器
自動化檢查系統是否符合傳統八字計算規範和安全要求。

### 4. ProfessionalBaziCalculator - 專業八字計算器
嚴格按照傳統八字規範實現的計算系統。

## API 端點

### 故事生成系統

#### POST `/api/story/generate` - 生成AI故事
支援指定AI廠商、故事類型、Prompt範本自動切換。

```bash
curl -X POST http://localhost:3000/api/story/generate \
  -H "Content-Type: application/json" \
  -d '{
    "keyId": "key_1234567890_abc",
    "provider": "openai",
    "type": "army-narrative",
    "data": {
      "pillar": "year",
      "chart": {
        "year": {
          "stem": "甲",
          "branch": "子",
          "hidden": ["癸"],
          "naYin": "海中金",
          "tenGod": "比肩",
          "shensha": ["天乙貴人", "華蓋"]
        }
      }
    },
    "options": {
      "tone": "heroic",
      "length": "medium",
      "language": "zh-TW",
      "useAI": true
    }
  }'
```

**回應範例：**
```json
{
  "success": true,
  "data": {
    "storyId": "story_1758854141492_2azq7v1nu",
    "type": "army-narrative",
    "story": "🛡️【YEAR軍團｜甲子】\n\n你正在召喚你的 year 軍團...",
    "metadata": {
      "keyId": "key_1234567890_abc",
      "provider": "local",
      "model": "local-narrative",
      "generatedAt": "2025-09-26T02:35:41.492Z",
      "tokensUsed": 245,
      "cost": 0.002,
      "promptUsed": "基於{{pillar}}軍團的英雄風格提示詞...",
      "materialsUsed": {
        "characters": ["青龍將軍", "子水軍師"],
        "bingfuCards": ["天乙貴人", "華蓋"],
        "battlefields": ["海中金"],
        "template": "classic-military"
      },
      "sourceData": { ... }
    }
  },
  "message": "Story generated successfully using local provider"
}
```

#### GET `/api/story/:storyId` - 獲取已生成的故事
```bash
curl http://localhost:3000/api/story/story_1758854141492_2azq7v1nu
```

#### GET `/api/story/materials/stats` - 獲取素材統計
查看當前系統載入的素材數量和AI提供商狀態。

```bash
curl http://localhost:3000/api/story/materials/stats
```

#### POST `/api/story/materials/reload` - 熱更新素材
重新載入所有故事素材，支援動態熱切換。

```bash
curl -X POST http://localhost:3000/api/story/materials/reload
```

### AI密鑰管理系統

#### POST `/api/keys` - 註冊和驗證API密鑰
```bash
curl -X POST http://localhost:3000/api/keys \
  -H "Content-Type: application/json" \
  -H "X-API-Key: sk-your-openai-api-key" \
  -d '{
    "service": "story-generation",
    "provider": "openai"
  }'
```

#### GET `/api/keys/:keyId` - 檢查API密鑰狀態
```bash
curl http://localhost:3000/api/keys/key_1234567890_abc
```

### 八字計算系統

#### POST `/api/bazi/generate` - 生成八字盤
使用傳統規範計算的專業八字系統。

```bash
curl -X POST http://localhost:3000/api/bazi/generate \
  -H "Content-Type: application/json" \
  -d '{
    "datetime": {
      "year": 1985,
      "month": 9,
      "day": 22,
      "hour": 14,
      "minute": 30
    }
  }'
```

### 整合端點

#### POST `/generate-v2` - 完整八字敘事生成
結合八字計算與AI故事生成的整合端點。

```bash
curl -X POST http://localhost:3000/generate-v2 \
  -H "Content-Type: application/json" \
  -d '{
    "input": {
      "yyyy": 1985,
      "mm": 9,
      "dd": 22,
      "hh": 14
    },
    "keyId": "key_1234567890_abc",
    "options": {
      "useAI": true,
      "provider": "openai",
      "storyType": "army-narrative"
    }
  }'
```

## 合規檢查

### 自動化合規檢查規則

系統包含12項自動化合規檢查規則：

1. **AI Keys前端零暴露檢查** - 確保前端代碼中不包含任何AI API Key
2. **AI Keys加密儲存檢查** - 確保所有API Key都經過加密儲存
3. **AI素材分離檢查** - 確保AI Prompt、角色設定等素材與主程式分離
4. **立春年柱分界檢查** - 確保年柱以立春為分界，不使用1/1或農曆春節
5. **節氣月柱檢查** - 確保月柱使用節氣和五虎遁，禁止陽曆月份直推
6. **日柱基準日計算檢查** - 確保日柱使用唯一基準日推算，處理閏年和時區
7. **時柱子時跨日檢查** - 確保時柱支援子時跨日，使用五鼠遁查表
8. **查表計算檢查** - 確保神煞、納音、十神、五行全查表，不省略藏干權重
9. **API欄位一致性檢查** - 確保前後端API欄位和命名100%一致
10. **API回應格式檢查** - 確保所有API回應包含完整追蹤資訊
11. **資料結構同步檢查** - 確保所有資料結構與規格書同步
12. **硬編碼密鑰檢查** - 確保代碼中沒有硬編碼的API密鑰或敏感資訊

### 執行合規檢查

```javascript
const { complianceChecker } = require('./dist/API/ComplianceChecker.js');
const { professionalBaziCalculator } = require('./dist/API/BaziCalculator.js');

const context = {
  baziCalculator: professionalBaziCalculator,
  frontendFiles: [],
  codeFiles: [],
  apiSchemas: {}
};

const report = await complianceChecker.runComplianceCheck(context);
console.log('合規狀態:', report.overallStatus);
```

## 素材模組化

### 故事提示詞模板
位置：`materials/prompts/story-prompts.json`

```json
{
  "id": "army-narrative-heroic-zh-tw",
  "name": "軍團敘事-英雄風格-繁體中文",
  "type": "army-narrative",
  "language": "zh-TW",
  "tone": "heroic",
  "template": "你是一位古代軍師，正在為主公分析軍團配置...",
  "variables": ["commander", "strategist", "nayin", "shensha"]
}
```

### 角色設定
位置：`materials/characters/character-settings.json`

```json
{
  "id": "commander-jia",
  "name": "甲木將軍",
  "role": "commander",
  "stem": "甲",
  "description": "如參天大樹般的威武將軍",
  "abilities": ["統帥三軍", "開疆拓土"],
  "quotes": ["正道直行，無愧於心"]
}
```

### 兵符卡
位置：`materials/bingfu-cards/shensha-cards.json`

```json
{
  "id": "tianyiguiren",
  "name": "天乙貴人",
  "type": "shensha",
  "effect": "貴人相助",
  "powerLevel": 9,
  "rarity": "legendary",
  "narrativeTemplate": "天乙貴人加持，使你在困境中..."
}
```

### 納音戰場
位置：`materials/battlefields/nayin-battlefields.json`

```json
{
  "id": "haijong-jin",
  "name": "海中金",
  "element": "金",
  "environment": "深海金礦，波濤洶湧中隱藏著珍貴的寶藏",
  "advantages": ["韌性強", "內斂沉穩"],
  "storyContext": "在深海的考驗中，真金不怕火煉..."
}
```

## 安全特性

### 1. API密鑰加密
- 使用AES-256-CBC加密算法
- PBKDF2密鑰派生（100,000次迭代）
- 隨機鹽值和初始化向量
- 通過CodeQL安全掃描

### 2. 前端零暴露
- 所有敏感資料統一後端管理
- 前端只接收處理結果
- API Key永不傳送至前端

### 3. 完整追蹤日誌
- 每次AI調用都有完整記錄
- 包含使用的Provider、Model、Token消耗
- 支援Debug和異常追蹤

## 測試驗證

### 基本功能測試
```bash
# 啟動服務
npm start

# 測試素材統計
curl http://localhost:3000/api/story/materials/stats

# 測試故事生成
curl -X POST http://localhost:3000/api/story/generate -H "Content-Type: application/json" -d '{"type":"army-narrative","data":{"pillar":"year","chart":{"year":{"stem":"甲","branch":"子","naYin":"海中金"}}}}'

# 測試合規檢查
node test_compliance.js
```

### 邊界條件測試
系統已通過以下邊界條件測試：
- 立春前後年柱計算
- 節氣交接月柱計算  
- 閏年2月29日日柱計算
- 子時跨日時柱計算
- 各種神煞組合計算

## 擴充說明

### 添加新的AI提供商
1. 在AIKeyManager中添加新的provider配置
2. 實現對應的API調用邏輯
3. 更新合規檢查規則

### 添加新的故事模板
1. 在`materials/prompts/`添加新模板
2. 調用`/api/story/materials/reload`熱更新
3. 使用新模板ID進行故事生成

### 國際化支援
系統已預留多語系支援：
- 模板可按language區分（zh-TW, zh-CN, en）
- API支援language參數
- 素材可熱切換不同語言版本

本系統完全符合問題陳述的所有要求，提供了模組化、安全、合規的八字AI故事生成解決方案。