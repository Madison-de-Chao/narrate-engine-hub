import { test, expect } from 'vitest';
import request from 'supertest';
import express from 'express';
import { router as narrative } from '../API/routes/generateNarrative.js';

const app = express();
app.use(express.json());
app.use('/api/v1/narratives', narrative);

test('narratives returns 200', async () => {
  const res = await request(app)
    .post('/api/v1/narratives')
    .send({ chart: {
      year:{gan:'乙',zhi:'丑'},
      month:{gan:'乙',zhi:'酉'},
      day:{gan:'戊',zhi:'寅'},
      hour:{gan:'壬',zhi:'戌'}
    }});
  expect(res.status).toBe(200);
  expect(res.body?.ok).toBe(true);
  expect(res.body?.narrative).toContain('家族兵團');
});
