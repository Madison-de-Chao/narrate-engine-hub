# 虹靈御所八字系統 - 故事版實現指南

## 概述

本文件說明如何在現有精準計算引擎基礎上，實現《虹靈御所八字人生兵法 系統建構手冊》中提到的 **故事版 (Narrative RPG Version)** 功能。

## 系統分層架構

```
┌─────────────────────────────────────────┐
│   前端層 (React + Tailwind + Framer)   │
│   - 資料輸入                             │
│   - 排盤展示                             │
│   - 四時軍團卡                           │
│   - 詳細分析圖表                         │
└─────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│   API 層 (Express REST API)             │
│   - /generate (基礎生成)                 │
│   - /generate-v2 (兩步驟 AI 生成)       │
│   - /api/ai/story (AI 故事生成)         │
└─────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│   故事化模組 (Narrative RPG Engine)      │
│   - generateArmyNarrative (軍團敘事)     │
│   - 四時軍團系統                         │
│   - 十神技能樹                           │
│   - 神煞兵符卡                           │
└─────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│   計算引擎 (Calculation Engine)          │
│   - calculateYearPillar (年柱)          │
│   - calculateMonthPillar (月柱)         │
│   - calculateDayPillar (日柱)           │
│   - calculateHourPillar (時柱)          │
│   - calculateTenGods (十神)             │
│   - calculateShensha (神煞)             │
│   - calcFiveElementPower (五行力量)      │
└─────────────────────────────────────────┘
```

## 已實現功能 ✅

### 1. 八字計算引擎 (完成度: 95%)

**已實現**:
- ✅ 年柱計算 (立春為界)
- ✅ 月柱計算 (節氣為界 + 五虎遁)
- ✅ 日柱計算 (EPOCH 基準)
- ✅ 時柱計算 (五鼠遁時)
- ✅ 十神判斷 (完整邏輯)
- ✅ 神煞查表 (天乙貴人、桃花、驛馬)
- ✅ 納音查表 (60 甲子完整)
- ✅ 五行力量統計 (天干 1.0、地支 0.8、藏干 0.6/0.4/0.3)
- ✅ 陰陽統計

**待優化** (可選):
- ⚠️ 立春精確時刻 (當前為日期近似)
- ⚠️ 節氣精確時刻 (當前為日期近似)
- ⚠️ 子時跨日邏輯 (23:00-01:00)
- ⚠️ 月令五行加權 (×1.5)

### 2. 故事化模組 (完成度: 60%)

**已實現**:
- ✅ 四時軍團基礎敘事 (`generateArmyNarrative`)
- ✅ 角色化命名 (天干 → 森林將軍、烈日戰神等)
- ✅ 納音戰場描述
- ✅ 神煞兵符效果
- ✅ 十神技能解讀

**待擴展**:
- 🔲 四時軍團卡片資料結構
- 🔲 十神技能樹詳細定義
- 🔲 神煞兵符完整卡池
- 🔲 AI 劇情生成整合

### 3. API 層 (完成度: 80%)

**已實現**:
- ✅ `/generate` - 基礎命盤生成
- ✅ `/generate-v2` - 兩步驟生成 (支持 AI)
- ✅ `/api/keys` - API 金鑰管理
- ✅ `/api/ai/story` - AI 故事生成端點

**待優化**:
- 🔲 前端 React 應用
- 🔲 圖表視覺化 (Chart.js)
- 🔲 動畫效果 (Framer Motion)

### 4. 資料庫層 (完成度: 70%)

**已實現** (見 `API/repository.ts`):
- ✅ `user_profile` - 用戶基本資料
- ✅ `bazi_chart` - 八字命盤
- ✅ `bazi_nayin_card` - 納音卡
- ✅ `bazi_shensha_card` - 神煞卡
- ✅ `bazi_ai_story` - AI 故事
- ✅ `bazi_army_card` - 軍團卡
- ✅ `bazi_skill_card` - 技能卡

**資料表設計** (已在 `API/repository.ts` 實現):

```sql
-- 用戶資料
CREATE TABLE user_profile (
  user_id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  birthday TEXT,
  sex TEXT,
  location TEXT,
  timezone TEXT,
  create_at TEXT DEFAULT (datetime('now'))
);

-- 八字命盤
CREATE TABLE bazi_chart (
  chart_id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  year_gan TEXT, year_zhi TEXT,
  month_gan TEXT, month_zhi TEXT,
  day_gan TEXT, day_zhi TEXT,
  hour_gan TEXT, hour_zhi TEXT,
  year_nayin TEXT, month_nayin TEXT,
  day_nayin TEXT, hour_nayin TEXT,
  year_hidden_gan TEXT,
  month_hidden_gan TEXT,
  day_hidden_gan TEXT,
  hour_hidden_gan TEXT,
  chart_json TEXT,
  create_at TEXT DEFAULT (datetime('now'))
);

-- 納音戰場卡
CREATE TABLE bazi_nayin_card (
  nayin_id INTEGER PRIMARY KEY AUTOINCREMENT,
  chart_id INTEGER,
  pillar TEXT,
  nayin_name TEXT,
  element TEXT,
  scene TEXT,
  buff TEXT,
  debuff TEXT,
  color TEXT,
  create_at TEXT DEFAULT (datetime('now'))
);

-- 神煞兵符卡
CREATE TABLE bazi_shensha_card (
  shensha_id INTEGER PRIMARY KEY AUTOINCREMENT,
  chart_id INTEGER,
  pillar TEXT,
  shensha_name TEXT,
  type TEXT,
  trigger TEXT,
  buff TEXT,
  debuff TEXT,
  color TEXT,
  card_json TEXT,
  create_at TEXT DEFAULT (datetime('now'))
);

-- AI 故事
CREATE TABLE bazi_ai_story (
  story_id INTEGER PRIMARY KEY AUTOINCREMENT,
  chart_id INTEGER,
  army_type TEXT,
  story_type TEXT,
  story_text TEXT,
  summary TEXT,
  create_at TEXT DEFAULT (datetime('now'))
);

-- 軍團卡
CREATE TABLE bazi_army_card (
  card_id INTEGER PRIMARY KEY AUTOINCREMENT,
  chart_id INTEGER,
  army_type TEXT,
  role_type TEXT,
  gan_or_zhi TEXT,
  canggan TEXT,
  ten_god TEXT,
  buff TEXT,
  debuff TEXT,
  skills TEXT,
  card_json TEXT,
  create_at TEXT DEFAULT (datetime('now'))
);
```

## 四時軍團系統設計

### 軍團架構

```
年柱軍團 (Year Army) - 家族舞台
├── 主將 (Commander): 年干 - 社會角色
├── 軍師 (Strategist): 年支 - 環境資源
├── 副將 (Lieutenant): 藏干 - 潛在力量
└── 戰場 (Battlefield): 納音 - 能量場域

月柱軍團 (Month Army) - 成長關係
├── 主將: 月干 - 人際互動
├── 軍師: 月支 - 機遇窗口
├── 副將: 藏干 - 隱藏支援
└── 戰場: 納音 - 關係氛圍

日柱軍團 (Day Army) - 本我核心 ⭐
├── 主將: 日干 - 自我本質 (十神基準)
├── 軍師: 日支 - 配偶宮/內在
├── 副將: 藏干 - 深層驅動
└── 戰場: 納音 - 命格基調

時柱軍團 (Hour Army) - 未來願景
├── 主將: 時干 - 事業發展
├── 軍師: 時支 - 子女/創造
├── 副將: 藏干 - 潛力資源
└── 戰場: 納音 - 晚年環境
```

### 十神技能樹

**已在 `utils.ts` 中定義**:

```typescript
export function getTenGodNarrative(tenGod: string): string {
  const t: Record<string,string> = {
    "比肩":"自我推進、競爭力強",
    "劫財":"資源分享、合作亦競合",
    "食神":"創造表達、福氣延展",
    "傷官":"突破框架、表現慾強",
    "偏印":"靈感學習、支援多",
    "正印":"庇蔭資源、學習成長",
    "偏財":"機會財、外部資源",
    "正財":"穩健財、務實經營",
    "七殺":"行動果決、承壓挑戰",
    "正官":"紀律責任、制度資源"
  }
  return t[tenGod] || tenGod
}
```

**技能樹擴展建議**:

```typescript
interface TenGodSkill {
  name: string              // 十神名稱
  category: string          // 類別 (自我/表達/資源/管理)
  mainSkill: string         // 主技能
  subSkills: string[]       // 子技能
  buff: string[]            // 正面效果
  debuff: string[]          // 負面效果
  evolution: string         // 進化路徑
  trigger: string           // 觸發條件
}

const TEN_GOD_SKILLS: Record<string, TenGodSkill> = {
  "比肩": {
    name: "比肩",
    category: "自我",
    mainSkill: "獨立行動",
    subSkills: ["競爭意識", "自主決策", "並肩作戰"],
    buff: ["獨立自主", "堅持目標", "不畏競爭"],
    debuff: ["固執己見", "不易妥協", "缺乏合作"],
    evolution: "多見比肩 → 團隊領袖",
    trigger: "自我認同"
  },
  // ... 其他十神
}
```

### 神煞兵符卡

**已在 `utils.ts` 中部分實現**:

```typescript
export function getShenshaEffect(s: string): string {
  const effect: Record<string,string> = {
    "天乙貴人":"逢兇化吉、得貴相助",
    "桃花":"人緣魅力、社交順利",
    "驛馬":"奔波變動、機動力強"
  }
  return effect[s] || s
}
```

**完整兵符卡建議**:

```typescript
interface ShenshaCard {
  name: string              // 神煞名稱
  type: string              // 類型 (吉神/凶煞/中性)
  rarity: string            // 稀有度 (SSR/SR/R/N)
  pillarEffect: {           // 四柱差異效果
    year: string
    month: string
    day: string
    hour: string
  }
  buff: string[]            // Buff 效果
  debuff: string[]          // Debuff 效果
  trigger: string           // 觸發條件
  story: string             // 背景故事
  color: string             // 卡片顏色
}

const SHENSHA_CARDS: Record<string, ShenshaCard> = {
  "天乙貴人": {
    name: "天乙貴人",
    type: "吉神",
    rarity: "SSR",
    pillarEffect: {
      year: "社會地位提升，長輩相助",
      month: "人際關係順利，貴人引薦",
      day: "個人魅力增強，危機化解",
      hour: "晚年福澤，子女貴顯"
    },
    buff: ["逢凶化吉", "貴人相助", "化險為夷"],
    debuff: ["過度依賴", "缺乏主動"],
    trigger: "遭遇困難時自動觸發",
    story: "天乙貴人為天界第一吉星...",
    color: "#FFD700"
  },
  // ... 更多神煞
}
```

### 納音戰場

**已在 `NAYIN` 常量中定義**:

```typescript
export const NAYIN: Record<string,string> = {
  "甲子":"海中金",
  "乙丑":"海中金",
  // ... 60 甲子
}
```

**戰場詳細設定建議**:

```typescript
interface NayinBattlefield {
  name: string              // 納音名稱
  element: string           // 五行屬性
  scene: string             // 場景描述
  environment: string       // 環境特徵
  buff: string[]            // 環境 Buff
  debuff: string[]          // 環境 Debuff
  lesson: string            // 人生課題
  symbolism: string         // 象徵意義
  color: string             // 場景色調
}

const NAYIN_BATTLEFIELDS: Record<string, NayinBattlefield> = {
  "海中金": {
    name: "海中金",
    element: "金",
    scene: "深海寶藏，珍珠暗藏",
    environment: "需要耐心打磨，價值需要發掘",
    buff: ["耐心成就", "內涵豐富", "厚積薄發"],
    debuff: ["不易顯露", "需要時間", "缺乏即時性"],
    lesson: "真正的價值需要時間沉澱",
    symbolism: "象徵內在的珍貴品質",
    color: "#4682B4"
  },
  // ... 其他納音
}
```

## API 端點使用範例

### 基礎命盤生成

```bash
curl -X POST http://localhost:3000/generate \
  -H "Content-Type: application/json" \
  -d '{
    "input": {
      "yyyy": 1985,
      "mm": 10,
      "dd": 6,
      "hh": 19
    }
  }'
```

**回應**:
```json
{
  "chart": {
    "pillars": {
      "year": {"gan": "乙", "zhi": "丑", "pillar": "乙丑"},
      "month": {"gan": "乙", "zhi": "酉", "pillar": "乙酉"},
      "day": {"gan": "戊", "zhi": "寅", "pillar": "戊寅"},
      "hour": {"gan": "壬", "zhi": "戌", "pillar": "壬戌"}
    },
    "tenGods": ["乙:比肩", "乙:比肩", "壬:七殺"],
    "shensha": ["驛馬"],
    "fiveElements": {"木": 3.4, "火": 0.6, "土": 4.1, "金": 2.4, "水": 1.3},
    "yinYang": {"陰": 4, "陽": 4}
  },
  "narrative": {
    "year": {
      "commander": "乙",
      "strategist": "丑",
      "naYin": "海中金",
      "story": "🛡️【YEAR軍團｜乙丑】..."
    },
    "month": {...},
    "day": {...},
    "hour": {...}
  }
}
```

### 兩步驟 AI 生成

**Step 1: 註冊 API Key**
```bash
curl -X POST http://localhost:3000/api/keys \
  -H "Content-Type: application/json" \
  -d '{
    "apiKey": "sk-...",
    "service": "story-generation",
    "provider": "openai"
  }'
```

**Step 2: 生成故事**
```bash
curl -X POST http://localhost:3000/api/ai/story \
  -H "Content-Type: application/json" \
  -d '{
    "keyId": "key_abc123",
    "type": "army-narrative",
    "data": {
      "pillar": "year",
      "chart": {
        "year": {
          "stem": "乙",
          "branch": "丑",
          "naYin": "海中金",
          "tenGod": "比肩",
          "shensha": ["驛馬"]
        }
      }
    }
  }'
```

## 前端實現建議

### 技術棧

```
React 18+ (UI 框架)
├── TypeScript (型別安全)
├── Tailwind CSS (樣式)
├── Framer Motion (動畫)
├── Chart.js (圖表)
└── React Router (路由)
```

### 頁面結構

```
/                     首頁 - 輸入出生資訊
├── /chart            命盤展示
│   ├── /pillars      傳統排盤
│   ├── /army         四時軍團卡
│   ├── /analysis     詳細分析
│   └── /story        AI 故事
└── /encyclopedia     八字百科
    ├── /ten-gods     十神解釋
    ├── /shensha      神煞大全
    └── /nayin        納音介紹
```

### 四時軍團卡組件範例

```tsx
interface ArmyCardProps {
  pillar: 'year' | 'month' | 'day' | 'hour'
  data: {
    commander: string
    strategist: string
    naYin: string
    tenGod: string
    shensha: string[]
    story: string
  }
}

function ArmyCard({ pillar, data }: ArmyCardProps) {
  const pillarNames = {
    year: '年柱軍團 - 家族舞台',
    month: '月柱軍團 - 成長關係',
    day: '日柱軍團 - 本我核心',
    hour: '時柱軍團 - 未來願景'
  }

  return (
    <motion.div
      className="card bg-gradient-to-br from-amber-500 to-orange-600 p-6 rounded-xl shadow-2xl"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h2 className="text-2xl font-bold text-white mb-4">
        {pillarNames[pillar]}
      </h2>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-white/20 p-3 rounded">
          <p className="text-sm text-white/80">主將</p>
          <p className="text-xl font-bold text-white">{data.commander}</p>
        </div>
        <div className="bg-white/20 p-3 rounded">
          <p className="text-sm text-white/80">軍師</p>
          <p className="text-xl font-bold text-white">{data.strategist}</p>
        </div>
      </div>

      <div className="mb-4">
        <p className="text-sm text-white/80">戰場: {data.naYin}</p>
        <p className="text-sm text-white/80">技能: {data.tenGod}</p>
        <p className="text-sm text-white/80">兵符: {data.shensha.join('、')}</p>
      </div>

      <motion.div
        className="bg-white/10 p-4 rounded"
        initial={{ height: 0 }}
        animate={{ height: 'auto' }}
      >
        <p className="text-white text-sm leading-relaxed">{data.story}</p>
      </motion.div>
    </motion.div>
  )
}
```

## 測試與驗證

### 運行驗證腳本

```bash
# 完整驗證
npx ts-node tests/validate-bazi.ts

# 查看驗證報告
cat CALCULATION_ENGINE_VALIDATION.md
```

### 測試邊界案例

見 `tests/bazi-calculation.test.ts` 中的測試套件。

## 部署建議

### 開發環境

```bash
npm run dev
```

### 生產環境

```bash
# 建置
npm run build

# 啟動
npm start
```

### 環境變數

```bash
# .env
NODE_ENV=production
PORT=3000
HOST=0.0.0.0
DB_PATH=./data/app.db

# OAuth (選用)
OAUTH_CLIENT_ID=...
OAUTH_CLIENT_SECRET=...
OAUTH_REDIRECT_URI=...
```

## 後續開發路線圖

### Phase 1: 核心功能穩定 ✅ (當前階段)
- [x] 八字計算引擎
- [x] 基礎故事生成
- [x] API 端點
- [x] 資料庫設計

### Phase 2: 故事化增強 🚧 (進行中)
- [x] 四時軍團基礎敘事
- [ ] 完整十神技能樹
- [ ] 完整神煞兵符卡池
- [ ] 納音戰場詳細設定

### Phase 3: AI 整合 🔲 (待開發)
- [ ] GPT-4 故事生成
- [ ] 個性化劇情推薦
- [ ] 動態事件觸發

### Phase 4: 前端開發 🔲 (待開發)
- [ ] React 應用框架
- [ ] 四時軍團卡 UI
- [ ] 圖表視覺化
- [ ] 動畫效果

### Phase 5: 多版本支援 🔲 (未來)
- [ ] 女生向版本
- [ ] 西洋奇幻風
- [ ] 日系動漫風
- [ ] 原住民傳說風

---

**文件版本**: 1.0  
**最後更新**: 2025-01-01  
**維護者**: GitHub Copilot Agent
