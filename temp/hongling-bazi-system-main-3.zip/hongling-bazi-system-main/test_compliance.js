const { complianceChecker } = require('./dist/API/ComplianceChecker.js');
const { professionalBaziCalculator } = require('./dist/API/BaziCalculator.js');

async function runTest() {
  console.log('🔍 執行合規檢查...');
  
  const context = {
    baziCalculator: professionalBaziCalculator,
    frontendFiles: [],
    codeFiles: [],
    apiSchemas: {}
  };
  
  const report = await complianceChecker.runComplianceCheck(context);
  
  console.log('📊 合規檢查報告:');
  console.log(`狀態: ${report.overallStatus}`);
  console.log(`總計: ${report.summary.total}, 通過: ${report.summary.passed}, 警告: ${report.summary.warnings}, 錯誤: ${report.summary.errors}`);
  
  report.results.forEach(result => {
    const status = result.result.passed ? '✅' : (result.rule.severity === 'error' ? '❌' : '⚠️');
    console.log(`${status} ${result.rule.name}: ${result.result.message}`);
  });
  
  if (report.recommendations.length > 0) {
    console.log('\n💡 建議:');
    report.recommendations.forEach(rec => console.log(`- ${rec}`));
  }
}

runTest().catch(console.error);
