# 虹靈八字系統部署指南

## 概述
此文檔提供虹靈八字系統的完整部署說明，包含本地開發、Docker 容器化部署、以及雲端平台部署。

## 系統要求
- Node.js >= 18.0.0
- npm >= 8.0.0
- Docker (可選，用於容器化部署)

## 本地部署

### 1. 解壓縮和安裝
```bash
# 解壓縮已完成，依賴已安裝
npm install
```

### 2. 開發模式啟動
```bash
npm run dev
```
應用程式會在 http://localhost:3000 啟動

### 3. 生產模式啟動
```bash
npm run build
npm start
```

### 4. 驗證部署
訪問以下端點：
- 主頁: http://localhost:3000/
- 健康檢查: http://localhost:3000/health
- 敘事生成: POST http://localhost:3000/generate

## Docker 部署

### 1. 生產環境部署
```bash
docker-compose up -d
```

### 2. 開發環境部署（含調試）
```bash
docker-compose -f compose.debug.yaml up -d
```

### 3. 驗證 Docker 部署
```bash
curl http://localhost:3000/health
```

## 雲端部署

### Railway 部署
項目已配置 Railway 部署支持：

1. **railway.json** - Railway 平台配置
2. **Procfile** - Heroku/Railway 啟動配置
3. **環境變數設定**：
   - `NODE_ENV=production`
   - `PORT` (Railway 會自動設定)

#### 部署步驟：
1. 連接 Railway 到 GitHub 儲存庫
2. Railway 會自動檢測 Node.js 項目
3. 自動執行 `npm ci && npm run build`
4. 使用 `npm start` 啟動服務

### Heroku 部署
同樣支持 Heroku 部署：
1. 創建 Heroku 應用
2. 連接 GitHub 儲存庫
3. 啟用自動部署

## API 端點

### 健康檢查
```bash
GET /health
```
回應：
```json
{
  "status": "OK",
  "timestamp": "2025-09-06T03:00:00.920Z",
  "message": "敘事模組運行正常",
  "version": "1.0.0",
  "port": 3000,
  "environment": "development",
  "uptime": 9.115835649,
  "memory": {...},
  "storyEngine": "OK"
}
```

### 敘事生成
```bash
POST /generate
Content-Type: application/json
```
請求體：
```json
{
  "pillar": "年柱",
  "chart": {
    "年柱": {
      "stem": "甲",
      "branch": "子",
      "hidden": ["癸"],
      "naYin": "海中金",
      "tenGod": "比肩",
      "shensha": ["天乙貴人", "華蓋"]
    }
  }
}
```

## 故障排除

### 常見問題

1. **端口衝突**
   - 檢查 3000 端口是否被占用
   - 設定環境變數 `PORT` 使用其他端口

2. **依賴安裝失敗**
   - 清除 npm 快取：`npm cache clean --force`
   - 刪除 node_modules 重新安裝：`rm -rf node_modules && npm install`

3. **TypeScript 編譯錯誤**
   - 執行類型檢查：`npm run type-check`
   - 檢查 tsconfig.json 配置

4. **Docker 建置失敗**
   - 檢查 Dockerfile 語法
   - 確保 .dockerignore 正確配置

## 監控和維護

### 日誌檢查
- 本地：查看控制台輸出
- Docker：`docker logs <container_name>`
- Railway：查看部署日誌面板

### 效能監控
- 使用 `/health` 端點監控應用程式狀態
- 檢查記憶體使用量和運行時間

## 安全性注意事項

1. **環境變數**
   - 不要在代碼中暴露 API 金鑰
   - 使用 `.env` 檔案管理敏感配置

2. **生產部署**
   - 設定 `NODE_ENV=production`
   - 使用 HTTPS 連接
   - 實施適當的錯誤處理

## 支援
如有部署問題，請檢查：
- GitHub Actions 工作流程狀態
- 分支保護規則
- 相關文檔：RAILWAY_DEPLOYMENT_FIX.md