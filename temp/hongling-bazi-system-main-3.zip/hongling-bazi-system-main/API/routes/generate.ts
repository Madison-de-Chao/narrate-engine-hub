import express from "express";
import { generateChart } from "../../storyEngine/chartEngine";
import { generateArmyNarrative } from "../../storyEngine/generateArmyNarrative";
import {
  NAYIN,
  CANG_GAN,
  getTenGod,
  type ChartData,
  type PillarData,
} from "../../storyEngine/utils";

type NarrativeSegment = {
  commander: string;
  strategist: string;
  naYin: string;
  story: string;
};

const router = express.Router();

router.post("/", (req, res) => {
  try {
    const { input } = req.body as {
      input: Parameters<typeof generateChart>[0];
    };
    const chart = generateChart(input);
    // 將 chart 組裝成 narrative 需要的結構
    const dayGan = chart.pillars.day.gan;
    const makePillarData = (
      key: "year" | "month" | "day" | "hour",
    ): PillarData => {
      const g = chart.pillars[key].gan;
      const z = chart.pillars[key].zhi;
      const naYin = NAYIN[g + z] || "";
      const hidden = (CANG_GAN[z] || []).map((x) => x.g);
      const tenGod = getTenGod(dayGan, g);
      return {
        stem: g,
        branch: z,
        hidden,
        naYin,
        tenGod,
        shensha: chart.shensha,
      };
    };
    const chartData: ChartData = {
      year: makePillarData("year"),
      month: makePillarData("month"),
      day: makePillarData("day"),
      hour: makePillarData("hour"),
    };

    // 生成四時軍團故事
    const armyResult = generateArmyNarrative(chart.pillars);
    const narrativeLines = armyResult.narrative.split("\n");

    const build = (
      key: "year" | "month" | "day" | "hour",
      idx: number,
    ): NarrativeSegment => {
      const pillar = chartData[key];
      if (!pillar) {
        throw new Error(`Missing pillar data for ${key}`);
      }
      return {
        commander: pillar.stem,
        strategist: pillar.branch,
        naYin: pillar.naYin,
        story: narrativeLines[idx] || `${key}軍團故事`,
      };
    };
    const narrative = {
      year: build("year", 0),
      month: build("month", 1),
      day: build("day", 2),
      hour: build("hour", 3),
    };
    res.json({ chart, narrative });
  } catch (error: unknown) {
    console.error("命盤生成錯誤：", error);
    res.status(500).json({ error: "命盤生成失敗" });
  }
});

export default router;
