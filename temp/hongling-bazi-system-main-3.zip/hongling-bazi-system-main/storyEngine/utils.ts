// storyEngine/utils.ts — cleaned & typed

import * as fs from "fs";
import * as path from "path";

/* =========================
 *        型別定義
 * ========================= */
export interface Pillar {
  gan: string;
  zhi: string;
  pillar: string;
}

export interface PillarSet {
  year: Pillar;
  month: Pillar;
  day: Pillar;
  hour: Pillar;
}

export interface HiddenStemsData {
  hiddenStems: Record<string, { stems: Array<{ stem: string; weight: number }> }>;
}

// PillarData for narrative generation
export interface PillarData {
  stem: string;
  branch: string;
  hidden: string[];
  naYin: string;
  tenGod: string;
  shensha: string[];
}

// ChartData can be either:
// 1. For API responses (from schemas.ts)
// 2. For narrative generation (mapping of pillars)
export type ChartData = {
  pillars: PillarSet | Record<string, { pillar: string }>;
  tenGods: string[];
  shensha: string[];
  fiveElements: Record<string, number>;
  yinYang: {
    陰: number;
    陽: number;
  };
  tone?: string;
} | {
  year: PillarData;
  month: PillarData;
  day: PillarData;
  hour: PillarData;
};

/* =========================
 *      查表資料載入
 * ========================= */
let ganZhiData: any = null;
let nayinData: any = null;
let hiddenStemsData: HiddenStemsData | null = null;

function loadLookupData(): void {
  if (ganZhiData) return;
  try {
    const dataDir = path.join(__dirname, "../data");
    ganZhiData = JSON.parse(fs.readFileSync(path.join(dataDir, "gan_zhi.json"), "utf8"));
    nayinData = JSON.parse(fs.readFileSync(path.join(dataDir, "nayin.json"), "utf8"));
    hiddenStemsData = JSON.parse(
      fs.readFileSync(path.join(dataDir, "hidden_stems.json"), "utf8")
    );
  } catch (error) {
    console.warn("警告: 無法載入查表資料，使用預設資料。", error);
  }
}
loadLookupData();

/* =========================
 *      天干地支/屬性表
 * ========================= */
// Define default arrays as const first
const DEFAULT_TIAN_GAN = ["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"] as const;
const DEFAULT_DI_ZHI = ["子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"] as const;

export const TIAN_GAN = (ganZhiData?.stems || DEFAULT_TIAN_GAN) as readonly string[];

export const DI_ZHI = (ganZhiData?.branches || DEFAULT_DI_ZHI) as readonly string[];

export const WU_XING_GAN: Record<string, string> = ganZhiData?.stemProperties
  ? Object.fromEntries(
      Object.entries(ganZhiData.stemProperties).map(
        ([stem, props]: [string, any]) => [stem, props.element]
      )
    )
  : { 甲: "木", 乙: "木", 丙: "火", 丁: "火", 戊: "土", 己: "土", 庚: "金", 辛: "金", 壬: "水", 癸: "水" };

export const WU_XING_ZHI: Record<string, string> = ganZhiData?.branchProperties
  ? Object.fromEntries(
      Object.entries(ganZhiData.branchProperties).map(
        ([branch, props]: [string, any]) => [branch, props.element]
      )
    )
  : {
      子: "水",
      丑: "土",
      寅: "木",
      卯: "木",
      辰: "土",
      巳: "火",
      午: "火",
      未: "土",
      申: "金",
      酉: "金",
      戌: "土",
      亥: "水",
    };

export const YIN_YANG_GAN: Record<string, string> = ganZhiData?.stemProperties
  ? Object.fromEntries(
      Object.entries(ganZhiData.stemProperties).map(
        ([stem, props]: [string, any]) => [stem, props.yinyang]
      )
    )
  : { 甲: "陽", 乙: "陰", 丙: "陽", 丁: "陰", 戊: "陽", 己: "陰", 庚: "陽", 辛: "陰", 壬: "陽", 癸: "陰" };

export const YIN_YANG_ZHI: Record<string, string> = ganZhiData?.branchProperties
  ? Object.fromEntries(
      Object.entries(ganZhiData.branchProperties).map(
        ([branch, props]: [string, any]) => [branch, props.yinyang]
      )
    )
  : {
      子: "陽",
      丑: "陰",
      寅: "陽",
      卯: "陰",
      辰: "陽",
      巳: "陰",
      午: "陽",
      未: "陰",
      申: "陽",
      酉: "陰",
      戌: "陽",
      亥: "陰",
    };

/* =========================
 *        角色稱號
 * ========================= */
export const GAN_ROLE: Record<string, string> = {
  甲: "森林將軍",
  乙: "花草軍師",
  丙: "烈日戰神",
  丁: "燭光法師",
  戊: "山岳守護",
  己: "大地母親",
  庚: "鋼鐵騎士",
  辛: "珠寶商人",
  壬: "江河船長",
  癸: "甘露天使",
};

export const ZHI_ROLE: Record<string, string> = {
  子: "夜行刺客",
  丑: "忠犬守衛",
  寅: "森林獵人",
  卯: "春兔使者",
  辰: "龍族法師",
  巳: "火蛇術士",
  午: "烈馬騎兵",
  未: "溫羊牧者",
  申: "靈猴戰士",
  酉: "金雞衛士",
  戌: "戰犬統領",
  亥: "海豚智者",
};

/* =========================
 *     月干/時支對應表
 * ========================= */
export const MONTH_GAN_MAP: Record<string, string[]> = {
  甲: ["丙", "丁", "戊", "己", "庚", "辛", "壬", "癸", "甲", "乙", "丙", "丁"],
  乙: ["戊", "己", "庚", "辛", "壬", "癸", "甲", "乙", "丙", "丁", "戊", "己"],
  丙: ["庚", "辛", "壬", "癸", "甲", "乙", "丙", "丁", "戊", "己", "庚", "辛"],
  丁: ["壬", "癸", "甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"],
  戊: ["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸", "甲", "乙"],
  己: ["丙", "丁", "戊", "己", "庚", "辛", "壬", "癸", "甲", "乙", "丙", "丁"],
  庚: ["戊", "己", "庚", "辛", "壬", "癸", "甲", "乙", "丙", "丁", "戊", "己"],
  辛: ["庚", "辛", "壬", "癸", "甲", "乙", "丙", "丁", "戊", "己", "庚", "辛"],
  壬: ["壬", "癸", "甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"],
  癸: ["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸", "甲", "乙"],
};

export const HOUR_TO_ZHI_MAP: Record<number, string> = {
  23: "子",
  0: "子",
  1: "丑",
  2: "丑",
  3: "寅",
  4: "寅",
  5: "卯",
  6: "卯",
  7: "辰",
  8: "辰",
  9: "巳",
  10: "巳",
  11: "午",
  12: "午",
  13: "未",
  14: "未",
  15: "申",
  16: "申",
  17: "酉",
  18: "酉",
  19: "戌",
  20: "戌",
  21: "亥",
  22: "亥",
};

export const WU_SHU_DUN_SHI_MAP: Record<string, string> = {
  甲: "甲",
  己: "甲",
  乙: "丙",
  庚: "丙",
  丙: "戊",
  辛: "戊",
  丁: "庚",
  壬: "庚",
  戊: "壬",
  癸: "壬",
};

/* =========================
 *      藏干（lazy 讀取）
 * ========================= */
let _cangGanCache: Record<string, { g: string; w: number }[]> | undefined;

export function getCangGan(): Record<string, { g: string; w: number }[]> {
  if (_cangGanCache) return _cangGanCache;
  if (hiddenStemsData?.hiddenStems) {
    _cangGanCache = Object.fromEntries(
      Object.entries(hiddenStemsData.hiddenStems).map(([branch, data]) => [
        branch,
        data.stems.map((s) => ({ g: s.stem, w: s.weight })),
      ])
    );
    return _cangGanCache;
  }
  // 預設
  _cangGanCache = {
    子: [{ g: "癸", w: 1.0 }],
    丑: [{ g: "己", w: 0.6 }, { g: "癸", w: 0.3 }, { g: "辛", w: 0.3 }],
    寅: [{ g: "甲", w: 0.6 }, { g: "丙", w: 0.3 }, { g: "戊", w: 0.3 }],
    卯: [{ g: "乙", w: 1.0 }],
    辰: [{ g: "戊", w: 0.6 }, { g: "乙", w: 0.3 }, { g: "癸", w: 0.3 }],
    巳: [{ g: "丙", w: 0.6 }, { g: "戊", w: 0.3 }, { g: "庚", w: 0.3 }],
    午: [{ g: "丁", w: 0.6 }, { g: "己", w: 0.4 }],
    未: [{ g: "己", w: 0.6 }, { g: "丁", w: 0.3 }, { g: "乙", w: 0.3 }],
    申: [{ g: "庚", w: 0.6 }, { g: "壬", w: 0.3 }, { g: "戊", w: 0.3 }],
    酉: [{ g: "辛", w: 1.0 }],
    戌: [{ g: "戊", w: 0.6 }, { g: "辛", w: 0.3 }, { g: "丁", w: 0.3 }],
    亥: [{ g: "壬", w: 0.6 }, { g: "甲", w: 0.4 }],
  };
  return _cangGanCache;
}

// Export as constant for backward compatibility
export const CANG_GAN = getCangGan();

/* =========================
 *          納音
 * ========================= */
export const NAYIN: Record<string, string> =
  nayinData?.nayin ||
  {
    甲子: "海中金",
    乙丑: "海中金",
    丙寅: "爐中火",
    丁卯: "爐中火",
    戊辰: "大林木",
    己巳: "大林木",
    庚午: "路旁土",
    辛未: "路旁土",
    壬申: "劍鋒金",
    癸酉: "劍鋒金",
    甲戌: "山頭火",
    乙亥: "山頭火",
    丙子: "澗下水",
    丁丑: "澗下水",
    戊寅: "城頭土",
    己卯: "城頭土",
    庚辰: "白蠟金",
    辛巳: "白蠟金",
    壬午: "楊柳木",
    癸未: "楊柳木",
    甲申: "泉中水",
    乙酉: "泉中水",
    丙戌: "屋上土",
    丁亥: "屋上土",
    戊子: "霹靂火",
    己丑: "霹靂火",
    庚寅: "松柏木",
    辛卯: "松柏木",
    壬辰: "長流水",
    癸巳: "長流水",
    甲午: "沙中金",
    乙未: "沙中金",
    丙申: "山下火",
    丁酉: "山下火",
    戊戌: "平地木",
    己亥: "平地木",
    庚子: "壁上土",
    辛丑: "壁上土",
    壬寅: "金箔金",
    癸卯: "金箔金",
    甲辰: "覆燈火",
    乙巳: "覆燈火",
    丙午: "天河水",
    丁未: "天河水",
    戊申: "大驛土",
    己酉: "大驛土",
    庚戌: "釵釧金",
    辛亥: "釵釧金",
    壬子: "桑柘木",
    癸丑: "桑柘木",
    甲寅: "大溪水",
    乙卯: "大溪水",
    丙辰: "沙中土",
    丁巳: "沙中土",
    戊午: "天上火",
    己未: "天上火",
    庚申: "石榴木",
    辛酉: "石榴木",
    壬戌: "大海水",
    癸亥: "大海水",
  };

/* =========================
 *        小工具
 * ========================= */
export function fmtPillars(ps: PillarSet): string {
  return `${ps.year.pillar} ${ps.month.pillar} ${ps.day.pillar} ${ps.hour.pillar}`;
}

export function getStemTitle(stem: string): string {
  return GAN_ROLE[stem] || stem;
}
export function getBranchTitle(branch: string): string {
  return ZHI_ROLE[branch] || branch;
}
export function getShenshaEffect(shensha: string): string {
  const effectMap: Record<string, string> = {
    天乙貴人: "逢兇化吉、得貴相助",
    桃花: "人緣魅力、社交順利",
    驛馬: "奔波變動、機動力強",
  };
  return effectMap[shensha] || shensha;
}

/* =========================
 *     四柱計算（簡化版）
 * ========================= */
const BASE_JIAZI_YEAR = 1984;

export function monthZhiBySolarTerm(y: number, m: number, d: number): string {
  const dt = new Date(y, m - 1, d);
  const stamp = (mm: number, dd: number) => new Date(y, mm - 1, dd);
  const map = [
    { date: stamp(1, 6), zhi: "丑" },
    { date: stamp(2, 4), zhi: "寅" },
    { date: stamp(3, 5), zhi: "卯" },
    { date: stamp(4, 4), zhi: "辰" },
    { date: stamp(5, 5), zhi: "巳" },
    { date: stamp(6, 5), zhi: "午" },
    { date: stamp(7, 7), zhi: "未" },
    { date: stamp(8, 7), zhi: "申" },
    { date: stamp(9, 7), zhi: "酉" },
    { date: stamp(10, 8), zhi: "戌" },
    { date: stamp(11, 7), zhi: "亥" },
    { date: stamp(12, 7), zhi: "子" },
  ];
  let last = map[0];
  for (let i = 0; i < map.length; i++) if (dt >= map[i].date) last = map[i];
  return last.zhi;
}

export function calculateYearPillar(yyyy: number, _mm: number, _dd: number): Pillar {
  const offset = yyyy - BASE_JIAZI_YEAR;
  const s = ((offset % 10) + 10) % 10;
  const b = ((offset % 12) + 12) % 12;
  const gan = TIAN_GAN[s] as string;
  const zhi = DI_ZHI[b] as string;
  return { gan, zhi, pillar: gan + zhi };
}

export function calculateMonthPillar(yearStem: string, yyyy: number, mm: number, dd: number): Pillar {
  const monthZhi = monthZhiBySolarTerm(yyyy, mm, dd);
  const idx = ["寅","卯","辰","巳","午","未","申","酉","戌","亥","子","丑"].indexOf(monthZhi);
  const monthGans = MONTH_GAN_MAP[yearStem] || MONTH_GAN_MAP["甲"];
  const gan = monthGans[idx];
  return { gan, zhi: monthZhi, pillar: gan + monthZhi };
}

export function calculateDayPillar(yyyy: number, mm: number, dd: number): Pillar {
  const base = new Date(1985, 8, 22); // 1985-09-22 略作甲子日
  const target = new Date(yyyy, mm - 1, dd);
  const diff = Math.floor((target.getTime() - base.getTime()) / (24 * 60 * 60 * 1000));
  const s = ((diff % 10) + 10) % 10;
  const b = ((diff % 12) + 12) % 12;
  const gan = TIAN_GAN[s] as string;
  const zhi = DI_ZHI[b] as string;
  return { gan, zhi, pillar: gan + zhi };
}

export function calculateHourPillar(hh: number, dayStem: string): Pillar {
  const zhi = HOUR_TO_ZHI_MAP[hh] || "子";
  const branchIndex = DI_ZHI.indexOf(zhi as (typeof DI_ZHI)[number]);
  const startStem = WU_SHU_DUN_SHI_MAP[dayStem] || "甲";
  const startIndex = TIAN_GAN.indexOf(startStem as (typeof TIAN_GAN)[number]);
  const stemIndex = (startIndex + branchIndex) % 10;
  const gan = TIAN_GAN[stemIndex] as string;
  return { gan, zhi, pillar: gan + zhi };
}

/* =========================
 *        十神（簡化）
 * ========================= */
export function getTenGod(dayStem: string, targetStem: string): string {
  const de = WU_XING_GAN[dayStem];
  const te = WU_XING_GAN[targetStem];
  const dy = YIN_YANG_GAN[dayStem];
  const ty = YIN_YANG_GAN[targetStem];

  if (!de || !te || !dy || !ty) return "比肩";
  if (dayStem === targetStem) return "比肩";
  if (de === te) return dy === ty ? "比肩" : "劫財";

  // 簡化版五行生剋 → 十神（只保留方向與陰陽差）
  const sheng = (a: string, b: string) =>
    (a === "木" && b === "火") ||
    (a === "火" && b === "土") ||
    (a === "土" && b === "金") ||
    (a === "金" && b === "水") ||
    (a === "水" && b === "木");

  const ke = (a: string, b: string) =>
    (a === "木" && b === "土") ||
    (a === "土" && b === "水") ||
    (a === "水" && b === "火") ||
    (a === "火" && b === "金") ||
    (a === "金" && b === "木");

  if (sheng(de, te)) return dy === ty ? "食神" : "傷官";
  if (ke(de, te)) return dy === ty ? "偏財" : "正財";
  if (sheng(te, de)) return dy === ty ? "偏印" : "正印";
  if (ke(te, de)) return dy === ty ? "七殺" : "正官";
  return "比肩";
}

export function calculateTenGods(dayStem: string, otherStems: string[]): string[] {
  return otherStems.map((s) => getTenGod(dayStem, s));
}

/* =========================
 *         神煞（簡化）
 * ========================= */
export function calculateShensha(pillars: PillarSet): string[] {
  const list: string[] = [];
  const yearZhi = pillars.year.zhi;

  if (["丑", "未"].includes(yearZhi)) list.push("天乙貴人");
  if (["子", "午", "卯", "酉"].includes(yearZhi)) list.push("桃花");

  return list.length ? list : ["（本盤暫無核心神煞）"];
}

/* =========================
 *     五行/陰陽統計
 * ========================= */
export function calcFiveElementPower(pillars: PillarSet): Record<string, number> {
  const power: Record<string, number> = { 木: 0, 火: 0, 土: 0, 金: 0, 水: 0 };
  Object.values(pillars).forEach((p) => {
    const se = WU_XING_GAN[p.gan];
    const be = WU_XING_ZHI[p.zhi];
    if (se) power[se] += 1;
    if (be) power[be] += 1;
  });
  return power;
}

export function calcYinYangCount(pillars: PillarSet): { 陰: number; 陽: number } {
  let yin = 0;
  let yang = 0;
  Object.values(pillars).forEach((p) => {
    if (YIN_YANG_GAN[p.gan] === "陽") yang++;
    else yin++;
    if (YIN_YANG_ZHI[p.zhi] === "陽") yang++;
    else yin++;
  });
  return { 陰: yin, 陽: yang };
}

/* =========================
 *        敘事輔助
 * ========================= */
export function generateAdvice(
  pillarKey: "year" | "month" | "day" | "hour",
  stem: string,
  branch: string,
  tenGod: string
): string {
  const domainMap: Record<string, string> = {
    year: "社會舞台",
    month: "關係資源",
    day: "自我核心",
    hour: "未來願景",
  };
  const domain = domainMap[pillarKey] || "此領域";
  const stemRole = getStemTitle(stem);
  const branchRole = getBranchTitle(branch);
  return `${domain}中，以${tenGod}為核心，善用${stemRole}與${branchRole}的特質。`;
}

export function generatePillarStory(pillar: Pillar, position: "year" | "month" | "day" | "hour"): string {
  const stemRole = getStemTitle(pillar.gan);
  const branchRole = getBranchTitle(pillar.zhi);
  const posMap: Record<string, string> = {
    year: "家族傳承的舞台上",
    month: "成長資源的戰場中",
    day: "自我核心的領域裡",
    hour: "未來願景的天空下",
  };
  const scene = posMap[position] || "命運的舞台上";
  return `${scene}，${stemRole}與${branchRole}攜手合作，展現${pillar.pillar}的獨特能量。`;
}

/* =========================
 *       軍團分析/引擎
 * ========================= */
export function analyzeArmyPower(pillars: PillarSet): {
  totalPower: number;
  strongestElement: string;
  weakestElement: string;
  balance: "balanced" | "unbalanced";
} {
  const elements = ["木", "火", "土", "金", "水"];
  const powers = calcFiveElementPower(pillars);

  const totalPower = elements.reduce((s, e) => s + (powers[e] || 0), 0);
  const sorted = elements.map((e) => [e, powers[e] || 0] as const).sort((a, b) => b[1] - a[1]);
  const strongestElement = sorted[0][0];
  const weakestElement = sorted[sorted.length - 1][0];
  const maxP = sorted[0][1];
  const minP = sorted[sorted.length - 1][1];
  const balance = totalPower === 0 ? "balanced" : maxP - minP <= totalPower * 0.4 ? "balanced" : "unbalanced";

  return { totalPower, strongestElement, weakestElement, balance };
}

export class StoryEngine {
  private pillars: PillarSet;
  constructor(pillars: PillarSet) {
    this.pillars = pillars;
  }
  generateFullStory(): {
    title: string;
    introduction: string;
    pillarStories: Record<"year" | "month" | "day" | "hour", string>;
    conclusion: string;
  } {
    const army = analyzeArmyPower(this.pillars);
    return {
      title: "虹靈御所 - 個人命運軍團戰記",
      introduction: `在命運的戰場上，您的靈魂軍團展現了${army.balance === "balanced" ? "均衡" : "特化"}的戰略布局。`,
      pillarStories: {
        year: generatePillarStory(this.pillars.year, "year"),
        month: generatePillarStory(this.pillars.month, "month"),
        day: generatePillarStory(this.pillars.day, "day"),
        hour: generatePillarStory(this.pillars.hour, "hour"),
      },
      conclusion: `您的軍團以${army.strongestElement}為主力，在人生戰場上擁有獨特的戰略優勢。`,
    };
  }
}

