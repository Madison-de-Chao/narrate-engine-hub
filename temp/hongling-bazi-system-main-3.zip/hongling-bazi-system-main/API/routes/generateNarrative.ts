import { Router } from "express";
import { z } from "zod";
import { generateArmyNarrative } from "../../storyEngine/generateArmyNarrative.js";

export const router = Router();

const ChartSchema = z.object({
  year: z.object({ gan: z.string(), zhi: z.string(), pillar: z.string().optional() }),
  month: z.object({ gan: z.string(), zhi: z.string(), pillar: z.string().optional() }),
  day: z.object({ gan: z.string(), zhi: z.string(), pillar: z.string().optional() }),
  hour: z.object({ gan: z.string(), zhi: z.string(), pillar: z.string().optional() }),
});

router.post("/", (req, res) => {
  const parsed = ChartSchema.safeParse(req.body?.chart);
  if (!parsed.success) {
    // Extract traceId from headers or generate a new one
    const traceId =
      req.headers["x-trace-id"] ||
      req.headers["traceid"] ||
      req.headers["x-request-id"] ||
      Math.random().toString(36).substring(2, 15);
    return res.status(400).json({
      error: "invalid_input",
      issues: parsed.error.issues,
      traceId,
      debug: {},
    });
  }
  // Add pillar property if missing
  const data = {
    year: { ...parsed.data.year, pillar: parsed.data.year.pillar || parsed.data.year.gan + parsed.data.year.zhi },
    month: { ...parsed.data.month, pillar: parsed.data.month.pillar || parsed.data.month.gan + parsed.data.month.zhi },
    day: { ...parsed.data.day, pillar: parsed.data.day.pillar || parsed.data.day.gan + parsed.data.day.zhi },
    hour: { ...parsed.data.hour, pillar: parsed.data.hour.pillar || parsed.data.hour.gan + parsed.data.hour.zhi },
  };
  const result = generateArmyNarrative(data);
  const traceId = (req as any).traceId || null;
  const debug = (req as any).debug || {};
  res.json({
    ok: true,
    narrative: result.narrative,
    legions: result.legions,
    traceId,
    debug,
  });
});
