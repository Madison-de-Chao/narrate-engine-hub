# ⚠️ 安全警告 / Security Warning

## 發現的問題 / Issues Found

### 1. API 金鑰外洩 / API Keys Exposure

**嚴重性：🔴 高 / Critical**

在 git 歷史紀錄中發現 `.env` 檔案被追蹤並包含實際的 API 金鑰：

The `.env` file was found in git history containing actual API keys:

- `OPENAI_API_KEY`: sk-BYRw...CwYA (已編輯 / redacted)
- `ANTHROPIC_API_KEY`: sk-ant-...RAAA (已編輯 / redacted)

**這些金鑰已在公開倉庫中暴露，必須立即撤銷！**  
**These keys have been exposed in the public repository and MUST be revoked immediately!**

## 立即採取的行動 / Immediate Actions Required

### 1. 撤銷所有外洩的 API 金鑰 / Revoke All Exposed API Keys

**必須立即執行 / Must be done immediately:**

- [ ] 登入 [OpenAI Platform](https://platform.openai.com/api-keys) 撤銷 OpenAI API 金鑰
- [ ] 登入 [Anthropic Console](https://console.anthropic.com/) 撤銷 Anthropic API 金鑰
- [ ] 生成新的 API 金鑰並妥善保管
- [ ] 更新生產環境的環境變數

### 2. 清理 Git 歷史紀錄 / Clean Git History

**選項 A: 使用 BFG Repo-Cleaner (推薦)**

```bash
# 安裝 BFG
brew install bfg  # macOS
# 或從 https://rtyley.github.io/bfg-repo-cleaner/ 下載

# 清除 .env 檔案
bfg --delete-files .env
git reflog expire --expire=now --all
git gc --prune=now --aggressive
git push --force
```

**選項 B: 使用 git filter-branch**

```bash
git filter-branch --force --index-filter \
  "git rm --cached --ignore-unmatch .env" \
  --prune-empty --tag-name-filter cat -- --all
git push --force --all
git push --force --tags
```

⚠️ **警告**: 這會重寫 git 歷史，所有協作者需要重新克隆倉庫！

### 3. 已採取的預防措施 / Prevention Measures Taken

- [x] 已將 `.env` 從 git 追蹤中移除 (使用 `git rm --cached .env`)
- [x] `.env` 已在 `.gitignore` 中
- [x] 提供 `env.example` 作為範本

### 4. 建議的後續步驟 / Recommended Next Steps

1. **啟用 API 金鑰使用監控**
   - 在 OpenAI 和 Anthropic 控制台設定使用量警報
   - 監控異常使用模式

2. **實施金鑰輪換政策**
   - 定期輪換 API 金鑰（建議每 90 天）
   - 使用環境變數管理服務（如 1Password, AWS Secrets Manager）

3. **添加預提交檢查**
   ```bash
   # 安裝 git-secrets
   git secrets --install
   git secrets --register-aws
   git secrets --add 'sk-[a-zA-Z0-9]{48}'  # OpenAI pattern
   git secrets --add 'sk-ant-[a-zA-Z0-9-]+'  # Anthropic pattern
   ```

4. **啟用 GitHub Secret Scanning**
   - 在 GitHub 倉庫設定中啟用 Secret scanning alerts
   - 設定 Push protection

## 受影響的服務 / Affected Services

- ✅ OpenAI API (GPT models)
- ✅ Anthropic API (Claude models)
- ⚠️ 可能的未授權使用和費用

## 參考資料 / References

- [OpenAI API Key Best Practices](https://platform.openai.com/docs/guides/safety-best-practices)
- [Anthropic API Key Security](https://docs.anthropic.com/claude/reference/getting-started-with-the-api)
- [GitHub Secret Scanning](https://docs.github.com/en/code-security/secret-scanning/about-secret-scanning)
- [git-secrets](https://github.com/awslabs/git-secrets)

---

**最後更新**: 2025-10-27  
**狀態**: 🔴 需要立即處理 / Requires Immediate Action
