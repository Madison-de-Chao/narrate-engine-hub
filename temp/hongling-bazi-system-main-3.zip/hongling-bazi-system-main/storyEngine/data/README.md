# 神煞規則資料化系統 (ShenSha Rule Data System)

## 概述

本系統實現了完整的、可追溯的神煞（ShenSha）計算引擎，採用資料驅動設計，所有神煞規則以 JSON 格式定義，支援動態載入與擴充。

## 目錄結構

```
storyEngine/data/
├── shensha_trad/          # 傳統版神煞規則
│   ├── tianyi_guiren.json # 天乙貴人
│   ├── taohua.json        # 桃花
│   ├── yima.json          # 驛馬
│   └── ...                # 其他13個神煞
├── shensha_legion/        # 四時軍團版規則
│   ├── qiang_taohua.json  # 強桃花（combo規則）
│   └── ...                # 繼承自傳統版 + 特化版本
├── SHENSHA_SPEC.md        # 完整規格文檔
├── AI_GENERATION_TEMPLATE.md # AI 批量產生指令模板
├── SUMMARY.md             # 實作總結
└── README.md              # 本文檔
```

## 核心特性

### ✅ 資料驅動
- 所有規則以 JSON 檔案定義
- 無需修改程式碼即可新增/修改神煞
- 支援熱重載（重啟服務）

### ✅ 多規則類型支援
1. **dayStem**: 以日干為錨點查表
2. **yearBranch/monthBranch/dayBranch/hourBranch**: 以地支為錨點查表
3. **anyBranch**: 支對支互見關係
4. **combo**: 複合條件（多條件 AND/OR）

### ✅ 完整證據鏈
每個神煞命中都包含：
- `name`: 神煞名稱
- `anchor_basis`: 錨點依據
- `why_matched`: 命中原因詳細說明
- `rule_ref`: 規則來源引用
- `priority`: 優先級

### ✅ 兩個 Ruleset
- **trad** (傳統版): 13個經典神煞
- **legion** (軍團版): 14個神煞（含特化版強桃花）

## 快速開始

### TypeScript/JavaScript 使用

```typescript
import ShenshaEngine from './storyEngine/shenshaEngine';

// 建立引擎（選擇 ruleset）
const engine = new ShenshaEngine('trad'); // or 'legion'

// 準備八字數據
const chart = {
  year: { stem: '甲', branch: '申' },
  month: { stem: '乙', branch: '酉' },
  day: { stem: '丙', branch: '卯' },
  hour: { stem: '丁', branch: '子' }
};

// 計算神煞
const matches = engine.calculate(chart);

// 查看結果
console.log(`命中 ${matches.length} 個神煞：`);
matches.forEach(m => {
  console.log(`- ${m.name}: ${m.why_matched}`);
});
```

### API 使用

#### POST /api/bazi/compute
計算指定八字的神煞

```bash
curl -X POST http://localhost:3000/api/bazi/compute \
  -H "Content-Type: application/json" \
  -d '{
    "chart": {
      "year": {"stem": "甲", "branch": "申"},
      "month": {"stem": "乙", "branch": "酉"},
      "day": {"stem": "丙", "branch": "卯"},
      "hour": {"stem": "丁", "branch": "子"}
    },
    "ruleset": "trad"
  }'
```

**回應範例:**
```json
{
  "success": true,
  "data": {
    "anchors": {
      "shensha": [
        {
          "name": "桃花",
          "anchor_basis": "年支=申",
          "why_matched": "查表得[酉]，四柱月支=酉命中",
          "rule_ref": "四柱對照-年支取桃花位",
          "priority": 30
        }
      ]
    },
    "stats": {
      "total": 3,
      "list": ["天乙貴人", "太極貴人", "桃花"]
    }
  },
  "metadata": {
    "ruleset": "trad",
    "engine_version": "1.0",
    "timestamp": "2025-10-19T01:00:00.000Z"
  }
}
```

#### GET /api/bazi/compute?ruleset=trad
查詢引擎資訊（不計算）

#### GET /api/bazi/status
查看系統狀態與已載入的神煞列表

```bash
curl http://localhost:3000/api/bazi/status
```

**回應範例:**
```json
{
  "success": true,
  "system_info": {
    "version": "1.0",
    "timestamp": "2025-10-19T01:00:00.000Z"
  },
  "rulesets": {
    "trad": {
      "directory": "storyEngine/data/shensha_trad",
      "last_modified": "2025-10-19T00:00:00.000Z",
      "loaded_count": 13,
      "loaded_list": ["天乙貴人", "桃花", "驛馬", ...]
    },
    "legion": {
      "directory": "storyEngine/data/shensha_legion",
      "last_modified": "2025-10-19T00:00:00.000Z",
      "loaded_count": 14,
      "loaded_list": ["強桃花", "天乙貴人", ...]
    }
  }
}
```

## 已實作神煞清單

### 傳統版 (13個)
1. 天乙貴人 - 吉神之首
2. 太極貴人 - 智慧洞察
3. 桃花 - 人緣魅力
4. 驛馬 - 奔波變動
5. 羊刃 - 刃鋒威力
6. 天德 - 德行庇護
7. 月德 - 月令庇護
8. 紅鸞 - 姻緣桃花
9. 天喜 - 喜慶婚嫁
10. 孤辰 - 孤獨傾向
11. 寡宿 - 孤寡傾向
12. 劫煞 - 破財風險
13. 亡神 - 失落憂慮

### 軍團版 (14個)
- 包含傳統版全部13個
- 新增：強桃花（combo 複合條件規則）

## 驗證與測試

### 運行測試
```bash
npm run test -- tests/shensha.test.ts
npm run test -- tests/api-shensha-integration.test.ts
```

### JSON 規則驗證
```typescript
import ShenshaValidator from './storyEngine/shenshaValidator';

const validator = new ShenshaValidator();
const result = validator.validate(shenshaDefinition);

if (!result.valid) {
  console.error('驗證失敗：', result.errors);
}
```

## 新增神煞

### 步驟
1. 在 `shensha_trad/` 或 `shensha_legion/` 新增 JSON 檔案
2. 遵守 JSON Schema（參考 SHENSHA_SPEC.md）
3. 使用 ShenshaValidator 驗證
4. 重啟服務載入新規則

### 使用 AI 批量產生
參考 `AI_GENERATION_TEMPLATE.md` 文檔，將指令模板提供給 AI，可快速產生符合規格的 JSON 檔案。

## 規則範例

### 簡單查表規則（桃花）
```json
{
  "name": "桃花",
  "enabled": true,
  "priority": 30,
  "rules": [
    {
      "anchor": "yearBranch",
      "rule_ref": "四柱對照-年支取桃花位",
      "table": {
        "申": ["酉"],
        "子": ["酉"],
        "辰": ["酉"],
        "寅": ["卯"],
        "午": ["卯"],
        "戌": ["卯"]
      }
    }
  ]
}
```

### 複合條件規則（強桃花）
```json
{
  "name": "強桃花",
  "enabled": true,
  "priority": 31,
  "rules": [
    {
      "anchor": "combo",
      "rule_ref": "軍團版-年支取位 + 月/日同應",
      "combo": [
        {
          "anchor": "yearBranch",
          "in": ["申", "子", "辰"],
          "target": "year"
        },
        {
          "anchor": "monthBranch",
          "in": ["酉"],
          "target": "month"
        },
        {
          "anchor": "dayBranch",
          "in": ["酉"],
          "target": "day"
        }
      ]
    }
  ]
}
```

## 效能指標

- 規則載入: < 50ms（13-14個檔案）
- 單次計算: < 5ms（遍歷所有規則）
- 記憶體佔用: < 1MB（所有規則載入後）

## 待擴充神煞

以下神煞規格已準備好，可隨時擴充：
- 文昌貴人、天醫、三奇、天赦
- 學堂、解神、將星、華蓋
- 飛刃、災煞、歲破
- 魁罡、空亡、咸池

## 文檔

- **SHENSHA_SPEC.md**: 完整技術規格
- **AI_GENERATION_TEMPLATE.md**: AI 批量產生指令
- **SUMMARY.md**: 實作總結與統計
- **README.md**: 本文檔（使用指南）

## 授權

本實作遵循專案授權條款。

---

**版本**: 1.0  
**最後更新**: 2025-10-19  
**維護**: Copilot Agent
