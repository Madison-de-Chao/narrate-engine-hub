# Copilot Coding Agent Repository Instructions

This repository is configured for use with GitHub Copilot Coding Agent. Please follow these best practices to ensure smooth collaboration and automation:

## 1. Task Planning & Tracking
- Always break down complex requests into actionable todos.
- Use the Copilot Coding Agent's todo list to track progress and mark items as completed immediately after finishing.

## 2. Code Changes & Reviews
- Use clear, concise commit messages describing the change and its purpose.
- Prefer atomic commits: one logical change per commit.
- Reference related issues or pull requests in commit messages when applicable.

## 3. Workspace Context
- Keep the workspace structure organized and up-to-date.
- Document any non-standard project structure or custom scripts in the README.md.

## 4. Error Handling & Validation
- After making code changes, always validate by running tests or checking for errors.
- Fix new errors immediately if they are relevant to the change.

## 5. Communication
- Use markdown formatting for all Copilot Coding Agent responses.
- When referring to files, classes, or symbols, wrap them in backticks (e.g., `index.ts`).

## 6. Security & Privacy
- Do not commit secrets, credentials, or sensitive data. Use environment variables and `.env.example` for configuration.

## 7. Automation & CI/CD
- Document any automation, CI/CD, or deployment steps in `DEPLOYMENT_GUIDE.md`.

## 8. Extensions & Tools
- List recommended VS Code extensions in the README.md or a dedicated section.

---

For more information, see [Best practices for Copilot coding agent in your repository](https://gh.io/copilot-coding-agent-tips).
