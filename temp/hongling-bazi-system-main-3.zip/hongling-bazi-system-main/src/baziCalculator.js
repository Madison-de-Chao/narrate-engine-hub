// 🌈 虹靈御所八字計算引擎 v9.3 重建版
// 基於默默超的原始設計和節氣資料庫

class BaziCalculator {
    constructor() {
        // 天干地支
        this.stems = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
        this.branches = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];
        
        // 1900-01-31 作為甲子日基準點
        this.baseDate = new Date(1900, 0, 31);
        
        // 月干起始表 (基於年干)
        this.monthStemStart = [2, 2, 4, 4, 6, 6, 8, 8, 0, 0]; // 甲年起丙寅
        
        // 時干起始表 (基於日干)
        this.hourStemStart = [0, 2, 4, 6, 8, 0, 2, 4, 6, 8]; // 甲日起甲子
        
        // 節氣資料庫 (簡化版，實際會從完整資料庫載入)
        this.solarTerms = this.initSolarTermsDatabase();
        
        // 納音對照表
        this.nayin = this.initNayinTable();
        
        // RPG職業對照表
        this.rpgClasses = this.initRPGClasses();
    }

    // 主要計算函數
    calculateBazi(birthDate, birthTime, options = {}) {
        try {
            const {
                useTrueSolarTime = false,
                longitude = 121.5654,
                latitude = 25.0330
            } = options;

            // 轉換輸入日期時間
            const datetime = this.parseDateTime(birthDate, birthTime);
            
            // 真太陽時校正 (如果啟用)
            const adjustedTime = useTrueSolarTime ? 
                this.adjustTrueSolarTime(datetime, longitude) : datetime;

            // 計算四柱
            const yearPillar = this.calculateYearPillar(adjustedTime);
            const monthPillar = this.calculateMonthPillar(adjustedTime, yearPillar.stem);
            const dayPillar = this.calculateDayPillar(adjustedTime);
            const hourPillar = this.calculateHourPillar(adjustedTime, dayPillar.stem);

            // 計算五行
            const fiveElements = this.calculateFiveElements([yearPillar, monthPillar, dayPillar, hourPillar]);

            // RPG遊戲化
            const rpgProfile = this.generateRPGProfile(dayPillar, [yearPillar, monthPillar, dayPillar, hourPillar]);

            // anchorbasis戰術分析
            const anchorBasis = this.analyzeAnchorBasis(dayPillar.stem, yearPillar.branch, dayPillar.branch);

            // 生成證據鏈
            const proofChain = this.generateProofChain(datetime, adjustedTime, useTrueSolarTime, longitude);

            return {
                success: true,
                input: { birthDate, birthTime, options },
                result: {
                    bazi: {
                        year: yearPillar,
                        month: monthPillar,
                        day: dayPillar,
                        hour: hourPillar
                    },
                    fiveElements,
                    rpgProfile,
                    anchorBasis,
                    proofChain
                },
                timestamp: new Date().toISOString()
            };

        } catch (error) {
            return {
                success: false,
                error: error.message,
                timestamp: new Date().toISOString()
            };
        }
    }

    // 年柱計算
    calculateYearPillar(date) {
        const year = date.getFullYear();
        
        // 檢查是否已過立春
        const lichun = this.getSolarTerm(year, '立春');
        const actualYear = date >= lichun ? year : year - 1;
        
        // 計算干支 (1984年甲子年為基準)
        const yearsSince1984 = actualYear - 1984;
        const stemIndex = (yearsSince1984 % 10 + 10) % 10; // 甲=0
        const branchIndex = (yearsSince1984 % 12 + 12) % 12; // 子=0
        
        return {
            stem: this.stems[stemIndex],
            branch: this.branches[branchIndex],
            nayin: this.getNayin(stemIndex, branchIndex)
        };
    }

    // 月柱計算
    calculateMonthPillar(date, yearStem) {
        const year = date.getFullYear();
        const month = date.getMonth() + 1;
        
        // 獲取本月節氣
        const currentMonthTerms = this.getMonthSolarTerms(year, month);
        
        // 判斷月支
        let monthBranchIndex;
        if (month === 1) {
            // 1月需要檢查立春
            const lichun = this.getSolarTerm(year, '立春');
            monthBranchIndex = date >= lichun ? 2 : 1; // 寅月或丑月
        } else {
            // 其他月份根據節氣判斷
            monthBranchIndex = this.getMonthBranchByTerm(date, currentMonthTerms);
        }
        
        // 計算月干 (根據年干和月支)
        const yearStemIndex = this.stems.indexOf(yearStem);
        const monthStemIndex = (this.monthStemStart[yearStemIndex] + monthBranchIndex) % 10;
        
        return {
            stem: this.stems[monthStemIndex],
            branch: this.branches[monthBranchIndex],
            nayin: this.getNayin(monthStemIndex, monthBranchIndex)
        };
    }

    // 日柱計算
    calculateDayPillar(date) {
        // 以1900-01-31甲子日為基準計算
        const daysDiff = Math.floor((date - this.baseDate) / (1000 * 60 * 60 * 24));
        
        // 計算干支索引 (甲子日為40)
        const ganzhiIndex = (daysDiff + 40) % 60;
        const stemIndex = ganzhiIndex % 10;
        const branchIndex = ganzhiIndex % 12;
        
        return {
            stem: this.stems[stemIndex],
            branch: this.branches[branchIndex],
            nayin: this.getNayin(stemIndex, branchIndex)
        };
    }

    // 時柱計算
    calculateHourPillar(date, dayStem) {
        const hours = date.getHours();
        
        // 時辰對照 (23-1子時, 1-3丑時, ...)
        let hourBranchIndex;
        if (hours >= 23 || hours < 1) hourBranchIndex = 0; // 子
        else hourBranchIndex = Math.floor((hours + 1) / 2);
        
        // 計算時干 (根據日干)
        const dayStemIndex = this.stems.indexOf(dayStem);
        const hourStemIndex = (this.hourStemStart[dayStemIndex] + hourBranchIndex) % 10;
        
        return {
            stem: this.stems[hourStemIndex],
            branch: this.branches[hourBranchIndex],
            nayin: this.getNayin(hourStemIndex, hourBranchIndex)
        };
    }

    // 五行計算
    calculateFiveElements(pillars) {
        const elements = { wood: 0, fire: 0, earth: 0, metal: 0, water: 0 };
        
        const stemElements = {
            '甲': 'wood', '乙': 'wood',
            '丙': 'fire', '丁': 'fire', 
            '戊': 'earth', '己': 'earth',
            '庚': 'metal', '辛': 'metal',
            '壬': 'water', '癸': 'water'
        };
        
        const branchElements = {
            '子': 'water', '亥': 'water',
            '寅': 'wood', '卯': 'wood',
            '巳': 'fire', '午': 'fire',
            '申': 'metal', '酉': 'metal',
            '丑': 'earth', '辰': 'earth', '未': 'earth', '戌': 'earth'
        };
        
        pillars.forEach(pillar => {
            elements[stemElements[pillar.stem]] += 1.0;
            elements[branchElements[pillar.branch]] += 0.8;
        });
        
        return elements;
    }

    // RPG職業生成
    generateRPGProfile(dayPillar, allPillars) {
        const rpgClass = this.rpgClasses[dayPillar.stem];
        const battlefield = this.getNayinBattlefield(dayPillar.stem + dayPillar.branch);
        
        return {
            class: rpgClass.name,
            battlefield: battlefield.scene,
            buffs: battlefield.buffs,
            debuffs: battlefield.debuffs,
            specialAbilities: rpgClass.abilities
        };
    }

    // anchorbasis戰術分析
    analyzeAnchorBasis(dayStem, yearBranch, dayBranch) {
        const anchor = `${dayStem}-${yearBranch}-${dayBranch}`;
        
        // 戰術分析邏輯
        const tactics = this.getAnchorBasisTactics(anchor);
        
        return {
            anchor,
            battleFormation: tactics.formation,
            tacticalAdvantage: tactics.advantages,
            whyMatched: tactics.explanation
        };
    }

    // 真太陽時校正
    adjustTrueSolarTime(datetime, longitude) {
        // 簡化的真太陽時計算
        const timeCorrection = (longitude - 120) * 4; // 分鐘
        return new Date(datetime.getTime() + timeCorrection * 60000);
    }

    // 輔助函數
    parseDateTime(dateStr, timeStr) {
        const [year, month, day] = dateStr.split('-').map(Number);
        const [hours, minutes] = timeStr.split(':').map(Number);
        return new Date(year, month - 1, day, hours, minutes);
    }

    // 節氣資料庫初始化 (簡化版)
    initSolarTermsDatabase() {
        // 實際會從完整的節氣資料庫載入
        return {
            '1985': {
                '立春': new Date(1985, 1, 4, 5, 32),
                '寒露': new Date(1985, 9, 8, 16, 14)
                // ... 其他節氣
            }
            // ... 1850-2100年完整數據
        };
    }

    // 納音表初始化
    initNayinTable() {
        return {
            '甲子': '海中金', '乙丑': '海中金',
            '丙寅': '爐中火', '丁卯': '爐中火'
            // ... 完整60甲子納音
        };
    }

    // RPG職業初始化
    initRPGClasses() {
        return {
            '甲': { name: '森林領主', abilities: ['生命復甦', '成長加速'] },
            '乙': { name: '花草精靈', abilities: ['治療術', '柔韌防禦'] },
            '丙': { name: '烈焰戰士', abilities: ['爆發攻擊', '照明術'] }
            // ... 完整10天干職業
        };
    }

    // 其他輔助函數...
    getSolarTerm(year, termName) {
        return this.solarTerms[year]?.[termName] || new Date();
    }

    getNayin(stemIndex, branchIndex) {
        const ganzhi = this.stems[stemIndex] + this.branches[branchIndex];
        return this.nayin[ganzhi] || '未知';
    }

    generateProofChain(original, adjusted, useTST, longitude) {
        const chain = [];
        chain.push(`輸入時間: ${original.toLocaleString('zh-TW')}`);
        
        if (useTST) {
            const diff = (adjusted - original) / 60000;
            chain.push(`真太陽時校正: ${diff > 0 ? '+' : ''}${diff.toFixed(1)}分鐘`);
        }
        
        chain.push('四柱計算完成');
        chain.push('RPG轉換完成');
        
        return chain;
    }

    // 更多輔助函數...
}

module.exports = BaziCalculator;
