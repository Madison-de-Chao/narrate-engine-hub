import express from "express";
import type { InputData } from "../../storyEngine/chartEngine";

const router = express.Router();

interface GenerateV2Request {
  input: string | InputData;
  tone?: string;
  options?: {
    useAI?: boolean;
    provider?: string;
    storyType?: string;
  };
}

// POST /generate-v2 - Two-step story generation process
router.post("/", async (req, res) => {
  try {
    const { input, tone, options = {} } = req.body as GenerateV2Request;
    const apiKey = req.headers["x-api-key"] as string;

    if (!input) {
      return res.status(400).json({
        success: false,
        error: "缺少必要的 input 參數",
      });
    }

    // Parse input data to expected format
    let chartInput: InputData;
    if (typeof input === "string") {
      // Parse date string like "1984-01-01 12:00:00"
      const date = new Date(input);
      chartInput = {
        yyyy: date.getFullYear(),
        mm: date.getMonth() + 1,
        dd: date.getDate(),
        hh: date.getHours(),
      };
    } else if (typeof input === "object" && input.yyyy !== undefined) {
      // Already in correct format
      chartInput = input;
    } else {
      return res.status(400).json({
        success: false,
        error:
          "Input should be either a date string or object with yyyy, mm, dd, hh properties",
      });
    }

    // Step 1: Validate API key if provided
    let keyId: string | null = null;
    if (apiKey) {
      try {
        // Call our key validation endpoint internally
        const keyValidationResponse = await fetch(
          `${req.protocol}://${req.get("host")}/api/keys`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-API-Key": apiKey,
            },
            body: JSON.stringify({
              service: "story-generation",
              provider: options.provider || "local",
            }),
          },
        );

        if (keyValidationResponse.ok) {
          const keyData = (await keyValidationResponse.json()) as {
            data: { keyId: string };
          };
          keyId = keyData.data.keyId;
        } else {
          return res.status(401).json({
            success: false,
            error: "API key validation failed",
          });
        }
      } catch (error) {
        console.warn("API key validation failed:", error);
        // Continue without key validation for backward compatibility
      }
    }

    // Import the chart generation logic
    const { generateChart } = await import("../../storyEngine/chartEngine");
    const { NAYIN, CANG_GAN, getTenGod } = await import(
      "../../storyEngine/utils"
    );
    type PillarData = import("../../storyEngine/utils").PillarData;

    const chart = generateChart(chartInput);

    // Prepare narrative data structure - build complete chart with all pillars
    const dayGan = chart.pillars.day.gan;
    const buildPillarData = (
      key: "year" | "month" | "day" | "hour",
    ): PillarData => {
      const g = chart.pillars[key].gan;
      const z = chart.pillars[key].zhi;
      const naYin = NAYIN[g + z] || "";
      const hidden = (CANG_GAN[z] || []).map((x) => x.g);
      const tenGod = getTenGod(dayGan, g);

      return {
        stem: g,
        branch: z,
        hidden,
        naYin,
        tenGod,
        shensha: chart.shensha,
      };
    };

    // Build complete chart data with all pillars
    const completeChartData = {
      year: buildPillarData("year"),
      month: buildPillarData("month"),
      day: buildPillarData("day"),
      hour: buildPillarData("hour"),
    };

    const pillars = ["year", "month", "day", "hour"] as const;
    const narrativePromises = pillars.map(async (pillar) => {
      const pillarInfo = completeChartData[pillar];

      // Step 2: Generate story using AI endpoint if key is available and AI is requested
      if (keyId && options.useAI) {
        try {
          const storyResponse = await fetch(
            `${req.protocol}://${req.get("host")}/api/ai/story`,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                keyId,
                type: options.storyType || "army-narrative",
                data: { pillar, chart: completeChartData },
                options: { tone },
              }),
            },
          );

          if (storyResponse.ok) {
            const storyData = (await storyResponse.json()) as {
              data: { story: string; storyId: string };
            };
            return {
              commander: pillarInfo.stem,
              strategist: pillarInfo.branch,
              naYin: pillarInfo.naYin,
              story: storyData.data.story,
              generatedBy: "ai" as const,
              storyId: storyData.data.storyId,
            };
          }
        } catch (error) {
          console.warn(`AI story generation failed for ${pillar}:`, error);
          // Fall back to local generation
        }
      }

      // Fallback to local story generation
      const { generateArmyNarrative } = await import(
        "../../storyEngine/generateArmyNarrative"
      );
      const pillarsForNarrative = {
        year: {
          gan: completeChartData.year.stem,
          zhi: completeChartData.year.branch,
          pillar: completeChartData.year.stem + completeChartData.year.branch,
        },
        month: {
          gan: completeChartData.month.stem,
          zhi: completeChartData.month.branch,
          pillar: completeChartData.month.stem + completeChartData.month.branch,
        },
        day: {
          gan: completeChartData.day.stem,
          zhi: completeChartData.day.branch,
          pillar: completeChartData.day.stem + completeChartData.day.branch,
        },
        hour: {
          gan: completeChartData.hour.stem,
          zhi: completeChartData.hour.branch,
          pillar: completeChartData.hour.stem + completeChartData.hour.branch,
        },
      };
      const armyResult = generateArmyNarrative(pillarsForNarrative);
      const narrativeLines = armyResult.narrative.split("\n");
      const pillarIndex = ["year", "month", "day", "hour"].indexOf(pillar);
      const story = narrativeLines[pillarIndex] || `${pillar}軍團故事`;

      return {
        commander: pillarInfo.stem,
        strategist: pillarInfo.branch,
        naYin: pillarInfo.naYin,
        story,
        generatedBy: "local",
      };
    });

    const narrativeResults = await Promise.all(narrativePromises);

    const narrative = {
      year: narrativeResults[0],
      month: narrativeResults[1],
      day: narrativeResults[2],
      hour: narrativeResults[3],
    };

    res.json({
      success: true,
      chart,
      narrative,
      metadata: {
        version: "v2",
        generationMethod:
          keyId && options.useAI ? "two-step-ai" : "single-step-local",
        keyId: keyId || null,
        generatedAt: new Date().toISOString(),
      },
    });
    return;
  } catch (err) {
    console.error("V2 命盤生成錯誤：", err);
    res.status(500).json({
      success: false,
      error: "命盤生成失敗",
      details: err instanceof Error ? err.message : "Unknown error",
    });
    return;
  }
});

export default router;
