import * as fs from 'fs'
import * as path from 'path'

export interface StoryPrompt {
  id: string
  name: string
  type: 'army-narrative' | 'fortune-analysis' | 'life-prediction'
  language: 'zh-TW' | 'zh-CN' | 'en'
  tone: 'heroic' | 'mystical' | 'analytical' | 'casual'
  template: string
  variables: string[]
  metadata: {
    author: string
    version: string
    createdAt: string
    updatedAt: string
  }
}

export interface CharacterSetting {
  id: string
  name: string
  role: 'commander' | 'strategist' | 'lieutenant'
  stem?: string
  branch?: string
  description: string
  abilities: string[]
  personality: string[]
  backstory: string
  quotes: string[]
}

export interface BingfuCard {
  id: string
  name: string
  type: 'shensha'
  effect: string
  description: string
  powerLevel: number
  rarity: 'common' | 'rare' | 'epic' | 'legendary'
  conditions: string[]
  narrativeTemplate: string
}

export interface NayinBattlefield {
  id: string
  name: string
  element: '金' | '木' | '水' | '火' | '土'
  environment: string
  advantages: string[]
  challenges: string[]
  storyContext: string
  weatherEffects?: string[]
}

export interface StoryTemplate {
  id: string
  name: string
  structure: {
    opening: string
    development: string
    climax: string
    resolution: string
  }
  placeholders: Record<string, string>
  tone: string
  length: 'short' | 'medium' | 'long'
}

/**
 * StoryMaterialsManager - 管理所有故事生成用素材
 * 符合問題陳述要求：AI故事Prompt、角色設定、兵符卡、納音戰場等生成用素材全部資料庫/JSON分離管理
 */
export class StoryMaterialsManager {
  private prompts: Map<string, StoryPrompt> = new Map()
  private characters: Map<string, CharacterSetting> = new Map()
  private bingfuCards: Map<string, BingfuCard> = new Map()
  private battlefields: Map<string, NayinBattlefield> = new Map()
  private templates: Map<string, StoryTemplate> = new Map()
  private materialsPath: string

  constructor(materialsPath?: string) {
    this.materialsPath = materialsPath || path.join(__dirname, '../materials')
    this.ensureMaterialsDirectory()
    this.loadAllMaterials()
  }

  /**
   * 確保素材目錄存在
   */
  private ensureMaterialsDirectory(): void {
    const dirs = [
      this.materialsPath,
      path.join(this.materialsPath, 'prompts'),
      path.join(this.materialsPath, 'characters'),
      path.join(this.materialsPath, 'bingfu-cards'),
      path.join(this.materialsPath, 'battlefields'),
      path.join(this.materialsPath, 'templates')
    ]

    dirs.forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true })
      }
    })
  }

  /**
   * 載入所有素材
   */
  private loadAllMaterials(): void {
    this.loadPrompts()
    this.loadCharacters()
    this.loadBingfuCards()
    this.loadBattlefields()
    this.loadTemplates()
  }

  /**
   * 載入故事提示詞
   */
  private loadPrompts(): void {
    const promptsFile = path.join(this.materialsPath, 'prompts', 'story-prompts.json')
    
    if (!fs.existsSync(promptsFile)) {
      this.createDefaultPrompts()
    }

    try {
      const data = JSON.parse(fs.readFileSync(promptsFile, 'utf8'))
      data.forEach((prompt: StoryPrompt) => {
        this.prompts.set(prompt.id, prompt)
      })
    } catch (error) {
      console.warn('Failed to load story prompts:', error)
      this.createDefaultPrompts()
    }
  }

  /**
   * 載入角色設定
   */
  private loadCharacters(): void {
    const charactersFile = path.join(this.materialsPath, 'characters', 'character-settings.json')
    
    if (!fs.existsSync(charactersFile)) {
      this.createDefaultCharacters()
    }

    try {
      const data = JSON.parse(fs.readFileSync(charactersFile, 'utf8'))
      data.forEach((character: CharacterSetting) => {
        this.characters.set(character.id, character)
      })
    } catch (error) {
      console.warn('Failed to load character settings:', error)
      this.createDefaultCharacters()
    }
  }

  /**
   * 載入兵符卡
   */
  private loadBingfuCards(): void {
    const cardsFile = path.join(this.materialsPath, 'bingfu-cards', 'shensha-cards.json')
    
    if (!fs.existsSync(cardsFile)) {
      this.createDefaultBingfuCards()
    }

    try {
      const data = JSON.parse(fs.readFileSync(cardsFile, 'utf8'))
      data.forEach((card: BingfuCard) => {
        this.bingfuCards.set(card.id, card)
      })
    } catch (error) {
      console.warn('Failed to load bingfu cards:', error)
      this.createDefaultBingfuCards()
    }
  }

  /**
   * 載入納音戰場
   */
  private loadBattlefields(): void {
    const battlefieldsFile = path.join(this.materialsPath, 'battlefields', 'nayin-battlefields.json')
    
    if (!fs.existsSync(battlefieldsFile)) {
      this.createDefaultBattlefields()
    }

    try {
      const data = JSON.parse(fs.readFileSync(battlefieldsFile, 'utf8'))
      data.forEach((battlefield: NayinBattlefield) => {
        this.battlefields.set(battlefield.id, battlefield)
      })
    } catch (error) {
      console.warn('Failed to load battlefields:', error)
      this.createDefaultBattlefields()
    }
  }

  /**
   * 載入故事模板
   */
  private loadTemplates(): void {
    const templatesFile = path.join(this.materialsPath, 'templates', 'story-templates.json')
    
    if (!fs.existsSync(templatesFile)) {
      this.createDefaultTemplates()
    }

    try {
      const data = JSON.parse(fs.readFileSync(templatesFile, 'utf8'))
      data.forEach((template: StoryTemplate) => {
        this.templates.set(template.id, template)
      })
    } catch (error) {
      console.warn('Failed to load story templates:', error)
      this.createDefaultTemplates()
    }
  }

  /**
   * 創建默認故事提示詞
   */
  private createDefaultPrompts(): void {
    const defaultPrompts: StoryPrompt[] = [
      {
        id: 'army-narrative-heroic-zh-tw',
        name: '軍團敘事-英雄風格-繁體中文',
        type: 'army-narrative',
        language: 'zh-TW',
        tone: 'heroic',
        template: `你是一位古代軍師，正在為主公分析軍團配置。

主將：{{commander}} ({{stem}})
軍師：{{strategist}} ({{branch}})
副將：{{lieutenants}}
納音戰場：{{nayin}}
神煞兵符：{{shensha}}
十神特質：{{tengod}}

請以古典軍事風格，描述這個{{pillar}}軍團的特色、戰術優勢、以及在人生戰場上的策略建議。文字要有氣勢，充滿智慧，約200-300字。`,
        variables: ['commander', 'stem', 'strategist', 'branch', 'lieutenants', 'nayin', 'shensha', 'tengod', 'pillar'],
        metadata: {
          author: 'system',
          version: '1.0',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      },
      {
        id: 'fortune-analysis-mystical-zh-tw',
        name: '運勢分析-神秘風格-繁體中文',
        type: 'fortune-analysis',
        language: 'zh-TW',
        tone: 'mystical',
        template: `以神秘學的角度，分析以下八字配置的運勢走向：

年柱：{{yearPillar}}
月柱：{{monthPillar}}
日柱：{{dayPillar}}
時柱：{{hourPillar}}

神煞配置：{{allShensha}}
五行平衡：{{fiveElements}}
十神分佈：{{tenGods}}

請預測近期運勢、人生轉折點、以及需要注意的事項。語調神秘而有深度，約300-400字。`,
        variables: ['yearPillar', 'monthPillar', 'dayPillar', 'hourPillar', 'allShensha', 'fiveElements', 'tenGods'],
        metadata: {
          author: 'system',
          version: '1.0',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      }
    ]

    this.savePrompts(defaultPrompts)
    defaultPrompts.forEach(prompt => {
      this.prompts.set(prompt.id, prompt)
    })
  }

  /**
   * 創建默認角色設定
   */
  private createDefaultCharacters(): void {
    const defaultCharacters: CharacterSetting[] = [
      {
        id: 'commander-jia',
        name: '甲木將軍',
        role: 'commander',
        stem: '甲',
        description: '如參天大樹般的威武將軍，有著不屈的意志和領導天賦',
        abilities: ['統帥三軍', '開疆拓土', '正直領導'],
        personality: ['正直', '堅毅', '有責任感', '積極進取'],
        backstory: '生於東方青龙之地，從小展現過人的領導才能',
        quotes: ['正道直行，無愧於心', '樹大招風，但我自巍然不動']
      },
      {
        id: 'strategist-zi',
        name: '子水軍師',
        role: 'strategist',
        branch: '子',
        description: '智慧如水，善於變通的謀略大師',
        abilities: ['深謀遠慮', '靈活變通', '洞察人心'],
        personality: ['機智', '靈活', '深沉', '善於觀察'],
        backstory: '來自北方玄武之境，精通兵法與人心',
        quotes: ['上善若水，兵無常勢', '知己知彼，百戰不殆']
      }
    ]

    this.saveCharacters(defaultCharacters)
    defaultCharacters.forEach(character => {
      this.characters.set(character.id, character)
    })
  }

  /**
   * 創建默認兵符卡
   */
  private createDefaultBingfuCards(): void {
    const defaultCards: BingfuCard[] = [
      {
        id: 'tianyiguiren',
        name: '天乙貴人',
        type: 'shensha',
        effect: '貴人相助',
        description: '天降貴人，在關鍵時刻獲得重要人物的幫助和支持',
        powerLevel: 9,
        rarity: 'legendary',
        conditions: ['日干查年月時支'],
        narrativeTemplate: '天乙貴人加持，使你在困境中總能遇到貴人相助，化險為夷'
      },
      {
        id: 'taohua',
        name: '桃花',
        type: 'shensha',
        effect: '人緣魅力',
        description: '增強個人魅力，提升人際關係和異性緣分',
        powerLevel: 6,
        rarity: 'rare',
        conditions: ['亥卯未見子', '巳酉丑見午', '申子辰見酉', '寅午戌見卯'],
        narrativeTemplate: '桃花星照命，賦予你非凡的魅力和良好的人際關係'
      }
    ]

    this.saveBingfuCards(defaultCards)
    defaultCards.forEach(card => {
      this.bingfuCards.set(card.id, card)
    })
  }

  /**
   * 創建默認納音戰場
   */
  private createDefaultBattlefields(): void {
    const defaultBattlefields: NayinBattlefield[] = [
      {
        id: 'haijong-jin',
        name: '海中金',
        element: '金',
        environment: '深海金礦，波濤洶湧中隱藏著珍貴的寶藏',
        advantages: ['韌性強', '內斂沉穩', '價值不凡'],
        challenges: ['需要時間磨練', '容易被埋沒'],
        storyContext: '在深海的考驗中，真金不怕火煉，終將綻放光芒',
        weatherEffects: ['海嘯時力量倍增', '乾旱時受限']
      },
      {
        id: 'furnace-fire',
        name: '爐中火',
        element: '火',
        environment: '熊熊烈火的煉金爐，極高溫度中鍛造最強武器',
        advantages: ['爆發力強', '精煉能力', '創造力豐富'],
        challenges: ['消耗巨大', '需要持續燃料'],
        storyContext: '爐火純青，能夠將平凡的金屬鍛造成神兵利器',
        weatherEffects: ['寒冬中威力不減', '暴雨時需要保護']
      }
    ]

    this.saveBattlefields(defaultBattlefields)
    defaultBattlefields.forEach(battlefield => {
      this.battlefields.set(battlefield.id, battlefield)
    })
  }

  /**
   * 創建默認故事模板
   */
  private createDefaultTemplates(): void {
    const defaultTemplates: StoryTemplate[] = [
      {
        id: 'classic-military',
        name: '經典軍事模板',
        structure: {
          opening: '🛡️【{{pillar}}軍團｜{{stem}}{{branch}}】',
          development: '主將{{commander}}統領三軍，軍師{{strategist}}運籌帷幄',
          climax: '在{{nayin}}戰場上，憑藉{{shensha}}兵符的力量',
          resolution: '最終獲得勝利，展現{{tengod}}的特質'
        },
        placeholders: {
          pillar: '年/月/日/時',
          stem: '天干',
          branch: '地支',
          commander: '主將名稱',
          strategist: '軍師名稱',
          nayin: '納音',
          shensha: '神煞',
          tengod: '十神'
        },
        tone: 'heroic',
        length: 'medium'
      }
    ]

    this.saveTemplates(defaultTemplates)
    defaultTemplates.forEach(template => {
      this.templates.set(template.id, template)
    })
  }

  /**
   * 保存提示詞到文件
   */
  private savePrompts(prompts: StoryPrompt[]): void {
    const filePath = path.join(this.materialsPath, 'prompts', 'story-prompts.json')
    fs.writeFileSync(filePath, JSON.stringify(prompts, null, 2), 'utf8')
  }

  /**
   * 保存角色設定到文件
   */
  private saveCharacters(characters: CharacterSetting[]): void {
    const filePath = path.join(this.materialsPath, 'characters', 'character-settings.json')
    fs.writeFileSync(filePath, JSON.stringify(characters, null, 2), 'utf8')
  }

  /**
   * 保存兵符卡到文件
   */
  private saveBingfuCards(cards: BingfuCard[]): void {
    const filePath = path.join(this.materialsPath, 'bingfu-cards', 'shensha-cards.json')
    fs.writeFileSync(filePath, JSON.stringify(cards, null, 2), 'utf8')
  }

  /**
   * 保存戰場到文件
   */
  private saveBattlefields(battlefields: NayinBattlefield[]): void {
    const filePath = path.join(this.materialsPath, 'battlefields', 'nayin-battlefields.json')
    fs.writeFileSync(filePath, JSON.stringify(battlefields, null, 2), 'utf8')
  }

  /**
   * 保存模板到文件
   */
  private saveTemplates(templates: StoryTemplate[]): void {
    const filePath = path.join(this.materialsPath, 'templates', 'story-templates.json')
    fs.writeFileSync(filePath, JSON.stringify(templates, null, 2), 'utf8')
  }

  /**
   * 獲取故事提示詞
   */
  public getPrompt(type: string, language: string = 'zh-TW', tone: string = 'heroic'): StoryPrompt | null {
    const promptId = `${type}-${tone}-${language}`
    return this.prompts.get(promptId) || Array.from(this.prompts.values()).find(p => 
      p.type === type && p.language === language
    ) || null
  }

  /**
   * 獲取角色設定
   */
  public getCharacter(stem?: string, branch?: string, role?: string): CharacterSetting | null {
    if (stem) {
      const character = Array.from(this.characters.values()).find(c => c.stem === stem)
      if (character) return character
    }
    
    if (branch) {
      const character = Array.from(this.characters.values()).find(c => c.branch === branch)
      if (character) return character
    }

    if (role) {
      const character = Array.from(this.characters.values()).find(c => c.role === role)
      if (character) return character
    }

    return null
  }

  /**
   * 獲取兵符卡
   */
  public getBingfuCard(shenshaName: string): BingfuCard | null {
    return this.bingfuCards.get(shenshaName.toLowerCase()) || 
           Array.from(this.bingfuCards.values()).find(c => c.name === shenshaName) || null
  }

  /**
   * 獲取納音戰場
   */
  public getBattlefield(nayinName: string): NayinBattlefield | null {
    return this.battlefields.get(nayinName.toLowerCase().replace(/\s+/g, '-')) ||
           Array.from(this.battlefields.values()).find(b => b.name === nayinName) || null
  }

  /**
   * 獲取故事模板
   */
  public getTemplate(templateId: string): StoryTemplate | null {
    return this.templates.get(templateId) || null
  }

  /**
   * 熱更新素材
   */
  public reloadMaterials(): void {
    this.prompts.clear()
    this.characters.clear()
    this.bingfuCards.clear()
    this.battlefields.clear()
    this.templates.clear()
    this.loadAllMaterials()
  }

  /**
   * 添加新的提示詞
   */
  public addPrompt(prompt: StoryPrompt): void {
    this.prompts.set(prompt.id, prompt)
    const allPrompts = Array.from(this.prompts.values())
    this.savePrompts(allPrompts)
  }

  /**
   * 獲取所有素材統計
   */
  public getStats(): Record<string, number> {
    return {
      prompts: this.prompts.size,
      characters: this.characters.size,
      bingfuCards: this.bingfuCards.size,
      battlefields: this.battlefields.size,
      templates: this.templates.size
    }
  }
}

// 單例實例
export const storyMaterialsManager = new StoryMaterialsManager()