# 神煞JSON規則 AI 產生指令模板

## 目標
依《神煞對照表》把每顆神煞轉寫成 JSON 規則檔。

## 輸出要求
- 嚴格遵守本文的 Schema、合法值與語意，不填造、無資料則留空陣列或設 `enabled:false`
- 僅輸出 JSON，不要多餘文字

## 語意準則

### 1. dayStem 規則
- 以日干為 key，value 是「應命中的地支集合」
- 命中條件：只要四柱任一支 ∈ 該集合，即判定為命中

### 2. *Branch 規則（yearBranch, monthBranch, dayBranch, hourBranch）
- 以某柱地支為 key，value 是「應命中的地支集合」
- 命中條件：只要四柱任一支 ∈ 該集合，即判定為命中

### 3. anyBranch 規則
- 遍歷四柱之支，互見關係命中
- 如果出現「X 支對應集合中包含四柱中另外一支」，視為命中

### 4. combo 規則
- 多錨點 AND 聯合
- 子條件 `any=true` 代表該子條件內部 OR
- 每個子條件可以指定 `target`（year/month/day/hour/any）

### 5. rule_ref 必填
- 標記來源（書名/條文/派別）
- 例：「傳統對照-日干取貴人支」、「軍團版-年支取位 + 月/日同應」

### 6. 未列對照的條目
- 輸出模板檔：`enabled:false` 並於 notes 註明「待補權威表」

## JSON Schema 結構

\`\`\`json
{
  "name": "string",           // 神煞名稱（繁中）
  "enabled": true|false,      // 是否啟用
  "priority": 10,             // 越小優先越高（數字）
  "rules": [
    {
      "anchor": "dayStem | yearBranch | monthBranch | dayBranch | hourBranch | anyBranch | combo",
      "rule_ref": "string",   // 來源/派別/書目
      "table": {              // 針對 anchor 的查表（非 combo 時使用）
        "鍵": ["值","值"]     // dayStem: 甲乙丙丁戊己庚辛壬癸
                              // *Branch: 子丑寅卯辰巳午未申酉戌亥
      },
      "combo": [              // anchor=combo 時使用（多條件 AND/OR）
        {
          "anchor": "dayStem | yearBranch | monthBranch | dayBranch | hourBranch",
          "in": ["值","值"],  // 需要命中的集合
          "target": "year | month | day | hour | any", // *Branch 類用
          "any": false        // true=此子條件內部 OR；預設 AND
        }
      ],
      "notes": "string (optional)"
    }
  ]
}
\`\`\`

## 合法值字典

### 天干（Stems）
甲 乙 丙 丁 戊 己 庚 辛 壬 癸

### 地支（Branches）  
子 丑 寅 卯 辰 巳 午 未 申 酉 戌 亥

### anchor 合法值
- `"dayStem"`
- `"yearBranch"`
- `"monthBranch"`
- `"dayBranch"`
- `"hourBranch"`
- `"anyBranch"`
- `"combo"`

### target 合法值（Branch 類子條件）
- `"year"`
- `"month"`
- `"day"`
- `"hour"`
- `"any"`

## 示例

### 示例 1: 天乙貴人（dayStem）
\`\`\`json
{
  "name": "天乙貴人",
  "enabled": true,
  "priority": 10,
  "rules": [
    {
      "anchor": "dayStem",
      "rule_ref": "傳統對照-日干取貴人支",
      "table": {
        "甲": ["丑","未"],
        "乙": ["子","申"],
        "丙": ["亥","酉"],
        "丁": ["酉","亥"],
        "戊": ["丑","未"],
        "己": ["子","申"],
        "庚": ["丑","未"],
        "辛": ["午","寅"],
        "壬": ["卯","巳"],
        "癸": ["卯","巳"]
      }
    }
  ]
}
\`\`\`

### 示例 2: 桃花（yearBranch）
\`\`\`json
{
  "name": "桃花",
  "enabled": true,
  "priority": 30,
  "rules": [
    {
      "anchor": "yearBranch",
      "rule_ref": "四柱對照-年支取桃花位",
      "table": {
        "申": ["酉"],
        "子": ["酉"],
        "辰": ["酉"],
        "寅": ["卯"],
        "午": ["卯"],
        "戌": ["卯"],
        "巳": ["午"],
        "酉": ["午"],
        "丑": ["午"],
        "亥": ["子"],
        "卯": ["子"],
        "未": ["子"]
      }
    }
  ]
}
\`\`\`

### 示例 3: 強桃花（combo - 軍團版）
\`\`\`json
{
  "name": "強桃花",
  "enabled": true,
  "priority": 31,
  "rules": [
    {
      "anchor": "combo",
      "rule_ref": "軍團版-年支取位 + 月/日同應",
      "combo": [
        {
          "anchor": "yearBranch",
          "in": ["申","子","辰"],
          "target": "year"
        },
        {
          "anchor": "monthBranch",
          "in": ["酉"],
          "target": "month"
        },
        {
          "anchor": "dayBranch",
          "in": ["酉"],
          "target": "day"
        }
      ]
    }
  ]
}
\`\`\`

## 校驗規則（產出前必檢）

1. **鍵值合法**：所有 key 值必為天干或地支中之一；表內 value 值必為地支或天干
2. **空陣列允許**：資料未覆核可留空，但 `enabled=false` 並於 notes 註明
3. **無多餘欄位**：不得出現 schema 未定義之欄位
4. **唯一性**：同一資料夾內 name 不重複；衝突請用 priority 或改名
5. **可解析性**：確保 JSON UTF-8 無 BOM；逗號、引號正確
6. **證據鏈**：務必填 `rule_ref`；指向你們的來源章節/派別名

## 常用神煞清單

傳統版建議實作清單：
- 天乙貴人、太極貴人、月德貴人、天德貴人
- 文昌、天醫、紅鸞、天喜
- 桃花、驛馬、羊刃、劫煞、災煞、亡神
- 孤辰、寡宿、將星、華蓋
- 三奇、天赦、學堂、解神、歲破

軍團版特殊神煞：
- 強桃花（combo條件）
- 軍團特化版本（可基於傳統版修改）

## 使用方式

將此文檔內容作為系統提示詞（System Prompt）或前置指令提供給 AI，然後詢問：

> 請根據《神煞對照表》為以下神煞生成JSON規則檔：[神煞名稱列表]

AI 將按照規格輸出正確的 JSON 格式。
