import express, { Request, Response, NextFunction } from 'express'
import cors from 'cors'

const app = express()
app.use(cors())
app.use(express.json({ limit: '1mb' }))

// Request logging middleware for debugging
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} ${req.method} ${req.path}`)
    next()
})

// Root endpoint
app.get('/', (req, res) => {
    res.json({
        message: '虹靈御所八字敘事系統 API',
        version: '1.0.0',
        status: 'running',
        timestamp: new Date().toISOString(),
        endpoints: {
            health: '/health',
            status: '/status',
            'railway-status': '/railway-status'
        }
    })
})

// Simple status endpoint for quick checks
app.get('/status', (req, res) => {
    res.json({
        status: 'OK',
        uptime: process.uptime(),
        timestamp: new Date().toISOString()
    })
})

// Railway-specific status monitoring endpoint
app.get('/railway-status', (req, res) => {
    const railwayInfo = {
        status: 'OK',
        platform: 'Railway',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: process.env.NODE_ENV || 'development',
        port: process.env.PORT || 3000,
        memory: process.memoryUsage(),
        railway_env: process.env.RAILWAY_ENVIRONMENT || 'unknown'
    }

    res.json(railwayInfo)
})

// Health check endpoint for Railway - optimized for deployment reliability
app.get('/health', (req, res) => {
    try {
        const timestamp = new Date().toISOString()

        // Basic health check response for Railway
        const healthData = {
            status: 'OK',
            timestamp,
            message: '敘事模組運行正常',
            version: '1.0.0',
            port: process.env.PORT || 3000,
            environment: process.env.NODE_ENV || 'development',
            uptime: process.uptime(),
            memory: process.memoryUsage()
        }

        console.log(`✅ Health check successful - ${timestamp}`)
        res.status(200).json(healthData)
    } catch (error) {
        console.error('❌ Health check error:', error)
        res.status(500).json({
            status: 'ERROR',
            message: '健康檢查失敗',
            timestamp: new Date().toISOString(),
            error: error instanceof Error ? error.message : 'Unknown error',
            port: process.env.PORT || 3000
        })
    }
})
// ===== 放在 app.use(global error handler) 之前 =====
app.use((req: Request, res: Response) => {
  res.status(404).json({
    status: 'error',
    code: 'NOT_FOUND',
    message: `Route not found: ${req.method} ${req.path}`
  });
});

// ===== 在這行下方插入（建議放在 /health 之後） =====

// Preflight for CORS (optional but clean)
app.options('/api/bazi/compute', cors(), (_req, res) => {
  res.setHeader('Access-Control-Max-Age', '86400'); // 可快取一天
  res.sendStatus(200);
});

// 主計算端點：POST /api/bazi/compute
app.post('/api/bazi/compute', async (req, res, next) => {
  try {
    const { datetime_local, timezone, longitude, use_true_solar_time } = req.body || {};

    // 基本驗證：缺必填就回 400（前端才會顯示可讀訊息，而不是 HTML 錯頁）
    const miss: string[] = [];
    if (!datetime_local) miss.push('datetime_local');
    if (!timezone) miss.push('timezone');
    if (typeof longitude !== 'number') miss.push('longitude:number');
    if (typeof use_true_solar_time !== 'boolean') miss.push('use_true_solar_time:boolean');

    if (miss.length) {
      return res.status(400).json({
        status: 'error',
        code: 'INVALID_PAYLOAD',
        message: `Missing/invalid fields: ${miss.join(', ')}`,
      });
    }

    // TODO: 這裡接你的真正八字計算模組（先回範例，證明路由存在且回 JSON）
    const result = {
      year_pillar: '乙丑',
      month_pillar: '壬午',
      day_pillar: '庚子',
      hour_pillar: '丙戌',
      anchors: {
        anchor_basis: '立春分年法',
        rule_ref: '三命通會-年上起月',
        why_matched: '日期 ≥ 立春 → 年干支=…'
      }
    };

    return res.status(200).json({ status: 'success', data: result });
  } catch (err) {
    next(err);
  }
});
// Global error handler (must be after all routes)
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    console.error('[API ERROR]', err)
    const isDev = process.env.NODE_ENV === 'development';
    res.status(500).json({ 
        error: 'internal_error',
        message: isDev ? (err.message || 'An unexpected error occurred') : 'An unexpected error occurred'
    })
})

const PORT = parseInt(process.env.PORT || '3000', 10)
const HOST = process.env.HOST || '0.0.0.0'

console.log('🔧 啟動配置:')
console.log(`   PORT: ${PORT}`)
console.log(`   HOST: ${HOST}`)
console.log(`   NODE_ENV: ${process.env.NODE_ENV || 'development'}`)
console.log(`   Node.js 版本: ${process.version}`)
console.log(`   Railway 部署: ${process.env.RAILWAY_ENVIRONMENT ? '是' : '否'}`)

const server = app.listen(PORT, HOST, () => {
    console.log('🚀 敘事模組 API 已啟動')
    console.log(`📍 地址: http://${HOST}:${PORT}`)
    console.log(`🏥 健康檢查: http://${HOST}:${PORT}/health`)
    console.log(`📊 快速狀態: http://${HOST}:${PORT}/status`)
    console.log(`📝 API 文檔: http://${HOST}:${PORT}/`)
    console.log(`🌟 環境: ${process.env.NODE_ENV || 'development'}`)

    // Railway specific logging
    if (process.env.RAILWAY_ENVIRONMENT) {
        console.log(`🚂 Railway 環境: ${process.env.RAILWAY_ENVIRONMENT}`)
        console.log(`🔗 Railway 服務: ${process.env.RAILWAY_SERVICE_NAME || 'Unknown'}`)
    }

    console.log('✅ 伺服器已準備就緒，可接受連線')

    // Test health endpoint immediately after startup
    setTimeout(() => {
        console.log('🔍 執行啟動後健康檢查...')
        // Simple internal health check to verify readiness
        try {
            console.log('🧪 測試基本功能模組...')
            console.log('✅ 啟動後檢查完成 - 服務已就緒')
        } catch (startupError) {
            console.error('⚠️ 啟動後檢查發現問題:', startupError)
        }
    }, 1000)
})

// Handle server startup errors
server.on('error', (error: Error & { code?: string }) => {
    console.error('❌ 伺服器啟動失敗:', error)
    if (error.code === 'EADDRINUSE') {
        console.error(`   埠號 ${PORT} 已被使用`)
        console.error('   Railway 提示: 確保 PORT 環境變數正確設定')
    } else if (error.code === 'EACCES') {
        console.error(`   權限不足，無法綁定到埠號 ${PORT}`)
        console.error('   Railway 提示: 檢查埠號權限設定')
    } else if (error.code === 'ENOTFOUND') {
        console.error(`   無法解析主機 ${HOST}`)
        console.error('   Railway 提示: 檢查 HOST 環境變數設定')
    }
    console.error('   建議檢查 Railway 環境變數和部署日誌')
    process.exit(1)
})

// Graceful shutdown for Railway
process.on('SIGTERM', () => {
    console.log('📶 收到 SIGTERM 信號，正在優雅關閉伺服器...')
    server.close(() => {
        console.log('✅ 伺服器已安全關閉')
        process.exit(0)
    })
})

process.on('SIGINT', () => {
    console.log('⚡ 收到 SIGINT 信號，正在優雅關閉伺服器...')
    server.close(() => {
        console.log('✅ 伺服器已安全關閉')
        process.exit(0)
    })
})

// Handle uncaught exceptions with Railway context
process.on('uncaughtException', (error) => {
    console.error('❌ 未捕獲的例外:', error)
    console.error('   Railway 部署提示: 檢查應用程式依賴和建置過程')
    console.error('   正在嘗試安全關閉伺服器...')
    server.close(() => {
        process.exit(1)
    })
})

// Handle unhandled promise rejections with Railway context
process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ 未處理的 Promise 拒絕:', reason)
    console.error('   Promise:', promise)
    console.error('   Railway 部署提示: 檢查非同步操作和錯誤處理')
})
