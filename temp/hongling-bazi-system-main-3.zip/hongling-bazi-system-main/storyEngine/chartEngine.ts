// 修復後的 chartEngine.ts - 只匯入實際使用的模組
import {
  PillarSet,
  calculateYearPillar,
  calculateMonthPillar,
  calculateDayPillar,
  calculateHourPillar,
  calculateTenGods,
  calculateShensha,
  calcFiveElementPower,
  calcYinYangCount,
} from "./utils";

// 如果需要格式化四柱，可以在這裡定義本地函數
function formatPillars(pillars: PillarSet): string {
  return `${pillars.year.gan}${pillars.year.zhi} ${pillars.month.gan}${pillars.month.zhi} ${pillars.day.gan}${pillars.day.zhi} ${pillars.hour.gan}${pillars.hour.zhi}`;
}

export interface BirthInfo {
  year: number;
  month: number;
  day: number;
  hour: number;
}

export class ChartEngine {
  private pillars: PillarSet;

  constructor(birthInfo: BirthInfo) {
    const { year, month, day, hour } = birthInfo;

    // 計算四柱
    const yearPillar = calculateYearPillar(year, month, day);
    const monthPillar = calculateMonthPillar(yearPillar.gan, year, month, day);
    const dayPillar = calculateDayPillar(year, month, day);
    const hourPillar = calculateHourPillar(hour, dayPillar.gan);

    this.pillars = {
      year: yearPillar,
      month: monthPillar,
      day: dayPillar,
      hour: hourPillar,
    };
  }

  getPillars(): PillarSet {
    return this.pillars;
  }

  getFormattedPillars(): string {
    return formatPillars(this.pillars);
  }

  getFiveElementPower(): Record<string, number> {
    return calcFiveElementPower(this.pillars);
  }

  getYinYangCount(): { 陰: number; 陽: number } {
    return calcYinYangCount(this.pillars);
  }

  getTenGods(): string[] {
    const dayGan = this.pillars.day.gan;
    const otherGans = [
      this.pillars.year.gan,
      this.pillars.month.gan,
      this.pillars.hour.gan,
    ];
    return calculateTenGods(dayGan, otherGans);
  }

  getShensha(): string[] {
    return calculateShensha(this.pillars);
  }

  // 生成完整的命盤分析
  generateFullAnalysis(): {
    pillars: string;
    fiveElements: Record<string, number>;
    yinYang: { 陰: number; 陽: number };
    tenGods: string[];
    shensha: string[];
  } {
    return {
      pillars: this.getFormattedPillars(),
      fiveElements: this.getFiveElementPower(),
      yinYang: this.getYinYangCount(),
      tenGods: this.getTenGods(),
      shensha: this.getShensha(),
    };
  }
}

// 型別在地宣告，避免外部依賴遺失
export type InputData = { yyyy: number; mm: number; dd: number; hh: number };
export type ChartResult = {
  pillars: PillarSet;
  tenGods: string[];
  shensha: string[];
  fiveElements: Record<string, number>;
  yinYang: { 陰: number; 陽: number };
};

export function generateChart(input: InputData): ChartResult {
  const { yyyy, mm, dd, hh } = input;

  const year = calculateYearPillar(yyyy, mm, dd);
  const month = calculateMonthPillar(year.gan, yyyy, mm, dd);
  const day = calculateDayPillar(yyyy, mm, dd);
  const hour = calculateHourPillar(hh, day.gan);

  const pillars: PillarSet = {
    year,
    month,
    day,
    hour,
  };

  const tenGods = calculateTenGods(day.gan, [year.gan, month.gan, hour.gan]);
  const shensha = calculateShensha(pillars);
  const fiveElements = calcFiveElementPower(pillars);
  const yinYang = calcYinYangCount(pillars);

  return {
    pillars,
    tenGods,
    shensha,
    fiveElements,
    yinYang,
  };
}

export default ChartEngine;
