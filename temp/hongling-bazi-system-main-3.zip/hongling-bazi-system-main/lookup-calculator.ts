/**
 * 專業八字計算器 - 使用JSON查表精確計算
 * 完全按照問題陳述要求實現：查表方式、精確節氣、五虎遁/五鼠遁、真太陽時等
 */

import * as fs from "fs";
import * as path from "path";

// 基礎介面定義
export interface BaziOptions {
  use_early_zi?: boolean; // 子時是否換日
  use_true_solar_time?: boolean; // 是否使用真太陽時
  longitude?: number; // 經度（用於真太陽時計算）
  debug?: boolean; // 除錯模式
}

export interface PillarResult {
  stem: string;
  branch: string;
  pillar: string;
  calculation_log?: string[];
}

export interface BaziResult {
  year: PillarResult;
  month: PillarResult;
  day: PillarResult;
  hour: PillarResult;
  calculation_logs: {
    year_log: string[];
    month_log: string[];
    day_log: string[];
    hour_log: string[];
    solar_terms_log: string[];
    five_elements_log: string[];
  };
  five_elements: Record<string, number>;
  ten_gods: Array<{ name: string; basis: string; calculation: string }>;
  shensha: Array<{ name: string; anchor_basis: string; source: string }>;
  nayin: {
    year: string;
    month: string;
    day: string;
    hour: string;
  };
}

// Lookup table interfaces
interface SolarTermEntry {
  name: string;
  date: string; // ISO date string or other format
  longitude: number;
}
type SolarTermsData = {
  years: Record<string, Record<string, { date: string; longitude: number }>>;
};

interface GanZhiEntry {
  year: number;
  month: number;
  day: number;
  hour: number;
  stem: string;
  branch: string;
}
type GanZhiData = {
  stems: string[];
  branches: string[];
  stemProperties: Record<string, any>;
  branchProperties: Record<string, any>;
};

interface FiveTigersEntry {
  yearStem: string;
  monthStems: string[];
}
type FiveTigersData = { mapping: Record<string, Record<string, string>> };

interface FiveRatsEntry {
  dayStem: string;
  hourStems: string[];
}
type FiveRatsData = {
  hourBranches: Record<string, string>;
  mapping: Record<string, Record<string, string>>;
};

interface NaYinEntry {
  stem: string;
  branch: string;
  nayin: string;
}
type NaYinData = { nayin: Record<string, string> };

interface ShenShaEntry {
  name: string;
  anchor_basis: string;
  source: string;
}
type ShenShaData = {
  shensha: {
    yearBased: { list: Array<any> };
    dayBased: { list: Array<any> };
  };
};

interface HiddenStemsEntry {
  branch: string;
  stems: string[];
}
type HiddenStemsData = { hiddenStems: Record<string, any> };

export class ProfessionalBaziCalculator {
  private solarTermsData: SolarTermsData = { years: {} };
  private ganZhiData: GanZhiData = {
    stems: [],
    branches: [],
    stemProperties: {},
    branchProperties: {},
  };
  private fiveTigersData: FiveTigersData = { mapping: {} };
  private fiveRatsData: FiveRatsData = { hourBranches: {}, mapping: {} };
  private nayinData: NaYinData = { nayin: {} };
  private shenshaData: ShenShaData = {
    shensha: { yearBased: { list: [] }, dayBased: { list: [] } },
  };
  private hiddenStemsData: HiddenStemsData = { hiddenStems: {} };

  constructor() {
    this.loadLookupTables();
  }

  private loadLookupTables(): void {
    const dataDir = path.join(__dirname, "data");

    try {
      this.solarTermsData = JSON.parse(
        fs.readFileSync(path.join(dataDir, "solar_terms.json"), "utf8"),
      );
      this.ganZhiData = JSON.parse(
        fs.readFileSync(path.join(dataDir, "gan_zhi.json"), "utf8"),
      );
      this.fiveTigersData = JSON.parse(
        fs.readFileSync(path.join(dataDir, "five_tigers.json"), "utf8"),
      );
      this.fiveRatsData = JSON.parse(
        fs.readFileSync(path.join(dataDir, "five_rats.json"), "utf8"),
      );
      this.nayinData = JSON.parse(
        fs.readFileSync(path.join(dataDir, "nayin.json"), "utf8"),
      );
      this.shenshaData = JSON.parse(
        fs.readFileSync(path.join(dataDir, "shensha.json"), "utf8"),
      );
      this.hiddenStemsData = JSON.parse(
        fs.readFileSync(path.join(dataDir, "hidden_stems.json"), "utf8"),
      );
    } catch (error) {
      throw new Error(`Failed to load lookup tables: ${error}`);
    }
  }

  /**
   * 主要計算方法 - 根據生日時間計算完整八字
   */
  public calculateBazi(
    year: number,
    month: number,
    day: number,
    hour: number,
    minute: number = 0,
    options: BaziOptions = {},
  ): BaziResult {
    const logs: {
      year_log: string[];
      month_log: string[];
      day_log: string[];
      hour_log: string[];
      solar_terms_log: string[];
      five_elements_log: string[];
    } = {
      year_log: [],
      month_log: [],
      day_log: [],
      hour_log: [],
      solar_terms_log: [],
      five_elements_log: [],
    };

    // 處理真太陽時調整
    let adjustedHour = hour;
    if (options.use_true_solar_time && options.longitude) {
      const trueSolarAdjustment = this.calculateTrueSolarTimeAdjustment(
        options.longitude,
      );
      adjustedHour = hour + trueSolarAdjustment;
      logs.hour_log.push(
        `真太陽時調整: 經度${options.longitude}° → 時間調整${trueSolarAdjustment}小時 → ${adjustedHour}時`,
      );
    }

    // 1. 年柱計算（根據立春時刻）
    const yearPillar = this.calculateYearPillar(
      year,
      month,
      day,
      hour,
      minute,
      logs.year_log,
      logs.solar_terms_log,
    );

    // 2. 月柱計算（根據節氣+五虎遁）
    const monthPillar = this.calculateMonthPillar(
      year,
      month,
      day,
      hour,
      minute,
      yearPillar.stem,
      logs.month_log,
      logs.solar_terms_log,
    );

    // 3. 日柱計算（甲子基準日推算）
    const dayPillar = this.calculateDayPillar(
      year,
      month,
      day,
      adjustedHour,
      options,
      logs.day_log,
    );

    // 4. 時柱計算（五鼠遁）
    const hourPillar = this.calculateHourPillar(
      adjustedHour,
      dayPillar.stem,
      logs.hour_log,
    );

    // 5. 五行統計
    const fiveElements = this.calculateFiveElements(
      {
        year: yearPillar,
        month: monthPillar,
        day: dayPillar,
        hour: hourPillar,
      },
      logs.five_elements_log,
    );

    // 6. 十神計算
    const tenGods = this.calculateTenGods(dayPillar.stem, [
      yearPillar.stem,
      monthPillar.stem,
      hourPillar.stem,
    ]);

    // 7. 神煞計算
    const shensha = this.calculateShensha({
      year: yearPillar,
      month: monthPillar,
      day: dayPillar,
      hour: hourPillar,
    });

    // 8. 納音
    const nayin = {
      year: this.nayinData.nayin[yearPillar.pillar] || "",
      month: this.nayinData.nayin[monthPillar.pillar] || "",
      day: this.nayinData.nayin[dayPillar.pillar] || "",
      hour: this.nayinData.nayin[hourPillar.pillar] || "",
    };

    return {
      year: yearPillar,
      month: monthPillar,
      day: dayPillar,
      hour: hourPillar,
      calculation_logs: logs,
      five_elements: fiveElements,
      ten_gods: tenGods,
      shensha: shensha,
      nayin: nayin,
    };
  }

  /**
   * 年柱計算 - 使用立春時刻精確判斷
   */
  private calculateYearPillar(
    year: number,
    month: number,
    day: number,
    hour: number,
    minute: number,
    yearLog: string[],
    solarTermsLog: string[],
  ): PillarResult {
    const birthTime = new Date(year, month - 1, day, hour, minute);

    // 查找立春時刻
    let actualYear = year;
    const currentYearTerms = this.solarTermsData.years[year.toString()];
    const prevYearTerms = this.solarTermsData.years[(year - 1).toString()];

    if (currentYearTerms && currentYearTerms["立春"]) {
      const lichunTime = new Date(currentYearTerms["立春"].date);
      if (birthTime < lichunTime) {
        actualYear = year - 1;
        yearLog.push(
          `出生時間${birthTime.toISOString()}早於當年立春${lichunTime.toISOString()}，年柱使用${actualYear}年`,
        );
        solarTermsLog.push(
          `立春分界判斷: ${year}年立春於${lichunTime.toISOString()}`,
        );
      } else {
        yearLog.push(
          `出生時間${birthTime.toISOString()}晚於當年立春${lichunTime.toISOString()}，年柱使用${actualYear}年`,
        );
        solarTermsLog.push(
          `立春分界判斷: ${year}年立春於${lichunTime.toISOString()}`,
        );
      }
    } else {
      yearLog.push(`缺少${year}年立春資料，採用預設判斷`);
    }

    const stemIndex = (actualYear - 4) % 10;
    const branchIndex = (actualYear - 4) % 12;
    const stem = this.ganZhiData.stems[stemIndex];
    const branch = this.ganZhiData.branches[branchIndex];

    yearLog.push(
      `年柱計算: ${actualYear}年 → 天干索引${stemIndex}(${stem}) 地支索引${branchIndex}(${branch})`,
    );

    return {
      stem,
      branch,
      pillar: stem + branch,
      calculation_log: [...yearLog],
    };
  }

  /**
   * 月柱計算 - 使用節氣分月+五虎遁月干
   */
  private calculateMonthPillar(
    year: number,
    month: number,
    day: number,
    hour: number,
    minute: number,
    yearStem: string,
    monthLog: string[],
    solarTermsLog: string[],
  ): PillarResult {
    const birthTime = new Date(year, month - 1, day, hour, minute);

    // 查找當前節氣確定月支
    const yearTerms = this.solarTermsData.years[year.toString()];
    let monthBranch = "寅"; // 預設
    let currentTerm = "立春";

    if (yearTerms) {
      // 節氣順序來判斷月支
      const termOrder = [
        "立春",
        "驚蟄",
        "清明",
        "立夏",
        "芒種",
        "小暑",
        "立秋",
        "白露",
        "寒露",
        "立冬",
        "大雪",
        "小寒",
      ];
      const branchOrder = [
        "寅",
        "卯",
        "辰",
        "巳",
        "午",
        "未",
        "申",
        "酉",
        "戌",
        "亥",
        "子",
        "丑",
      ];

      for (let i = 0; i < termOrder.length; i++) {
        const termName = termOrder[i];
        const termTime = yearTerms[termName];
        if (termTime && birthTime >= new Date(termTime.date)) {
          monthBranch = branchOrder[i];
          currentTerm = termName;
          solarTermsLog.push(
            `節氣判斷: 出生時間晚於${termName}(${termTime.date})，月支為${monthBranch}`,
          );
        }
      }
    }

    // 使用五虎遁推算月干
    const fiveTigerMapping = this.fiveTigersData.mapping[yearStem];
    let monthStem = "甲"; // 預設

    if (fiveTigerMapping && fiveTigerMapping[monthBranch]) {
      monthStem = fiveTigerMapping[monthBranch];
      monthLog.push(
        `五虎遁計算: 年干${yearStem} + 月支${monthBranch} → 月干${monthStem}`,
      );
    } else {
      monthLog.push(`五虎遁查表失敗，使用預設月干${monthStem}`);
    }

    monthLog.push(
      `月柱確定: ${currentTerm}節氣 → ${monthBranch}支 → 五虎遁得${monthStem}干`,
    );

    return {
      stem: monthStem,
      branch: monthBranch,
      pillar: monthStem + monthBranch,
      calculation_log: [...monthLog],
    };
  }

  /**
   * 日柱計算 - 使用甲子基準日推算
   */
  private calculateDayPillar(
    year: number,
    month: number,
    day: number,
    hour: number,
    options: BaziOptions,
    dayLog: string[],
  ): PillarResult {
    // 使用1985年9月22日甲子日作為基準（如問題陳述中的例子）
    const baseDate = new Date(1985, 8, 22); // 9月22日，JavaScript月份從0開始
    let targetDate = new Date(year, month - 1, day);

    // 子時換日處理
    let actualDay = day;
    if (hour >= 23 && options.use_early_zi) {
      targetDate = new Date(year, month - 1, day + 1);
      actualDay = day + 1;
      dayLog.push(
        `子時換日模式: ${hour}時屬於次日，實際計算日期為${actualDay}日`,
      );
    } else if (hour >= 23) {
      dayLog.push(`子時不換日模式: ${hour}時仍屬於當日${day}日`);
    }

    const daysDiff = Math.floor(
      (targetDate.getTime() - baseDate.getTime()) / (1000 * 60 * 60 * 24),
    );
    const stemIndex = ((daysDiff % 10) + 10) % 10;
    const branchIndex = ((daysDiff % 12) + 12) % 12;

    const stem = this.ganZhiData.stems[stemIndex];
    const branch = this.ganZhiData.branches[branchIndex];

    dayLog.push(
      `日柱計算: 基準日1985/09/22甲子 → 目標日${year}/${month}/${actualDay}`,
    );
    dayLog.push(
      `天數差: ${daysDiff}天 → 天干索引${stemIndex}(${stem}) 地支索引${branchIndex}(${branch})`,
    );
    dayLog.push(
      `子時處理策略: ${options.use_early_zi ? "早子時換日" : "晚子時不換日"}`,
    );

    return {
      stem,
      branch,
      pillar: stem + branch,
      calculation_log: [...dayLog],
    };
  }

  /**
   * 時柱計算 - 使用兩小時一支查表+五鼠遁
   */
  private calculateHourPillar(
    hour: number,
    dayStem: string,
    hourLog: string[],
  ): PillarResult {
    // 查表確定時支（兩小時一支）
    const hourBranches = this.fiveRatsData.hourBranches;
    let hourBranch = "子"; // 預設

    // 找到對應的時支
    for (const [timeKey, branch] of Object.entries(hourBranches)) {
      const timeNum = parseInt(timeKey);
      if (hour === timeNum || (timeNum === 23 && hour === 0)) {
        hourBranch = branch as string;
        break;
      }
    }

    // 如果沒有精確匹配，使用範圍匹配
    if (hourBranch === "子" && hour !== 23 && hour !== 0) {
      const timeRanges = [
        { range: [1, 2], branch: "丑" },
        { range: [3, 4], branch: "寅" },
        { range: [5, 6], branch: "卯" },
        { range: [7, 8], branch: "辰" },
        { range: [9, 10], branch: "巳" },
        { range: [11, 12], branch: "午" },
        { range: [13, 14], branch: "未" },
        { range: [15, 16], branch: "申" },
        { range: [17, 18], branch: "酉" },
        { range: [19, 20], branch: "戌" },
        { range: [21, 22], branch: "亥" },
      ];

      for (const { range, branch } of timeRanges) {
        if (hour >= range[0] && hour <= range[1]) {
          hourBranch = branch;
          break;
        }
      }
    }

    // 使用五鼠遁推算時干
    const fiveRatMapping = this.fiveRatsData.mapping[dayStem];
    let hourStem = "甲"; // 預設

    if (fiveRatMapping && fiveRatMapping[hourBranch]) {
      hourStem = fiveRatMapping[hourBranch];
      hourLog.push(
        `五鼠遁計算: 日干${dayStem} + 時支${hourBranch} → 時干${hourStem}`,
      );
    } else {
      hourLog.push(`五鼠遁查表失敗，使用預設時干${hourStem}`);
    }

    hourLog.push(
      `時柱計算: ${hour}時 → 時支${hourBranch} → 五鼠遁得時干${hourStem}`,
    );
    hourLog.push(`兩小時一支查表: ${hour}時對應${hourBranch}支`);

    return {
      stem: hourStem,
      branch: hourBranch,
      pillar: hourStem + hourBranch,
      calculation_log: [...hourLog],
    };
  }

  /**
   * 五行計算 - 包含藏干權重
   */
  private calculateFiveElements(
    pillars: {
      year: PillarResult;
      month: PillarResult;
      day: PillarResult;
      hour: PillarResult;
    },
    fiveElementsLog: string[],
  ): Record<string, number> {
    const elements = { 木: 0, 火: 0, 土: 0, 金: 0, 水: 0 };

    // 天干五行
    const stems = [
      pillars.year.stem,
      pillars.month.stem,
      pillars.day.stem,
      pillars.hour.stem,
    ];
    stems.forEach((stem, index) => {
      const pillarNames = ["年", "月", "日", "時"];
      const element = this.ganZhiData.stemProperties[stem]?.element;
      if (element) {
        elements[element] += 1.0;
        fiveElementsLog.push(`${pillarNames[index]}干${stem}(${element}) +1.0`);
      }
    });

    // 地支五行（本氣）
    const branches = [
      pillars.year.branch,
      pillars.month.branch,
      pillars.day.branch,
      pillars.hour.branch,
    ];
    branches.forEach((branch, index) => {
      const pillarNames = ["年", "月", "日", "時"];
      const element = this.ganZhiData.branchProperties[branch]?.element;
      if (element) {
        const weight = index === 1 ? 1.5 : 1.0; // 月令加權
        elements[element] += weight;
        fiveElementsLog.push(
          `${pillarNames[index]}支${branch}(${element}) +${weight}${index === 1 ? "(月令加權)" : ""}`,
        );
      }
    });

    // 藏干五行
    branches.forEach((branch, index) => {
      const pillarNames = ["年", "月", "日", "時"];
      const hiddenData = this.hiddenStemsData.hiddenStems[branch];
      if (hiddenData && hiddenData.stems) {
        hiddenData.stems.forEach((stemInfo: any) => {
          const element =
            this.ganZhiData.stemProperties[stemInfo.stem]?.element;
          if (element) {
            const weight = stemInfo.weight * (index === 1 ? 1.5 : 1.0); // 月令藏干也加權
            elements[element] += weight;
            fiveElementsLog.push(
              `${pillarNames[index]}支${branch}藏干${stemInfo.stem}(${element}) +${weight.toFixed(2)} [${stemInfo.type}]`,
            );
          }
        });
      }
    });

    fiveElementsLog.push(
      `五行統計結果: ${Object.entries(elements)
        .map(([e, v]) => `${e}${v.toFixed(1)}`)
        .join(", ")}`,
    );
    return elements;
  }

  /**
   * 十神計算 - 比較五行生克+陰陽
   */
  private calculateTenGods(
    dayStem: string,
    otherStems: string[],
  ): Array<{ name: string; basis: string; calculation: string }> {
    const tenGods: Array<{ name: string; basis: string; calculation: string }> =
      [];
    const dayElement = this.ganZhiData.stemProperties[dayStem]?.element;
    const dayYinYang = this.ganZhiData.stemProperties[dayStem]?.yinyang;

    otherStems.forEach((stem, index) => {
      const pillarNames = ["年", "月", "時"];
      const stemElement = this.ganZhiData.stemProperties[stem]?.element;
      const stemYinYang = this.ganZhiData.stemProperties[stem]?.yinyang;

      let tenGodName = "";
      let calculation = "";

      if (dayElement === stemElement) {
        // 同五行
        if (dayYinYang === stemYinYang) {
          tenGodName = "比肩";
          calculation = `同五行同陰陽: ${dayStem}(${dayElement}${dayYinYang}) vs ${stem}(${stemElement}${stemYinYang})`;
        } else {
          tenGodName = "劫財";
          calculation = `同五行異陰陽: ${dayStem}(${dayElement}${dayYinYang}) vs ${stem}(${stemElement}${stemYinYang})`;
        }
      } else {
        // 不同五行，判斷生克關係
        const relation = this.getFiveElementRelation(dayElement, stemElement);
        if (relation === "生") {
          tenGodName = dayYinYang === stemYinYang ? "偏印" : "正印";
          calculation = `${stemElement}生${dayElement}，${dayYinYang === stemYinYang ? "同" : "異"}陰陽`;
        } else if (relation === "克") {
          tenGodName = dayYinYang === stemYinYang ? "偏官" : "正官";
          calculation = `${stemElement}克${dayElement}，${dayYinYang === stemYinYang ? "同" : "異"}陰陽`;
        } else if (relation === "洩") {
          tenGodName = dayYinYang === stemYinYang ? "食神" : "傷官";
          calculation = `${dayElement}生${stemElement}，${dayYinYang === stemYinYang ? "同" : "異"}陰陽`;
        } else if (relation === "耗") {
          tenGodName = dayYinYang === stemYinYang ? "偏財" : "正財";
          calculation = `${dayElement}克${stemElement}，${dayYinYang === stemYinYang ? "同" : "異"}陰陽`;
        }
      }

      tenGods.push({
        name: tenGodName,
        basis: `${pillarNames[index]}干${stem}`,
        calculation: calculation,
      });
    });

    return tenGods;
  }

  /**
   * 神煞計算
   */
  private calculateShensha(pillars: {
    year: PillarResult;
    month: PillarResult;
    day: PillarResult;
    hour: PillarResult;
  }): Array<{ name: string; anchor_basis: string; source: string }> {
    const shensha: Array<{
      name: string;
      anchor_basis: string;
      source: string;
    }> = [];

    // 年支為基準的神煞
    const yearBasedShensha = this.shenshaData.shensha.yearBased.list;
    Object.entries(yearBasedShensha).forEach(([name, data]: [string, any]) => {
      const mapping = data.mapping[pillars.year.branch];
      if (mapping) {
        const targets = Array.isArray(mapping) ? mapping : [mapping];
        targets.forEach((target: string) => {
          if (
            [
              pillars.month.branch,
              pillars.day.branch,
              pillars.hour.branch,
            ].includes(target)
          ) {
            shensha.push({
              name: name,
              anchor_basis: `年支${pillars.year.branch}`,
              source: `年支${pillars.year.branch}見${target}`,
            });
          }
        });
      }
    });

    // 日干為基準的神煞
    const dayBasedShensha = this.shenshaData.shensha.dayBased.list;
    Object.entries(dayBasedShensha).forEach(([name, data]: [string, any]) => {
      if (name === "魁罡" && data.mapping[pillars.day.pillar]) {
        shensha.push({
          name: name,
          anchor_basis: `日柱${pillars.day.pillar}`,
          source: `日柱${pillars.day.pillar}為魁罡日`,
        });
      } else if (name !== "魁罡") {
        const target = data.mapping[pillars.day.stem];
        if (
          target &&
          [
            pillars.year.branch,
            pillars.month.branch,
            pillars.day.branch,
            pillars.hour.branch,
          ].includes(target)
        ) {
          shensha.push({
            name: name,
            anchor_basis: `日干${pillars.day.stem}`,
            source: `日干${pillars.day.stem}見${target}`,
          });
        }
      }
    });

    return shensha;
  }

  /**
   * 真太陽時調整計算
   */
  private calculateTrueSolarTimeAdjustment(longitude: number): number {
    // 中國標準時間基於東經120度
    const standardLongitude = 120;
    const adjustment = (longitude - standardLongitude) / 15; // 每15度差1小時
    return adjustment;
  }

  /**
   * 五行生克關係判斷
   */
  private getFiveElementRelation(element1: string, element2: string): string {
    const shengRelations = {
      木: "火",
      火: "土",
      土: "金",
      金: "水",
      水: "木",
    };
    const keRelations = {
      木: "土",
      火: "金",
      土: "水",
      金: "木",
      水: "火",
    };

    if (shengRelations[element1] === element2) return "洩"; // element1生element2
    if (shengRelations[element2] === element1) return "生"; // element2生element1
    if (keRelations[element1] === element2) return "耗"; // element1克element2
    if (keRelations[element2] === element1) return "克"; // element2克element1

    return "無關";
  }
}
